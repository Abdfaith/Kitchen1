package com.kitchen.designer.engine

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.tan

/** Camera recovered from 4 marked floor corners: h = plane(m)->pixel homography (row-major), plus a Filament-ready pose. */
class Calib(val h: DoubleArray, val eye: DoubleArray, val look: DoubleArray, val up: DoubleArray, val fovV: Double, val iw: Double = 0.0, val ih: Double = 0.0) {
    /** World point (metres) -> [pixelX, pixelY, pixelsPerMetreAtDepth]; pinhole camera from eye/look/up/fov. Null if behind the camera. */
    fun project3D(x: Double, y: Double, z: Double): DoubleArray? {
        var fx = look[0] - eye[0]; var fy = look[1] - eye[1]; var fz = look[2] - eye[2]
        val fl = sqrt(fx * fx + fy * fy + fz * fz); fx /= fl; fy /= fl; fz /= fl
        var rx = fy * up[2] - fz * up[1]; var ry = fz * up[0] - fx * up[2]; var rz = fx * up[1] - fy * up[0]
        val rl = sqrt(rx * rx + ry * ry + rz * rz); rx /= rl; ry /= rl; rz /= rl
        val ux = ry * fz - rz * fy; val uy = rz * fx - rx * fz; val uz = rx * fy - ry * fx
        val vx = x - eye[0]; val vy = y - eye[1]; val vz = z - eye[2]
        val zc = vx * fx + vy * fy + vz * fz
        if (zc < 0.05) return null
        val fpx = (ih / 2) / tan(Math.toRadians(fovV / 2))
        return doubleArrayOf(iw / 2 + fpx * (vx * rx + vy * ry + vz * rz) / zc, ih / 2 - fpx * (vx * ux + vy * uy + vz * uz) / zc, fpx / zc)
    }

    fun project(x: Double, z: Double): DoubleArray {
        val u = h[0] * x + h[1] * z + h[2]; val v = h[3] * x + h[4] * z + h[5]; val w = h[6] * x + h[7] * z + h[8]
        return doubleArrayOf(u / w, v / w)
    }

    /** Unit pixel-space direction from (px,py) toward the vanishing point of floor axis 0 (X) or 1 (Z). */
    fun dirTo(axis: Int, px: Double, py: Double): DoubleArray? {
        val a = h[axis]; val b = h[3 + axis]; val w = h[6 + axis]
        val dx: Double; val dy: Double
        if (abs(w) < 1e-9) { dx = a; dy = b } else { dx = a / w - px; dy = b / w - py }
        val l = hypot(dx, dy)
        return if (l < 1e-9) null else doubleArrayOf(dx / l, dy / l)
    }
}

object PhotoCalib {
    private fun solve(a: Array<DoubleArray>, b: DoubleArray): DoubleArray? {
        val n = b.size
        for (c in 0 until n) {
            var p = c
            for (r in c + 1 until n) if (abs(a[r][c]) > abs(a[p][c])) p = r
            if (abs(a[p][c]) < 1e-12) return null
            val t = a[c]; a[c] = a[p]; a[p] = t; val tb = b[c]; b[c] = b[p]; b[p] = tb
            for (r in c + 1 until n) {
                val f = a[r][c] / a[c][c]
                for (k in c until n) a[r][k] -= f * a[c][k]
                b[r] -= f * b[c]
            }
        }
        val x = DoubleArray(n)
        for (r in n - 1 downTo 0) { var s = b[r]; for (k in r + 1 until n) s -= a[r][k] * x[k]; x[r] = s / a[r][r] }
        return x
    }

    private fun norm(v: DoubleArray): DoubleArray { val l = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return doubleArrayOf(v[0] / l, v[1] / l, v[2] / l) }
    private fun dot(a: DoubleArray, b: DoubleArray) = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
    private fun cross(a: DoubleArray, b: DoubleArray) = doubleArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])

    /**
     * px: tapped pixels for floor corners (0,0) (W,0) (W,D) (0,D) in metres (back-left, back-right, front-right, front-left).
     * World: X right, Y up, Z toward the viewer. Principal point assumed at the image centre.
     */
    fun calibrate(px: List<Pair<Double, Double>>, wM: Double, dM: Double, iw: Double, ih: Double): Calib? {
        val src = listOf(0.0 to 0.0, wM to 0.0, wM to dM, 0.0 to dM)
        val a = Array(8) { DoubleArray(8) }; val b = DoubleArray(8)
        for (i in 0 until 4) {
            val (x, y) = src[i]; val (u, v) = px[i]
            a[2 * i] = doubleArrayOf(x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y); b[2 * i] = u
            a[2 * i + 1] = doubleArrayOf(0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y); b[2 * i + 1] = v
        }
        val s = solve(a, b) ?: return null
        val h = doubleArrayOf(s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], 1.0)
        val cx = iw / 2; val cy = ih / 2
        val hp = doubleArrayOf(h[0] - cx * h[6], h[1] - cx * h[7], h[2] - cx * h[8], h[3] - cy * h[6], h[4] - cy * h[7], h[5] - cy * h[8], h[6], h[7], h[8])
        val h1 = doubleArrayOf(hp[0], hp[3], hp[6]); val h2 = doubleArrayOf(hp[1], hp[4], hp[7]); val h3 = doubleArrayOf(hp[2], hp[5], hp[8])
        val big = max(iw, ih)
        val f2 = if (abs(h1[2] * h2[2]) > 1e-12) -(h1[0] * h2[0] + h1[1] * h2[1]) / (h1[2] * h2[2]) else -1.0
        var f = if (f2 > 0) sqrt(f2) else Double.NaN
        if (f.isNaN() || f < 0.35 * big || f > 6 * big) f = 1.15 * big
        fun kinv(v: DoubleArray) = doubleArrayOf(v[0] / f, v[1] / f, v[2])
        val k1 = kinv(h1); val k2 = kinv(h2); val k3 = kinv(h3)
        var lam = 1.0 / sqrt(dot(k1, k1))
        if (k3[2] * lam < 0) lam = -lam
        val c0 = norm(doubleArrayOf(k1[0] * lam, k1[1] * lam, k1[2] * lam))
        val r2 = doubleArrayOf(k2[0] * lam, k2[1] * lam, k2[2] * lam); val d = dot(r2, c0)
        val c2 = norm(doubleArrayOf(r2[0] - d * c0[0], r2[1] - d * c0[1], r2[2] - d * c0[2]))
        val c1 = cross(c2, c0)
        val t = doubleArrayOf(k3[0] * lam, k3[1] * lam, k3[2] * lam)
        val eye = doubleArrayOf(-dot(c0, t), -dot(c1, t), -dot(c2, t))
        val fwd = doubleArrayOf(c0[2], c1[2], c2[2]); val up = doubleArrayOf(-c0[1], -c1[1], -c2[1])
        if (up[1] < 0.05 || eye[1] < 0.1) return null   // mirrored order or impossible pose
        val fov = Math.toDegrees(2 * atan(ih / (2 * f)))
        return Calib(h, eye, doubleArrayOf(eye[0] + fwd[0] * 3, eye[1] + fwd[1] * 3, eye[2] + fwd[2] * 3), up, fov, iw, ih)
    }
}
