package com.kitchen.designer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import com.kitchen.designer.model.*
import kotlin.math.*

/** Top-down 2D editor. Drag items (uses SnapEngine) or drag the orange corner to resize the room. */
class PlanEditorView(ctx: Context, private val plan: Plan) : View(ctx) {
    var selected: PlacedItem? = null
    var onItemMoved: (PlacedItem) -> Unit = {}
    var onSelected: (PlacedItem?) -> Unit = {}
    var onRoomResized: () -> Unit = {}
    var onDrop: (PlacedItem?) -> Unit = {}

    private enum class Mode { NONE, MOVE, RESIZE }
    private var mode = Mode.NONE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val maxW = 1000f; private val maxD = 800f   // fixed canvas scale so resizing doesn't shift the handle
    private val pad = 40f; private val bottomPad = 170f
    private var s = 1f

    private fun X(v: Float) = pad + v * s
    private fun Y(v: Float) = pad + v * s

    private fun color(c: Category) = when (c) {
        Category.BASE -> 0xFFB88557.toInt(); Category.WALL_UNIT -> 0xFF4A5555.toInt()
        Category.APPLIANCE -> 0xFFBFC4CC.toInt(); Category.COUNTER -> 0xFFE8E8E8.toInt(); Category.DECOR -> 0xFF5A9040.toInt(); Category.OPENING -> 0xFF4FA3D1.toInt(); Category.FURNITURE -> 0xFF9A7BC0.toInt()
    }

    override fun onDraw(c: Canvas) {
        s = min((width - 2 * pad) / maxW, (height - bottomPad - 2 * pad) / maxD)
        c.drawColor(0xFF1E1E1E.toInt())
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0xFF333333.toInt()
        var g = 0f
        while (g <= maxW) { c.drawLine(X(g), Y(0f), X(g), Y(maxD), p); g += 50f }
        g = 0f
        while (g <= maxD) { c.drawLine(X(0f), Y(g), X(maxW), Y(g), p); g += 50f }
        p.style = Paint.Style.FILL; p.color = 0xFF3A3A3A.toInt(); c.drawRect(X(0f), Y(0f), X(plan.w), Y(plan.d), p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = 0xFFEEEEEE.toInt(); c.drawRect(X(0f), Y(0f), X(plan.w), Y(plan.d), p)

        for (it in plan.items) {
            val (hx, hz) = SnapEngine.half(it.item, it.rotY)
            p.style = Paint.Style.FILL; p.color = color(it.item.category)
            c.drawRect(X(it.x - hx), Y(it.z - hz), X(it.x + hx), Y(it.z + hz), p)
            p.style = Paint.Style.STROKE; p.strokeWidth = if (it === selected) 6f else 2f
            p.color = if (it === selected) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
            c.drawRect(X(it.x - hx), Y(it.z - hz), X(it.x + hx), Y(it.z + hz), p)
            val r = Math.toRadians(it.rotY.toDouble()); val len = min(hx, hz) * 0.9f
            p.color = 0xFFFFEB3B.toInt(); p.strokeWidth = 4f
            c.drawLine(X(it.x), Y(it.z), X(it.x + sin(r).toFloat() * len), Y(it.z + cos(r).toFloat() * len), p)
            p.style = Paint.Style.FILL; p.color = 0xFF000000.toInt(); p.textSize = 24f; p.textAlign = Paint.Align.CENTER
            c.drawText(it.item.name, X(it.x), Y(it.z) + 8f, p)
        }
        p.style = Paint.Style.FILL; p.color = 0xFFFFB300.toInt(); c.drawCircle(X(plan.w), Y(plan.d), 22f, p)
        p.color = 0xFFFFFFFF.toInt(); p.textSize = 30f; p.textAlign = Paint.Align.LEFT
        c.drawText("${plan.w.toInt()} × ${plan.d.toInt()} سم", pad, height - bottomPad + 10f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val px = (e.x - pad) / s; val pz = (e.y - pad) / s
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (hypot(e.x - X(plan.w), e.y - Y(plan.d)) < 60f) mode = Mode.RESIZE
                else {
                    val hit = plan.items.lastOrNull {
                        val (hx, hz) = SnapEngine.half(it.item, it.rotY); abs(px - it.x) <= hx && abs(pz - it.z) <= hz
                    }
                    selected = hit; onSelected(hit); mode = if (hit != null) Mode.MOVE else Mode.NONE
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    Mode.RESIZE -> {
                        plan.w = ((px / 10f).roundToInt() * 10f).coerceIn(200f, maxW)
                        plan.d = ((pz / 10f).roundToInt() * 10f).coerceIn(200f, maxD)
                    }
                    Mode.MOVE -> selected?.let {
                        val sn = SnapEngine.snap(plan, it, px, pz); it.x = sn.x; it.z = sn.z; it.rotY = sn.rot; onItemMoved(it)
                    }
                    Mode.NONE -> {}
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (mode == Mode.RESIZE) onRoomResized(); if (mode == Mode.MOVE) onDrop(selected); mode = Mode.NONE }
        }
        return true
    }
}
