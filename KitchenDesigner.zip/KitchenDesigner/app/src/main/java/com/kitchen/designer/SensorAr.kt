package com.kitchen.designer

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.widget.FrameLayout
import com.kitchen.designer.engine.Renderer3D
import com.kitchen.designer.engine.SceneController
import com.kitchen.designer.model.Plan
import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.max

/**
 * "AR without Google services": a Camera2 preview + the phone's rotation sensor (3 degrees of freedom).
 * The camera sits at a fixed height above the floor (you set it), so a tap on the floor gives a real floor point and the room is
 * anchored there. Turn the phone around you and the room stays put. Walking is NOT tracked (use "re-anchor" after moving).
 * Scene world: X east, Y up, Z = -north (right-handed). Room space is derived from the tap point, like ArHelper.
 */
class SensorAr(private val act: Activity, private val preview: TextureView) {
    private val sm = act.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotSensor: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val rm = FloatArray(9).also { it[0] = 1f; it[4] = 1f; it[8] = 1f }
    var camHeight = 1.4f
    var fovV = 60.0
    var active = false
        private set
    var originSet = false
        private set
    private var ox = 0f
    private var oz = 0f
    private var xx = 1f
    private var xz = 0f
    private var zx = 0f
    private var zz = 1f
    private var camDev: CameraDevice? = null
    private var sess: CameraCaptureSession? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var camId = ""
    private var size = Size(1280, 960)

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) { SensorManager.getRotationMatrixFromVector(rm, e.values) }
        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    }

    /** Returns null on success or an error message. vw/vh = screen size used to centre-crop the preview. */
    fun start(vw: Int, vh: Int): String? {
        if (rotSensor == null) return "الجهاز لا يحتوي حساس الدوران المطلوب"
        try {
            val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK }
                ?: return "لا توجد كاميرا خلفية"
            val ch = cm.getCameraCharacteristics(id); camId = id
            val ps = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val fl = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            if (ps != null && fl != null) fovV = Math.toDegrees(2.0 * atan(max(ps.width, ps.height) / (2.0 * fl))).coerceIn(40.0, 100.0)
            val sizes = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.getOutputSizes(SurfaceTexture::class.java)
            if (sizes != null && sizes.isNotEmpty()) {
                size = sizes.filter { it.width * 3 == it.height * 4 && it.width <= 1600 }.maxByOrNull { it.width } ?: sizes.maxByOrNull { it.width * it.height }!!
            }
            val a = size.height.toFloat() / size.width            // portrait width/height (about 3/4)
            val pw: Int; val ph: Int
            if (vw.toFloat() / vh < a) { ph = vh; pw = (vh * a).toInt() } else { pw = vw; ph = (vw / a).toInt() }
            preview.layoutParams = FrameLayout.LayoutParams(pw, ph, Gravity.CENTER); preview.visibility = View.VISIBLE
            val t = HandlerThread("cam"); t.start(); thread = t; handler = Handler(t.looper)
            sm.registerListener(listener, rotSensor, SensorManager.SENSOR_DELAY_GAME)
            active = true
            if (preview.isAvailable) open() else preview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { open() }
                override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
                override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
                override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
            }
            return null
        } catch (e: Exception) { stop(); return "تعذر تشغيل الكاميرا (${e.javaClass.simpleName})" }
    }

    @SuppressLint("MissingPermission")
    private fun open() {
        try {
            val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) { camDev = c; startPreview(c) }
                override fun onDisconnected(c: CameraDevice) { c.close(); camDev = null }
                override fun onError(c: CameraDevice, error: Int) { c.close(); camDev = null }
            }, handler)
        } catch (e: Exception) { }
    }

    private fun startPreview(c: CameraDevice) {
        try {
            val st = preview.surfaceTexture ?: return
            st.setDefaultBufferSize(size.width, size.height)
            val surf = Surface(st)
            val req = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            req.addTarget(surf); req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            c.createCaptureSession(listOf(surf), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) { sess = s; try { s.setRepeatingRequest(req.build(), null, handler) } catch (e: Exception) { } }
                override fun onConfigureFailed(s: CameraCaptureSession) {}
            }, handler)
        } catch (e: Exception) { }
    }

    fun pause() {
        sm.unregisterListener(listener)
        try { sess?.close() } catch (e: Exception) { }
        try { camDev?.close() } catch (e: Exception) { }
        sess = null; camDev = null
    }

    fun resume() {
        if (!active) return
        sm.registerListener(listener, rotSensor, SensorManager.SENSOR_DELAY_GAME)
        if (preview.isAvailable) open()
    }

    fun stop() {
        pause(); active = false; originSet = false; preview.visibility = View.GONE
        thread?.quitSafely(); thread = null; handler = null
    }

    fun resetOrigin() { originSet = false }

    // scene-world forward / up from the rotation matrix (device -> ENU world): ENU (x,y,z) -> scene (x, z, -y)
    private fun forward() = floatArrayOf(-rm[2], -rm[8], rm[5])
    private fun upVec() = floatArrayOf(rm[1], rm[7], -rm[4])

    /** Tap on the floor: the room's centre goes there and its back wall faces the viewing direction. */
    fun tapFloor(x: Float, y: Float, w: Int, h: Int, sc: SceneController, plan: Plan): Boolean {
        val p = sc.floorPoint(x, y, w, h) ?: return false
        val hx = p.first / 100f; val hz = p.second / 100f
        val f = forward()
        var fx = f[0]; var fz = f[2]
        val l = hypot(fx.toDouble(), fz.toDouble()).toFloat()
        if (l < 1e-3f) return false
        fx /= l; fz /= l
        zx = -fx; zz = -fz; xx = zz; xz = -zx
        ox = hx - xx * plan.w / 200f - zx * plan.d / 200f
        oz = hz - xz * plan.w / 200f - zz * plan.d / 200f
        originSet = true
        return true
    }

    /** Every frame: camera pose (in room space once anchored) from the sensors. */
    fun update(r: Renderer3D) {
        if (!active) return
        val eye = floatArrayOf(0f, camHeight, 0f)
        fun pt(p: FloatArray): DoubleArray {
            if (!originSet) return doubleArrayOf(p[0].toDouble(), p[1].toDouble(), p[2].toDouble())
            val dx = p[0] - ox; val dz = p[2] - oz
            return doubleArrayOf((dx * xx + dz * xz).toDouble(), p[1].toDouble(), (dx * zx + dz * zz).toDouble())
        }
        fun dir(d: FloatArray): DoubleArray {
            if (!originSet) return doubleArrayOf(d[0].toDouble(), d[1].toDouble(), d[2].toDouble())
            return doubleArrayOf((d[0] * xx + d[2] * xz).toDouble(), d[1].toDouble(), (d[0] * zx + d[2] * zz).toDouble())
        }
        val e = pt(eye); val f = dir(forward())
        r.eye = e; r.look = doubleArrayOf(e[0] + f[0] * 3, e[1] + f[1] * 3, e[2] + f[2] * 3); r.up = dir(upVec()); r.fovV = fovV
    }
}
