package com.kitchen.designer.engine

import android.view.Surface
import android.view.TextureView
import com.google.android.filament.*
import com.google.android.filament.android.UiHelper
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

object Quality {
    fun apply(engine: Engine, view: View) {
        view.ambientOcclusionOptions = View.AmbientOcclusionOptions().apply { enabled = true; radius = 0.6f; intensity = 1.2f }
        view.bloomOptions = View.BloomOptions().apply { enabled = true; strength = 0.12f }
        view.multiSampleAntiAliasingOptions = View.MultiSampleAntiAliasingOptions().apply { enabled = true; sampleCount = 4 }
        view.dynamicResolutionOptions = View.DynamicResolutionOptions().apply { enabled = true }
        view.renderQuality = View.RenderQuality().apply { hdrColorBuffer = View.QualityLevel.HIGH }
        view.colorGrading = ColorGrading.Builder().toneMapper(ToneMapper.ACES()).contrast(1.08f).saturation(1.05f).build(engine)
    }
}

/** Own Filament render loop on a TextureView (so it can be translucent over a photo). Orbit camera, or a fixed calibrated photo camera. */
class Renderer3D(tv: TextureView) {
    val engine: Engine = Engine.create()
    val renderer: Renderer = engine.createRenderer()
    val scene: Scene = engine.createScene()
    val view: View = engine.createView()
    val camera: Camera = engine.createCamera(EntityManager.get().create())
    val sun: Int = EntityManager.get().create()
    private val ui = UiHelper(UiHelper.ContextErrorPolicy.DONT_CHECK)
    private var swap: SwapChain? = null
    private var w = 1
    private var h = 1

    val target = floatArrayOf(2f, 0.7f, 1.5f)
    var yaw = 0.35f
    var pitch = 0.5f
    var dist = 6.5f
    var photoMode = false
    var arMode = false                 // live ARCore camera: pose + projection come from ARCore (room space)
    var arModel: DoubleArray? = null
    var arProj: DoubleArray? = null
    var eye = DoubleArray(3)
    var look = DoubleArray(3)
    var up = doubleArrayOf(0.0, 1.0, 0.0)
    var fovV = 50.0
    private var sunAz = 0.4f

    init {
        view.scene = scene; view.camera = camera
        ui.isOpaque = false
        ui.renderCallback = object : UiHelper.RendererCallback {
            override fun onNativeWindowChanged(surface: Surface) {
                swap?.let { engine.destroySwapChain(it) }
                swap = engine.createSwapChain(surface, ui.swapChainFlags)
            }
            override fun onDetachedFromSurface() {
                swap?.let { engine.destroySwapChain(it); engine.flushAndWait() }
                swap = null
            }
            override fun onResized(width: Int, height: Int) { w = width; h = height; view.viewport = Viewport(0, 0, width, height) }
        }
        ui.attachTo(tv)
        LightManager.Builder(LightManager.Type.SUN).color(0.98f, 0.96f, 0.92f).intensity(90_000f).direction(-0.35f, -1f, -0.45f).castShadows(true).build(engine, sun)
        scene.addEntity(sun)
        setPhoto(false)
    }

    fun setPhoto(on: Boolean) {
        photoMode = on
        view.blendMode = if (on) View.BlendMode.TRANSLUCENT else View.BlendMode.OPAQUE
        renderer.clearOptions = Renderer.ClearOptions().apply {
            clear = true
            clearColor = if (on) floatArrayOf(0f, 0f, 0f, 0f) else floatArrayOf(0.82f, 0.85f, 0.88f, 1f)
        }
    }

    fun setLight(level: Float) {
        scene.indirectLight?.intensity = 30_000f * level
        val lm = engine.lightManager; lm.setIntensity(lm.getInstance(sun), 90_000f * level)
    }

    fun setSunAzimuth(deg: Float) {
        sunAz = Math.toRadians(deg.toDouble()).toFloat()
        val x = sin(sunAz) * 0.5f; val z = cos(sunAz) * 0.5f; val n = sqrt(x * x + 1f + z * z)
        val lm = engine.lightManager; lm.setDirection(lm.getInstance(sun), -x / n, -1f / n, -z / n)
    }

    fun render(nanos: Long) {
        if (!ui.isReadyToRender) return
        val sc = swap ?: return
        val aspect = w.toDouble() / max(h, 1)
        if (arMode) {
            val m = arModel; val pj = arProj
            if (m == null || pj == null) return
            camera.setCustomProjection(pj, 0.05, 50.0); camera.setModelMatrix(m)
        } else if (photoMode) {
            camera.setProjection(fovV, aspect, 0.05, 80.0, Camera.Fov.VERTICAL)
            camera.lookAt(eye[0], eye[1], eye[2], look[0], look[1], look[2], up[0], up[1], up[2])
        } else {
            camera.setProjection(45.0, aspect, 0.05, 80.0, Camera.Fov.VERTICAL)
            val cp = cos(pitch)
            camera.lookAt((target[0] + dist * cp * sin(yaw)).toDouble(), (target[1] + dist * sin(pitch)).toDouble(), (target[2] + dist * cp * cos(yaw)).toDouble(),
                target[0].toDouble(), target[1].toDouble(), target[2].toDouble(), 0.0, 1.0, 0.0)
        }
        if (renderer.beginFrame(sc, nanos)) { renderer.render(view); renderer.endFrame() }
    }
}
