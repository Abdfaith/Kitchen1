package com.kitchen.designer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import com.kitchen.designer.engine.Calib
import kotlin.math.abs
import kotlin.math.hypot

/** Transparent layer over the photo/3D: freehand drawing, eraser, line straightening (snaps to vanishing directions), and floor-corner marking. */
class DrawView(ctx: Context) : View(ctx) {
    enum class Mode { OFF, DRAW, ERASE, MARK }

    class Stroke(var pts: List<PointF>, val color: Int, val w: Float)

    var mode = Mode.OFF
    var color = Color.RED
    var width = 6f
    var straighten = false
    var calib: Calib? = null
    var showGrid = false
    var gridW = 4.0
    var gridD = 3.0
    private val strokes = mutableListOf<Stroke>()
    private val redo = mutableListOf<Stroke>()
    private var cur: Stroke? = null
    private val marks = mutableListOf<PointF>()
    private var onMarked: ((List<PointF>) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }

    fun beginMark(cb: (List<PointF>) -> Unit) { marks.clear(); onMarked = cb; mode = Mode.MARK; invalidate() }
    fun undo() { if (strokes.isNotEmpty()) { redo.add(strokes.removeAt(strokes.size - 1)); invalidate() } }
    fun redoStroke() { if (redo.isNotEmpty()) { strokes.add(redo.removeAt(redo.size - 1)); invalidate() } }
    fun clearAll() { strokes.clear(); redo.clear(); invalidate() }

    private fun straight(a: PointF, b: PointF): List<PointF> {
        val dx = b.x - a.x; val dy = b.y - a.y; val len = hypot(dx, dy)
        if (len < 8f) return listOf(a, b)
        val dirs = mutableListOf(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f))
        val c = calib
        if (c != null) for (axis in 0..1) {
            val v = c.dirTo(axis, a.x.toDouble(), a.y.toDouble())
            if (v != null) dirs.add(floatArrayOf(v[0].toFloat(), v[1].toFloat()))
        }
        var best: FloatArray? = null; var bc = 0f
        for (d in dirs) { val cs = abs(dx * d[0] + dy * d[1]) / len; if (cs > bc) { bc = cs; best = d } }
        if (best != null && bc > 0.966f) {
            val proj = dx * best[0] + dy * best[1]
            return listOf(a, PointF(a.x + best[0] * proj, a.y + best[1] * proj))
        }
        return listOf(a, b)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (mode) {
            Mode.OFF -> return false
            Mode.MARK -> {
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    marks.add(PointF(e.x, e.y)); invalidate()
                    if (marks.size == 4) { mode = Mode.OFF; onMarked?.invoke(marks.toList()) }
                }
                return true
            }
            Mode.ERASE -> {
                if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                    val it = strokes.iterator()
                    while (it.hasNext()) { val s = it.next(); if (s.pts.any { p -> hypot(p.x - e.x, p.y - e.y) < 28f }) { it.remove(); invalidate() } }
                }
                return true
            }
            Mode.DRAW -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { cur = Stroke(mutableListOf(PointF(e.x, e.y)), color, width) }
                    MotionEvent.ACTION_MOVE -> { (cur?.pts as? MutableList<PointF>)?.add(PointF(e.x, e.y)); invalidate() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val s = cur
                        if (s != null && s.pts.size > 1) {
                            if (straighten) s.pts = straight(s.pts.first(), s.pts.last())
                            strokes.add(s); redo.clear()
                        }
                        cur = null; invalidate()
                    }
                }
                return true
            }
        }
        return false
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        paint.color = s.color; paint.strokeWidth = s.w
        val path = Path(); val p0 = s.pts.first(); path.moveTo(p0.x, p0.y)
        for (i in 1 until s.pts.size) path.lineTo(s.pts[i].x, s.pts[i].y)
        c.drawPath(path, paint)
    }

    override fun onDraw(c: Canvas) {
        val cal = calib
        if (showGrid && cal != null) {
            paint.color = 0xAA00E5FF.toInt(); paint.strokeWidth = 2f
            var x = 0.0
            while (x <= gridW + 1e-6) { val a = cal.project(x, 0.0); val b = cal.project(x, gridD); c.drawLine(a[0].toFloat(), a[1].toFloat(), b[0].toFloat(), b[1].toFloat(), paint); x += 0.5 }
            var z = 0.0
            while (z <= gridD + 1e-6) { val a = cal.project(0.0, z); val b = cal.project(gridW, z); c.drawLine(a[0].toFloat(), a[1].toFloat(), b[0].toFloat(), b[1].toFloat(), paint); z += 0.5 }
        }
        for (s in strokes) drawStroke(c, s)
        cur?.let { if (it.pts.size > 1) drawStroke(c, it) }
        if (mode == Mode.MARK) {
            paint.style = Paint.Style.FILL; paint.textSize = 34f
            for ((i, p) in marks.withIndex()) { paint.color = 0xFFFFB300.toInt(); c.drawCircle(p.x, p.y, 16f, paint); paint.color = Color.BLACK; c.drawText("${i + 1}", p.x - 8f, p.y + 12f, paint) }
            paint.style = Paint.Style.STROKE
        }
    }
}
