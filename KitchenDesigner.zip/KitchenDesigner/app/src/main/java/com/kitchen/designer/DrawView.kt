package com.kitchen.designer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.kitchen.designer.engine.Calib
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Transparent layer over the photo + 3D: pressure-sensitive smoothed strokes, eraser, magnetic straightening that snaps to
 * vanishing directions (calibrated floor axes and auto-detected vanishing points), perspective fan grid, LED glow, corner marking,
 * and region selection for material coating (CoatView).
 */
class DrawView(ctx: Context) : View(ctx) {
    enum class Mode { OFF, DRAW, ERASE, MARK, COAT }

    class Stroke(val pts: MutableList<PointF>, val ws: MutableList<Float>, val color: Int, val w: Float)

    var mode = Mode.OFF
    var color = Color.RED
    var penSize = 6f
    var straighten = false
    var calib: Calib? = null
    var showGrid = false
    var gridW = 4.0
    var gridD = 3.0
    var vps: List<DoubleArray> = emptyList()      // auto-detected vanishing points (pixels)
    var fan = false
    var glowSource: (() -> List<DoubleArray>)? = null   // world points (m) that emit warm light
    var glowColor = floatArrayOf(1f, 0.8f, 0.5f)
    var onCoat: ((List<PointF>) -> Unit)? = null
    private val strokes = mutableListOf<Stroke>()
    private val redo = mutableListOf<Stroke>()
    private var cur: Stroke? = null
    private var pressureOn = false
    private val marks = mutableListOf<PointF>()
    private var onMarked: ((List<PointF>) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun beginMark(cb: (List<PointF>) -> Unit) { marks.clear(); onMarked = cb; mode = Mode.MARK; invalidate() }
    fun undo() { if (strokes.isNotEmpty()) { redo.add(strokes.removeAt(strokes.size - 1)); invalidate() } }
    fun redoStroke() { if (redo.isNotEmpty()) { strokes.add(redo.removeAt(redo.size - 1)); invalidate() } }
    fun clearAll() { strokes.clear(); redo.clear(); invalidate() }

    /** Magnetic snap: if the stroke direction is within ~15 degrees of a perspective direction at its start point, make it perfectly straight along it. */
    private fun straight(a: PointF, b: PointF): List<PointF> {
        val dx = b.x - a.x; val dy = b.y - a.y; val len = hypot(dx, dy)
        if (len < 8f) return listOf(a, b)
        val dirs = mutableListOf(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f))
        val c = calib
        if (c != null) for (axis in 0..1) {
            val v = c.dirTo(axis, a.x.toDouble(), a.y.toDouble())
            if (v != null) dirs.add(floatArrayOf(v[0].toFloat(), v[1].toFloat()))
        }
        for (vp in vps) {
            val vx = vp[0] - a.x; val vy = vp[1] - a.y; val l = hypot(vx, vy)
            if (l > 1.0) dirs.add(floatArrayOf((vx / l).toFloat(), (vy / l).toFloat()))
        }
        var best: FloatArray? = null; var bc = 0f
        for (d in dirs) { val cs = abs(dx * d[0] + dy * d[1]) / len; if (cs > bc) { bc = cs; best = d } }
        if (best != null && bc > 0.966f) {
            val proj = dx * best[0] + dy * best[1]
            return listOf(a, PointF(a.x + best[0] * proj, a.y + best[1] * proj))
        }
        return listOf(a, b)
    }

    private fun wOf(p: Float) = if (pressureOn) penSize * (0.35f + 1.3f * p.coerceIn(0f, 1f)) else penSize

    /** Exponential smoothing of position and width -> clean curves from a shaky hand. */
    private fun addPoint(x: Float, y: Float, p: Float) {
        val s = cur ?: return
        val l = s.pts.last()
        s.pts.add(PointF(l.x * 0.55f + x * 0.45f, l.y * 0.55f + y * 0.45f)); s.ws.add(s.ws.last() * 0.6f + wOf(p) * 0.4f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (mode) {
            Mode.OFF -> return false
            Mode.MARK -> {
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    marks.add(PointF(e.x, e.y)); invalidate()
                    if (marks.size == 4) { mode = Mode.OFF; onMarked?.invoke(marks.toList()) }
                }
                return true
            }
            Mode.ERASE -> {
                if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                    val itr = strokes.iterator()
                    while (itr.hasNext()) { val s = itr.next(); if (s.pts.any { p -> hypot(p.x - e.x, p.y - e.y) < 28f }) { itr.remove(); invalidate() } }
                }
                return true
            }
            Mode.DRAW, Mode.COAT -> {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        pressureOn = mode == Mode.DRAW && e.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                        cur = Stroke(mutableListOf(PointF(e.x, e.y)), mutableListOf(wOf(e.pressure)), if (mode == Mode.COAT) 0xFFF59E0B.toInt() else color, penSize)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        for (i in 0 until e.historySize) addPoint(e.getHistoricalX(i), e.getHistoricalY(i), e.getHistoricalPressure(i))
                        addPoint(e.x, e.y, e.pressure); invalidate()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val s = cur
                        if (s != null && mode == Mode.COAT) { if (s.pts.size >= 3) onCoat?.invoke(s.pts.toList()) }
                        else if (s != null && s.pts.size > 1) {
                            if (straighten) {
                                val st = straight(s.pts.first(), s.pts.last()); val avg = s.ws.average().toFloat()
                                s.pts.clear(); s.pts.addAll(st); s.ws.clear(); s.ws.add(avg); s.ws.add(avg)
                            }
                            strokes.add(s); redo.clear()
                        }
                        cur = null; invalidate()
                    }
                }
                return true
            }
        }
        return false
    }

    private fun drawStroke(c: Canvas, s: Stroke) {
        paint.color = s.color
        for (i in 1 until s.pts.size) { paint.strokeWidth = s.ws[i]; val a = s.pts[i - 1]; val b = s.pts[i]; c.drawLine(a.x, a.y, b.x, b.y, paint) }
    }

    private fun glowArgb(a: Int) = Color.argb(a, (glowColor[0] * 255).toInt(), (glowColor[1] * 255).toInt(), (glowColor[2] * 255).toInt())

    override fun onDraw(c: Canvas) {
        val cal = calib
        val gs = glowSource
        if (cal != null && gs != null) for (g in gs()) {
            val p = cal.project3D(g[0], g[1], g[2]) ?: continue
            val r = (p[2] * 0.45).toFloat().coerceIn(20f, 700f)
            glowPaint.shader = RadialGradient(p[0].toFloat(), p[1].toFloat(), r, intArrayOf(glowArgb(150), glowArgb(60), glowArgb(0)), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(p[0].toFloat(), p[1].toFloat(), r, glowPaint)
        }
        paint.style = Paint.Style.STROKE
        if (fan) for (vp in vps) {
            paint.color = 0x660284C7.toInt(); paint.strokeWidth = 1.5f
            val n = 28; val w = this.getWidth().toFloat(); val h = this.getHeight().toFloat()
            for (i in 0..n) {
                val t = i / n.toFloat()
                c.drawLine(vp[0].toFloat(), vp[1].toFloat(), w * t, 0f, paint); c.drawLine(vp[0].toFloat(), vp[1].toFloat(), w * t, h, paint)
                c.drawLine(vp[0].toFloat(), vp[1].toFloat(), 0f, h * t, paint); c.drawLine(vp[0].toFloat(), vp[1].toFloat(), w, h * t, paint)
            }
        }
        if (showGrid && cal != null) {
            paint.color = 0xAA00E5FF.toInt(); paint.strokeWidth = 2f
            var x = 0.0
            while (x <= gridW + 1e-6) { val a = cal.project(x, 0.0); val b = cal.project(x, gridD); c.drawLine(a[0].toFloat(), a[1].toFloat(), b[0].toFloat(), b[1].toFloat(), paint); x += 0.5 }
            var z = 0.0
            while (z <= gridD + 1e-6) { val a = cal.project(0.0, z); val b = cal.project(gridW, z); c.drawLine(a[0].toFloat(), a[1].toFloat(), b[0].toFloat(), b[1].toFloat(), paint); z += 0.5 }
        }
        for (s in strokes) drawStroke(c, s)
        cur?.let { if (it.pts.size > 1) drawStroke(c, it) }
        if (mode == Mode.MARK) {
            paint.style = Paint.Style.FILL; paint.textSize = 34f
            for ((i, p) in marks.withIndex()) { paint.color = 0xFFFFB300.toInt(); c.drawCircle(p.x, p.y, 16f, paint); paint.color = Color.BLACK; c.drawText("${i + 1}", p.x - 8f, p.y + 12f, paint) }
            paint.style = Paint.Style.STROKE
        }
    }
}

/**
 * Material coating under the 3D layer. Each region redraws the photo clipped to the region and blends a texture over it with
 * MULTIPLY (tints, keeps shadows) or OVERLAY (keeps contrast), so walls/cabinets in the photo take the new material seamlessly.
 */
class CoatView(ctx: Context) : View(ctx) {
    class Region(val pts: List<PointF>, val tex: android.graphics.Bitmap?, val color: Int, val mode: android.graphics.PorterDuff.Mode)

    var base: android.graphics.Bitmap? = null
    private val regions = mutableListOf<Region>()

    fun add(r: Region) { regions.add(r); invalidate() }
    fun undo() { if (regions.isNotEmpty()) { regions.removeAt(regions.size - 1); invalidate() } }
    fun clearAll() { regions.clear(); invalidate() }

    override fun onDraw(c: Canvas) {
        val b = base ?: return
        val w = this.getWidth(); val h = this.getHeight()
        val dst = android.graphics.Rect(0, 0, w, h)
        for (r in regions) {
            val path = Path(); path.moveTo(r.pts[0].x, r.pts[0].y)
            for (i in 1 until r.pts.size) path.lineTo(r.pts[i].x, r.pts[i].y)
            path.close()
            c.save(); c.clipPath(path)
            c.drawBitmap(b, null, dst, null)
            val p = Paint(Paint.ANTI_ALIAS_FLAG); p.xfermode = android.graphics.PorterDuffXfermode(r.mode)
            val t = r.tex
            if (t != null) {
                val sh = android.graphics.BitmapShader(t, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
                val m = android.graphics.Matrix(); val k = (w * 0.25f) / t.width; m.setScale(k, k); sh.setLocalMatrix(m); p.shader = sh
            } else p.color = r.color
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.restore()
        }
    }
}
