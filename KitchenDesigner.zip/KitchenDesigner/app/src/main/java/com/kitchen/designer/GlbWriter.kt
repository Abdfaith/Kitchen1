package com.kitchen.designer

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Builds binary glTF (.glb) files in memory: a photo cut-out standing upright, or a mesh converted from OBJ text. */
object GlbWriter {
    private fun pack(json: String, bin: ByteArray): ByteArray {
        val js = json.toByteArray(Charsets.UTF_8); val jp = (4 - js.size % 4) % 4; val bp = (4 - bin.size % 4) % 4
        val total = 12 + 8 + js.size + jp + 8 + bin.size + bp
        val b = ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(0x46546C67); b.putInt(2); b.putInt(total)
        b.putInt(js.size + jp); b.putInt(0x4E4F534A); b.put(js); repeat(jp) { b.put(0x20.toByte()) }
        b.putInt(bin.size + bp); b.putInt(0x004E4942); b.put(bin); repeat(bp) { b.put(0.toByte()) }
        return b.array()
    }

    /** Upright double-sided photo quad, wM x hM metres, origin at bottom-centre. Transparent pixels are cut out (alpha mask). */
    fun photoQuad(bmp: Bitmap, wM: Float, hM: Float): ByteArray {
        val png = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
        val pos = floatArrayOf(-wM / 2, 0f, 0f, wM / 2, 0f, 0f, wM / 2, hM, 0f, -wM / 2, hM, 0f)
        val nor = floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f)
        val uv = floatArrayOf(0f, 1f, 1f, 1f, 1f, 0f, 0f, 0f)
        val bb = ByteBuffer.allocate(12 + 48 + 48 + 32 + png.size).order(ByteOrder.LITTLE_ENDIAN)
        for (i in intArrayOf(0, 1, 2, 0, 2, 3)) bb.putShort(i.toShort())
        pos.forEach { bb.putFloat(it) }; nor.forEach { bb.putFloat(it) }; uv.forEach { bb.putFloat(it) }; bb.put(png)
        val json = """{"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0}],
"meshes":[{"primitives":[{"attributes":{"POSITION":1,"NORMAL":2,"TEXCOORD_0":3},"indices":0,"material":0}]}],
"materials":[{"name":"photo","pbrMetallicRoughness":{"baseColorTexture":{"index":0},"metallicFactor":0,"roughnessFactor":0.9},"alphaMode":"MASK","alphaCutoff":0.5,"doubleSided":true}],
"textures":[{"source":0,"sampler":0}],"samplers":[{"magFilter":9729,"minFilter":9987,"wrapS":33071,"wrapT":33071}],"images":[{"bufferView":4,"mimeType":"image/png"}],
"accessors":[{"bufferView":0,"componentType":5123,"count":6,"type":"SCALAR"},
{"bufferView":1,"componentType":5126,"count":4,"type":"VEC3","min":[${-wM / 2},0,0],"max":[${wM / 2},$hM,0]},
{"bufferView":2,"componentType":5126,"count":4,"type":"VEC3"},{"bufferView":3,"componentType":5126,"count":4,"type":"VEC2"}],
"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":12,"target":34963},{"buffer":0,"byteOffset":12,"byteLength":48,"target":34962},
{"buffer":0,"byteOffset":60,"byteLength":48,"target":34962},{"buffer":0,"byteOffset":108,"byteLength":32,"target":34962},{"buffer":0,"byteOffset":140,"byteLength":${png.size}}],
"buffers":[{"byteLength":${bb.capacity()}}]}"""
        return pack(json, bb.array())
    }

    /** Non-indexed triangle soup with per-corner position/normal/uv -> glb (grey double-sided material). */
    fun mesh(pos: FloatArray, nor: FloatArray, uv: FloatArray): ByteArray {
        val n = pos.size / 3
        var mnx = Float.MAX_VALUE; var mny = Float.MAX_VALUE; var mnz = Float.MAX_VALUE; var mxx = -Float.MAX_VALUE; var mxy = -Float.MAX_VALUE; var mxz = -Float.MAX_VALUE
        for (i in 0 until n) {
            mnx = minOf(mnx, pos[3 * i]); mxx = maxOf(mxx, pos[3 * i]); mny = minOf(mny, pos[3 * i + 1]); mxy = maxOf(mxy, pos[3 * i + 1]); mnz = minOf(mnz, pos[3 * i + 2]); mxz = maxOf(mxz, pos[3 * i + 2])
        }
        val bb = ByteBuffer.allocate(n * 4 + n * 12 + n * 12 + n * 8).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putInt(i)
        pos.forEach { bb.putFloat(it) }; nor.forEach { bb.putFloat(it) }; uv.forEach { bb.putFloat(it) }
        val json = """{"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0}],
"meshes":[{"primitives":[{"attributes":{"POSITION":1,"NORMAL":2,"TEXCOORD_0":3},"indices":0,"material":0}]}],
"materials":[{"name":"imported","pbrMetallicRoughness":{"baseColorFactor":[0.78,0.78,0.78,1],"metallicFactor":0,"roughnessFactor":0.7},"doubleSided":true}],
"accessors":[{"bufferView":0,"componentType":5125,"count":$n,"type":"SCALAR"},
{"bufferView":1,"componentType":5126,"count":$n,"type":"VEC3","min":[$mnx,$mny,$mnz],"max":[$mxx,$mxy,$mxz]},
{"bufferView":2,"componentType":5126,"count":$n,"type":"VEC3"},{"bufferView":3,"componentType":5126,"count":$n,"type":"VEC2"}],
"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":${n * 4},"target":34963},{"buffer":0,"byteOffset":${n * 4},"byteLength":${n * 12},"target":34962},
{"buffer":0,"byteOffset":${n * 16},"byteLength":${n * 12},"target":34962},{"buffer":0,"byteOffset":${n * 28},"byteLength":${n * 8},"target":34962}],
"buffers":[{"byteLength":${bb.capacity()}}]}"""
        return pack(json, bb.array())
    }
}

object ObjToGlb {
    fun convert(text: String): ByteArray {
        val v = ArrayList<FloatArray>(); val vn = ArrayList<FloatArray>(); val vt = ArrayList<FloatArray>()
        val pp = ArrayList<Float>(); val nn = ArrayList<Float>(); val tt = ArrayList<Float>()
        fun idx(s: String, n: Int): Int { val k = s.toInt(); return if (k > 0) k - 1 else n + k }
        for (raw in text.lineSequence()) {
            val ln = raw.trim(); if (ln.isEmpty() || ln[0] == '#') continue
            val t = ln.split(Regex("\\s+"))
            when (t[0]) {
                "v" -> v.add(floatArrayOf(t[1].toFloat(), t[2].toFloat(), t[3].toFloat()))
                "vn" -> vn.add(floatArrayOf(t[1].toFloat(), t[2].toFloat(), t[3].toFloat()))
                "vt" -> vt.add(floatArrayOf(t[1].toFloat(), if (t.size > 2) t[2].toFloat() else 0f))
                "f" -> {
                    val c = t.size - 1; val pi = IntArray(c); val ti = IntArray(c); val ni = IntArray(c)
                    for (i in 0 until c) {
                        val parts = t[i + 1].split("/")
                        pi[i] = idx(parts[0], v.size)
                        ti[i] = if (parts.size > 1 && parts[1].isNotEmpty()) idx(parts[1], vt.size) else -1
                        ni[i] = if (parts.size > 2 && parts[2].isNotEmpty()) idx(parts[2], vn.size) else -1
                    }
                    for (i in 1 until c - 1) {
                        val tri = intArrayOf(0, i, i + 1)
                        val a = v[pi[tri[0]]]; val b = v[pi[tri[1]]]; val d = v[pi[tri[2]]]
                        val e1 = floatArrayOf(b[0] - a[0], b[1] - a[1], b[2] - a[2]); val e2 = floatArrayOf(d[0] - a[0], d[1] - a[1], d[2] - a[2])
                        var fx = e1[1] * e2[2] - e1[2] * e2[1]; var fy = e1[2] * e2[0] - e1[0] * e2[2]; var fz = e1[0] * e2[1] - e1[1] * e2[0]
                        val l = Math.sqrt((fx * fx + fy * fy + fz * fz).toDouble()).toFloat().coerceAtLeast(1e-12f); fx /= l; fy /= l; fz /= l
                        for (k in tri) {
                            val p = v[pi[k]]; pp.add(p[0]); pp.add(p[1]); pp.add(p[2])
                            if (ni[k] >= 0) { val q = vn[ni[k]]; nn.add(q[0]); nn.add(q[1]); nn.add(q[2]) } else { nn.add(fx); nn.add(fy); nn.add(fz) }
                            if (ti[k] >= 0) { val q = vt[ti[k]]; tt.add(q[0]); tt.add(1f - q[1]) } else { tt.add(0f); tt.add(0f) }
                        }
                    }
                }
            }
        }
        if (pp.isEmpty()) throw IllegalArgumentException("OBJ is empty")
        if (pp.size / 3 > 900_000) throw IllegalArgumentException("OBJ too large")
        return GlbWriter.mesh(pp.toFloatArray(), nn.toFloatArray(), tt.toFloatArray())
    }
}
