package com.kitchen.designer

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.android.filament.utils.Utils
import com.kitchen.designer.engine.Calib
import com.kitchen.designer.engine.PhotoCalib
import com.kitchen.designer.engine.Renderer3D
import com.kitchen.designer.engine.SceneController
import com.kitchen.designer.model.*
import java.io.File
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URL
import kotlin.math.max
import kotlin.math.min
import org.json.JSONObject

/** Any touch inside the menus re-arms the auto-hide timer. */
class TouchBox(ctx: android.content.Context, val onTouch: () -> Unit) : LinearLayout(ctx) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean { onTouch(); return super.dispatchTouchEvent(ev) }
}

class MainActivity : Activity() {
    companion object {
        init { Utils.init() }
        const val REQ_BG_CAM = 1
        const val REQ_BG_GAL = 2
        const val REQ_OBJ_CAM = 3
        const val REQ_OBJ_GAL = 4
        const val REQ_IMPORT = 5
    }

    private val plan = Plan(400f, 300f, 260f)
    private lateinit var tv: TextureView
    private lateinit var r3d: Renderer3D
    private lateinit var sc: SceneController
    private lateinit var stage: FrameLayout
    private lateinit var bg: ImageView
    private lateinit var pen: DrawView
    private lateinit var editor: PlanEditorView
    private lateinit var root: FrameLayout
    private lateinit var topBar: HorizontalScrollView
    private lateinit var uiBox: TouchBox
    private lateinit var panel: FrameLayout
    private lateinit var fab: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val choreographer = Choreographer.getInstance()
    private val prefs by lazy { getSharedPreferences("ui", MODE_PRIVATE) }
    private val store by lazy { File(filesDir, "project.json") }
    private var autoHide = true
    private var currentTab = 0
    private val tabNames = listOf("العناصر", "الخامات", "الصورة", "الرسم", "تصدير", "واقعي", "إعدادات")
    private var lastJson: JSONObject? = null
    private var curGroup = ""
    private var matTarget = "main"
    private var matGroup = ""
    private var uid = 0
    private var selected: PlacedItem? = null
    private var dragging: PlacedItem? = null
    private var dragMoved = false
    private var lx = 0f
    private var ly = 0f
    private var lastT = 0L
    private var photoBmp: Bitmap? = null
    private var marks: List<PointF> = emptyList()
    private var camFile: File? = null
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private val iconCache = HashMap<String, Bitmap?>()
    private val thumbCache = HashMap<String, Bitmap?>()

    private val hideRun = Runnable { hideUiNow() }
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            choreographer.postFrameCallback(this)
            val dt = if (lastT == 0L) 0.016f else ((t - lastT) / 1e9f).coerceIn(0f, 0.1f)
            lastT = t; sc.tick(dt); r3d.render(t)
        }
    }
    private val scaleDet by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { if (!r3d.photoMode) r3d.dist = (r3d.dist / d.scaleFactor).coerceIn(1.5f, 25f); return true }
        })
    }

    // =============================================================== lifecycle
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Catalog.load(this); Materials.load(this)
        autoHide = prefs.getBoolean("autohide", true)
        tv = TextureView(this); r3d = Renderer3D(tv); sc = SceneController(this, r3d)
        if (store.exists()) try { plan.restore(store.readText()) } catch (e: Exception) { }
        uid = (plan.items.maxOfOrNull { it.uid } ?: -1) + 1
        sc.buildRoom(plan); plan.items.forEach { sc.place(it) }
        tv.setOnTouchListener { v, e -> onStageTouch(v, e) }
        pen = DrawView(this)
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY; visibility = View.GONE }
        stage = FrameLayout(this).apply {
            addView(bg, FrameLayout.LayoutParams(-1, -1)); addView(tv, FrameLayout.LayoutParams(-1, -1)); addView(pen, FrameLayout.LayoutParams(-1, -1))
        }
        editor = PlanEditorView(this, plan).apply {
            visibility = View.GONE
            onSelected = { if (it != null) snapshot(); selected = it }
            onItemMoved = { sc.update(it) }
            onDrop = { if (it?.item?.category == Category.OPENING) sc.buildRoom(plan) }
            onRoomResized = { plan.items.forEach { i -> resnap(i) }; sc.buildRoom(plan); if (marks.size == 4) runCalib(); invalidate() }
        }
        root = FrameLayout(this).apply {
            setBackgroundColor(0xFF15181C.toInt())
            addView(stage, FrameLayout.LayoutParams(-1, -1)); addView(editor, FrameLayout.LayoutParams(-1, -1))
        }
        buildUi(); setContentView(root)
    }

    override fun onResume() { super.onResume(); lastT = 0L; choreographer.postFrameCallback(frame) }
    override fun onPause() { super.onPause(); choreographer.removeFrameCallback(frame); save() }
    override fun onBackPressed() { if (editor.visibility == View.VISIBLE) editor.visibility = View.GONE else super.onBackPressed() }

    // =============================================================== UI helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun round(c: Int, r: Int = 18) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun chip(text: String, on: Boolean = false, click: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7)); background = round(if (on) 0xFF1E88E5.toInt() else 0xFF3A3F47.toInt())
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { click(); ping() }
    }

    private fun label(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER }

    private fun hrow(vararg v: View): HorizontalScrollView = HorizontalScrollView(this).apply {
        isHorizontalScrollBarEnabled = false
        addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) } })
    }

    private fun vcol(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }

    private fun seek(title: String, maxV: Int, init: Int, on: (Int) -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(label(title, 12f).apply { layoutParams = LinearLayout.LayoutParams(dp(64), -2) })
        addView(SeekBar(this@MainActivity).apply {
            max = maxV; progress = init; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { on(p); ping() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun form(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)); v.forEach { addView(it) }
    }

    private fun edit(hint: String, text: String = "", number: Boolean = false) = EditText(this).apply {
        this.hint = hint; setText(text); if (number) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }

    // =============================================================== main UI (menus with auto-hide)
    private fun buildUi() {
        val tl = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        fun tb(t: String, f: () -> Unit) = tl.addView(chip(t, false, f))
        tb("تراجع") { doUndo() }; tb("إعادة") { doRedo() }; tb("تدوير") { rotateSel() }; tb("نسخ") { dupSel() }; tb("حذف") { deleteSel() }
        tb("LED") { selected?.let { sc.toggleLed(it) } }; tb("2D/3D") { editor.visibility = if (editor.visibility == View.VISIBLE) View.GONE else View.VISIBLE; editor.invalidate() }
        topBar = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(0x99000000.toInt()); addView(tl) }
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        panel = FrameLayout(this).apply { setBackgroundColor(0xEE1C1F24.toInt()); visibility = View.GONE }
        val tabs = LinearLayout(this).apply { setBackgroundColor(0xFF111418.toInt()); setPadding(dp(4), dp(2), dp(4), dp(2)) }
        tabNames.forEachIndexed { i, n ->
            tabs.addView(chip(n, i == currentTab && panel.visibility == View.VISIBLE) {
                if (currentTab == i && panel.visibility == View.VISIBLE) { panel.visibility = View.GONE; rebuildTabs() } else openTab(i)
            })
        }
        uiBox = TouchBox(this) { ping() }.apply {
            orientation = LinearLayout.VERTICAL
            addView(panel, LinearLayout.LayoutParams(-1, dp(215)))
            addView(HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; tag = "tabs"; addView(tabs) })
        }
        root.addView(uiBox, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        fab = TextView(this).apply {
            text = "☰"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; background = round(0xCC1E88E5.toInt(), 26); visibility = View.GONE
            setOnClickListener { showUi() }
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(12), dp(12)) })
        openTab(0)
    }

    private fun rebuildTabs() {
        val hs = uiBox.findViewWithTag<HorizontalScrollView>("tabs") ?: return
        val tabs = LinearLayout(this).apply { setBackgroundColor(0xFF111418.toInt()); setPadding(dp(4), dp(2), dp(4), dp(2)) }
        tabNames.forEachIndexed { i, n ->
            tabs.addView(chip(n, i == currentTab && panel.visibility == View.VISIBLE) {
                if (currentTab == i && panel.visibility == View.VISIBLE) { panel.visibility = View.GONE; rebuildTabs() } else openTab(i)
            })
        }
        hs.removeAllViews(); hs.addView(tabs)
    }

    private fun openTab(i: Int) {
        currentTab = i; panel.removeAllViews()
        val content: View = when (i) { 0 -> tabElements(); 1 -> tabMaterials(); 2 -> tabPhoto(); 3 -> tabDraw(); 4 -> tabExport(); 5 -> tabRealistic(); else -> tabSettings() }
        panel.addView(ScrollView(this).apply { addView(content) }, FrameLayout.LayoutParams(-1, -1))
        panel.visibility = View.VISIBLE; rebuildTabs(); ping()
    }

    private fun ping() { handler.removeCallbacks(hideRun); if (autoHide) handler.postDelayed(hideRun, 7000) }
    private fun hideUiNow() { uiBox.visibility = View.GONE; topBar.visibility = View.GONE; fab.visibility = View.VISIBLE }
    private fun showUi() { uiBox.visibility = View.VISIBLE; topBar.visibility = View.VISIBLE; fab.visibility = View.GONE; ping() }

    // ---------------------------------------------------------------- tab: elements
    private fun icon(ci: CatalogItem): Bitmap? = iconCache.getOrPut(ci.id) {
        try { assets.open("icons/${ci.id}.png").use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }
    }

    private fun card(ci: CatalogItem): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)); background = round(0xFF2B3036.toInt(), 12)
            layoutParams = LinearLayout.LayoutParams(dp(92), -2).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
        }
        val iv = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)) }
        val ic = icon(ci)
        if (ic != null) iv.setImageBitmap(ic) else iv.background = round(0xFF4A5059.toInt(), 10)
        c.addView(iv); c.addView(label(ci.name, 11f)); c.addView(label("${ci.w.toInt()}×${ci.d.toInt()}", 9f, 0xFF9AA0A6.toInt()))
        c.setOnClickListener { addItem(ci); ping() }
        return c
    }

    private fun tabElements(): View {
        val col = vcol()
        val groups = Catalog.groups()
        if (curGroup.isEmpty() || curGroup !in groups) curGroup = groups.first()
        col.addView(hrow(
            chip("+ استيراد ملف") { pick("*/*", REQ_IMPORT) }, chip("+ من رابط") { askUrl() },
            chip("+ تصوير عنصر") { launchCamera(REQ_OBJ_CAM) }, chip("+ عنصر من صورة") { pick("image/*", REQ_OBJ_GAL) }
        ))
        val cards = LinearLayout(this)
        val search = edit("بحث عن عنصر...").apply { textSize = 13f; setSingleLine() }
        fun fill(f: String) {
            cards.removeAllViews()
            val list = if (f.isNotBlank()) Catalog.items.filter { it.name.contains(f) || it.id.contains(f, true) }.take(80) else Catalog.items.filter { it.group == curGroup }
            list.forEach { cards.addView(card(it)) }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(search)
        col.addView(hrow(*groups.map { g -> chip(g, g == curGroup) { curGroup = g; openTab(0) } }.toTypedArray()))
        fill(""); col.addView(HorizontalScrollView(this).apply { addView(cards) })
        return col
    }

    // ---------------------------------------------------------------- tab: materials
    private fun thumb(m: MatPreset): Bitmap? = thumbCache.getOrPut(m.id) {
        if (m.tex.isEmpty()) null else try {
            assets.open("tex/${m.tex}.png").use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 }) }
        } catch (e: Exception) { null }
    }

    private fun tabMaterials(): View {
        val col = vcol()
        val names = mapOf("main" to "الرئيسية", "top" to "السطح", "accent" to "التفاصيل")
        val avail = mutableListOf<Pair<String, String>>()
        selected?.item?.slots?.forEach { s -> avail.add(s to (names[s] ?: s)) }
        avail.add("floor" to "الأرضية"); avail.add("wall" to "الجدران")
        if (avail.none { it.first == matTarget }) matTarget = avail.first().first
        col.addView(label(if (selected == null) "اختر عنصراً لتغيير خاماته، أو عدّل الأرضية والجدران" else "العنصر: ${selected?.item?.name}", 12f, 0xFF9AA0A6.toInt()))
        col.addView(hrow(*avail.map { (k, n) -> chip(n, k == matTarget) { matTarget = k; openTab(1) } }.toTypedArray()))
        val groups = if (matTarget == "wall") listOf("دهانات", "طلاء لامع", "رخام وحجر") else Materials.groups()
        if (matGroup !in groups) matGroup = groups.first()
        col.addView(hrow(*groups.map { g -> chip(g, g == matGroup) { matGroup = g; openTab(1) } }.toTypedArray()))
        val row = LinearLayout(this)
        for (m in Materials.list.filter { it.grp == matGroup }) {
            val sw = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(78), -2).apply { setMargins(dp(3), dp(2), dp(3), dp(2)) }
            }
            val iv = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)); scaleType = ImageView.ScaleType.CENTER_CROP }
            val th = thumb(m)
            if (th != null) iv.setImageBitmap(th)
            else iv.background = round(Color.rgb((m.r * 255).toInt(), (m.g * 255).toInt(), (m.b * 255).toInt()), 10)
            sw.addView(iv); sw.addView(label(m.name, 10f)); sw.setOnClickListener { applyMaterial(m); ping() }
            row.addView(sw)
        }
        col.addView(HorizontalScrollView(this).apply { addView(row) })
        return col
    }

    private fun applyMaterial(m: MatPreset) {
        snapshot()
        when (matTarget) {
            "floor" -> { plan.floorMat = m.id; sc.buildRoom(plan) }
            "wall" -> { plan.wallMat = m.id; sc.buildRoom(plan) }
            else -> selected?.let { it.mats[matTarget] = m.id; sc.refreshMaterials(it) }
        }
    }

    // ---------------------------------------------------------------- tab: photo
    private fun tabPhoto(): View {
        val col = vcol()
        col.addView(label("1) صوّر الغرفة  2) اضغط معايرة وحدّد زوايا الأرضية: خلفية-يسار، خلفية-يمين، أمامية-يمين، أمامية-يسار  3) أدخل أبعاد الغرفة الحقيقية ثم ضع العناصر", 11f, 0xFF9AA0A6.toInt()))
        col.addView(hrow(
            chip("التقاط خلفية") { launchCamera(REQ_BG_CAM) }, chip("من المعرض") { pick("image/*", REQ_BG_GAL) },
            chip("معايرة الأرضية") { if (photoBmp == null) toast("أضف صورة أولاً") else startMark() },
            chip("أبعاد الغرفة") { askDims() },
            chip("شبكة التحقق", pen.showGrid) { pen.showGrid = !pen.showGrid; pen.invalidate(); openTab(2) },
            chip("إزالة الصورة") { clearBackground() }
        ))
        col.addView(seek("الإضاءة", 200, 100) { r3d.setLight(it / 100f) })
        col.addView(seek("الظل", 100, 55) { sc.setShadowOpacity(it / 100f) })
        col.addView(seek("الشمس", 360, 25) { r3d.setSunAzimuth(it.toFloat()) })
        return col
    }

    // ---------------------------------------------------------------- tab: draw
    private fun tabDraw(): View {
        val col = vcol()
        col.addView(hrow(
            chip("قلم", pen.mode == DrawView.Mode.DRAW) { pen.mode = DrawView.Mode.DRAW; openTab(3) },
            chip("ممحاة", pen.mode == DrawView.Mode.ERASE) { pen.mode = DrawView.Mode.ERASE; openTab(3) },
            chip("إيقاف الرسم", pen.mode == DrawView.Mode.OFF) { pen.mode = DrawView.Mode.OFF; openTab(3) },
            chip("تقويم الخطوط", pen.straighten) { pen.straighten = !pen.straighten; openTab(3) },
            chip("تراجع") { pen.undo() }, chip("إعادة") { pen.redoStroke() }, chip("مسح") { pen.clearAll() }
        ))
        val colors = LinearLayout(this)
        for (c in intArrayOf(0xFFE53935.toInt(), 0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFFDD835.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFB8C00.toInt(), 0xFF8E24AA.toInt())) {
            colors.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(dp(5), dp(4), dp(5), dp(4)) }
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(2), Color.GRAY) }
                setOnClickListener { pen.color = c; pen.mode = DrawView.Mode.DRAW; openTab(3) }
            })
        }
        col.addView(HorizontalScrollView(this).apply { addView(colors) })
        col.addView(seek("السُّمك", 30, pen.width.toInt()) { pen.width = max(2, it).toFloat() })
        return col
    }

    // ---------------------------------------------------------------- tab: export
    private fun tabExport(): View {
        val col = vcol()
        col.addView(hrow(
            chip("PNG") { composite()?.let { b -> savePng(b) } },
            chip("PDF") { composite()?.let { b -> val f = out("pdf"); Exporter.pdf(plan, b, f); toast(f.absolutePath) } },
            chip("سكتش رصاص") { sketch(0) }, chip("سكتش خطوط") { sketch(1) }, chip("سكتش ملوّن") { sketch(2) }
        ))
        col.addView(label("السكتش يُنشأ من الصورة الحالية (الخلفية + التصميم + الرسم) ويمكن حفظه كصورة.", 11f, 0xFF9AA0A6.toInt()))
        return col
    }

    // ---------------------------------------------------------------- tab: settings
    private fun tabSettings(): View {
        val col = vcol()
        col.addView(hrow(
            chip(if (autoHide) "الإخفاء التلقائي: تشغيل" else "الإخفاء التلقائي: إيقاف", autoHide) {
                autoHide = !autoHide; prefs.edit().putBoolean("autohide", autoHide).apply(); openTab(6)
            },
            chip("إعادة ضبط الكاميرا") { r3d.yaw = 0.35f; r3d.pitch = 0.5f; r3d.dist = 6.5f },
            chip("حفظ المشروع") { save(); toast("تم الحفظ") },
            chip("مشروع جديد") { snapshot(); plan.items.toList().forEach { sc.remove(it) }; plan.items.clear(); selected = null; sc.buildRoom(plan); editor.invalidate() }
        ))
        col.addView(label("القوائم تختفي بعد 7 ثوانٍ من عدم الاستخدام، وتظهر بزر ☰. المشروع يُحفظ تلقائياً.", 11f, 0xFF9AA0A6.toInt()))
        return col
    }

    // ---------------------------------------------------------------- tab: realistic render engine
    private fun rc(k: String, d: String = ""): String = prefs.getString(k, d) ?: d

    private fun tabRealistic(): View {
        val col = vcol()
        col.addView(hrow(
            chip("وصف محلي (بدون إنترنت)") { makeLocal() }, chip("وصف بالذكاء (Claude)") { makeAi() },
            chip("توليد الصورة الواقعية") { generate() }, chip("إعدادات الخادم") { serverDialog() }
        ))
        col.addView(label("الوصف المحلي يُبنى من عناصر مشروعك وخاماتها بدقة. وصف Claude يحلل الصورة (يحتاج مفتاح API). التوليد يعمل مباشرة عبر خادم AI Horde المجاني (بدون تسجيل)، أو خادمك الخاص من الإعدادات.", 11f, 0xFF9AA0A6.toInt()))
        return col
    }

    private fun makeLocal(): JSONObject {
        val j = RenderEngine.local(plan, sc.photo, sc.ledCount(), rc("rc_pre", "mlsd")); lastJson = j; showJson(); return j
    }

    private fun busy(msg: String): AlertDialog = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()

    private fun prepImage(src: Bitmap, maxSide: Int, mult: Int = 8): Triple<String, Int, Int> {
        val s = min(1f, maxSide.toFloat() / max(src.width, src.height))
        val w = ((src.width * s).toInt() / mult * mult).coerceAtLeast(64); val h = ((src.height * s).toInt() / mult * mult).coerceAtLeast(64)
        val bo = ByteArrayOutputStream(); Bitmap.createScaledBitmap(src, w, h, true).compress(Bitmap.CompressFormat.JPEG, 90, bo)
        return Triple(Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP), w, h)
    }

    private fun makeAi() {
        val key = rc("rc_key")
        if (key.isBlank()) { toast("أدخل مفتاح Claude في إعدادات الخادم"); serverDialog(); return }
        val bmp = composite() ?: return
        val img = prepImage(bmp, 1024)
        val notes = RenderEngine.local(plan, sc.photo, sc.ledCount(), rc("rc_pre", "mlsd")).getString("positive_prompt")
        val dlg = busy("جارٍ تحليل التصميم بالذكاء...")
        Thread {
            try {
                val j = RenderEngine.claudePrompt(key, rc("rc_model", "claude-sonnet-5-5"), img.first, notes)
                runOnUiThread { dlg.dismiss(); lastJson = j; showJson() }
            } catch (e: Exception) { runOnUiThread { dlg.dismiss(); toast("فشل: ${e.message}") } }
        }.start()
    }

    private fun showJson() {
        val j = lastJson ?: return
        val txt = j.toString(2)
        val view = TextView(this).apply { text = txt; textSize = 11f; setTextIsSelectable(true); typeface = android.graphics.Typeface.MONOSPACE; setTextColor(Color.WHITE) }
        AlertDialog.Builder(this).setTitle("JSON").setView(ScrollView(this).apply { addView(form(view)) })
            .setPositiveButton("نسخ") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("render", txt)); toast("تم النسخ")
            }.setNeutralButton("توليد") { _, _ -> generate() }.setNegativeButton("إغلاق", null).show()
    }

    private fun generate() {
        val mode = rc("rc_mode", "horde")
        if (mode == "horde" && !prefs.getBoolean("rc_consent", false)) {
            AlertDialog.Builder(this).setTitle("خادم مجاني عام")
                .setMessage("سيُرسل التصميم والوصف إلى شبكة AI Horde (حواسيب متطوعين). لا ترسل صوراً خاصة أو حساسة. قد يستغرق التوليد عدة دقائق لأن الاستخدام المجهول له أقل أولوية. المتابعة؟")
                .setPositiveButton("موافق") { _, _ -> prefs.edit().putBoolean("rc_consent", true).apply(); generate() }.setNegativeButton("إلغاء", null).show()
            return
        }
        val j = lastJson ?: RenderEngine.local(plan, sc.photo, sc.ledCount(), rc("rc_pre", "mlsd")).also { lastJson = it }
        val url = rc("rc_url", "https://aihorde.net/api/v2").ifBlank { "https://aihorde.net/api/v2" }
        if (mode != "horde" && url.contains("aihorde.net")) { toast("أدخل عنوان خادمك في إعدادات الخادم"); serverDialog(); return }
        val bmp = composite() ?: return
        val img = if (mode == "horde") prepImage(bmp, 768, 64) else prepImage(bmp, 1024, 8)
        val hk = rc("rc_hkey", "0000000000"); val control = rc("rc_method", "control") == "control"
        val dlg = busy("جارٍ توليد الصورة الواقعية...")
        Thread {
            try {
                val res = when (mode) {
                    "horde" -> RenderEngine.horde(url, hk, j, img.first, img.second, img.third, control) { s -> runOnUiThread { dlg.setMessage(s) } }
                    "a1111" -> RenderEngine.a1111(url, j, img.first, img.second, img.third)
                    else -> RenderEngine.generic(url, j, img.first)
                }
                runOnUiThread { dlg.dismiss(); showRender(res) }
            } catch (e: Exception) { runOnUiThread { dlg.dismiss(); toast("فشل التوليد: ${e.message}") } }
        }.start()
    }

    private fun showRender(b: Bitmap) {
        val iv = ImageView(this).apply { setImageBitmap(b); adjustViewBounds = true }
        AlertDialog.Builder(this).setView(iv).setPositiveButton("حفظ") { _, _ -> savePng(b) }.setNegativeButton("إغلاق", null).show()
    }

    private fun serverDialog() {
        val key = edit("مفتاح Claude API (اختياري للوصف بالذكاء)", rc("rc_key")); val model = edit("نموذج Claude", rc("rc_model", "claude-sonnet-5-5"))
        val modeKeys = arrayOf("horde", "a1111", "generic")
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("AI Horde - مجاني بدون تسجيل (افتراضي)", "Stable Diffusion WebUI (A1111)", "خادم عام (JSON)"))
            setSelection(modeKeys.indexOf(rc("rc_mode", "horde")).coerceAtLeast(0))
        }
        val url = edit("عنوان الخادم", rc("rc_url", "https://aihorde.net/api/v2"))
        val hkey = edit("مفتاح AI Horde (اتركه 0000000000 للاستخدام المجهول)", rc("rc_hkey", "0000000000"))
        val method = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("ControlNet (يحافظ على الخطوط)", "img2img (احتياطي)"))
            setSelection(if (rc("rc_method", "control") == "control") 0 else 1)
        }
        val pre = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("mlsd (خطوط مستقيمة)", "canny (حواف)"))
            setSelection(if (rc("rc_pre", "mlsd") == "mlsd") 0 else 1)
        }
        AlertDialog.Builder(this).setTitle("إعدادات المحرك الواقعي")
            .setView(ScrollView(this).apply { addView(form(label("الخادم الافتراضي مضبوط تلقائياً، غيّره فقط إذا كان لديك خادم خاص", 11f, 0xFF9AA0A6.toInt()), mode, url, hkey, method, pre, key, model)) })
            .setPositiveButton("حفظ") { _, _ ->
                val chosen = modeKeys[mode.selectedItemPosition]
                var u = url.text.toString().trim()
                if (chosen == "horde" && !u.contains("aihorde.net")) u = "https://aihorde.net/api/v2"
                prefs.edit().putString("rc_mode", chosen).putString("rc_url", u).putString("rc_hkey", hkey.text.toString().trim())
                    .putString("rc_method", if (method.selectedItemPosition == 0) "control" else "img2img").putString("rc_pre", if (pre.selectedItemPosition == 0) "mlsd" else "canny")
                    .putString("rc_key", key.text.toString().trim()).putString("rc_model", model.text.toString().trim()).apply()
                toast("تم الحفظ")
            }.setNegativeButton("إلغاء", null).show()
    }

    // =============================================================== items / undo
    private fun addItem(ci: CatalogItem) {
        snapshot()
        val p = PlacedItem(uid++, ci, plan.w / 2, if (ci.category == Category.OPENING) 0f else plan.d / 2)
        plan.items += p; selected = p; resnap(p); sc.place(p)
        if (ci.category == Category.OPENING) sc.buildRoom(plan)
    }

    private fun resnap(p: PlacedItem) {
        val s = SnapEngine.snap(plan, p, p.x, p.z); p.x = s.x; p.z = s.z; p.rotY = s.rot; sc.update(p); editor.invalidate()
    }

    private fun rotateSel() { selected?.let { if (it.item.category != Category.OPENING) { snapshot(); it.rotY = (it.rotY + 90f) % 360f; resnap(it) } } }

    private fun dupSel() {
        val s = selected ?: return
        if (s.item.category == Category.OPENING) return
        snapshot(); val n = PlacedItem(uid++, s.item, s.x + 40f, s.z + 40f, s.rotY, s.mats.toMutableMap())
        plan.items += n; selected = n; resnap(n); sc.place(n)
    }

    private fun deleteSel() {
        val s = selected ?: return
        snapshot(); plan.items.remove(s); sc.remove(s); selected = null
        if (s.item.category == Category.OPENING) sc.buildRoom(plan)
        editor.invalidate()
    }

    private fun snapshot() { undoStack.addLast(plan.toJson()); if (undoStack.size > 40) undoStack.removeFirst(); redoStack.clear() }
    private fun doUndo() { if (undoStack.isNotEmpty()) { redoStack.addLast(plan.toJson()); restoreFrom(undoStack.removeLast()) } }
    private fun doRedo() { if (redoStack.isNotEmpty()) { undoStack.addLast(plan.toJson()); restoreFrom(redoStack.removeLast()) } }

    private fun restoreFrom(json: String) {
        plan.restore(json); selected = null; dragging = null
        sc.clearAll(); sc.buildRoom(plan); plan.items.forEach { sc.place(it) }
        uid = max(uid, (plan.items.maxOfOrNull { it.uid } ?: -1) + 1); editor.invalidate()
    }

    private fun save() { try { store.writeText(plan.toJson()) } catch (e: Exception) { } }

    // =============================================================== touch on the 3D stage
    private fun onStageTouch(v: View, e: MotionEvent): Boolean {
        scaleDet.onTouchEvent(e)
        if (e.pointerCount > 1) { dragging = null; return true }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (autoHide && uiBox.visibility == View.VISIBLE) hideUiNow()
                lx = e.x; ly = e.y; dragMoved = false
                val hit = sc.pick(e.x, e.y, v.width, v.height, plan.items)
                if (hit != null) { selected = hit; dragging = hit } else dragging = null
            }
            MotionEvent.ACTION_MOVE -> {
                val d = dragging
                if (d != null) {
                    sc.floorPoint(e.x, e.y, v.width, v.height)?.let { (fx, fz) ->
                        if (!dragMoved) { snapshot(); dragMoved = true }
                        val s = SnapEngine.snap(plan, d, fx, fz); d.x = s.x; d.z = s.z; d.rotY = s.rot; sc.update(d)
                    }
                } else if (!r3d.photoMode) {
                    r3d.yaw -= (e.x - lx) * 0.006f; r3d.pitch = (r3d.pitch + (e.y - ly) * 0.006f).coerceIn(0.05f, 1.45f)
                }
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val d = dragging
                if (d != null && dragMoved && d.item.category == Category.OPENING) sc.buildRoom(plan)
                dragging = null; editor.invalidate()
            }
        }
        return true
    }

    // =============================================================== photo background + calibration
    private fun fitStage(bw: Int, bh: Int) {
        val s = min(root.width.toFloat() / bw, root.height.toFloat() / bh)
        stage.layoutParams = FrameLayout.LayoutParams((bw * s).toInt(), (bh * s).toInt(), Gravity.CENTER)
    }

    private fun setBackground(bmp: Bitmap) {
        photoBmp = bmp; bg.setImageBitmap(bmp); bg.visibility = View.VISIBLE
        fitStage(bmp.width, bmp.height)
        marks = emptyList(); pen.calib = null; sc.setPhoto(false, plan); tv.visibility = View.INVISIBLE
        toast("اضغط زوايا الأرضية بالترتيب: خلفية-يسار، خلفية-يمين، أمامية-يمين، أمامية-يسار"); startMark()
    }

    private fun startMark() { pen.beginMark { pts -> marks = pts; runCalib() }; if (autoHide) hideUiNow() }

    private fun runCalib() {
        if (marks.size != 4) return
        pen.gridW = plan.w / 100.0; pen.gridD = plan.d / 100.0
        val c: Calib? = PhotoCalib.calibrate(marks.map { it.x.toDouble() to it.y.toDouble() }, plan.w / 100.0, plan.d / 100.0, stage.width.toDouble(), stage.height.toDouble())
        if (c == null) { toast("تعذرت المعايرة. تحقق من ترتيب النقاط وأعد المحاولة"); startMark(); return }
        pen.calib = c; r3d.eye = c.eye; r3d.look = c.look; r3d.up = c.up; r3d.fovV = c.fovV
        tv.visibility = View.VISIBLE; sc.setPhoto(true, plan)
    }

    private fun clearBackground() {
        photoBmp = null; bg.visibility = View.GONE; marks = emptyList(); pen.calib = null; pen.mode = DrawView.Mode.OFF
        stage.layoutParams = FrameLayout.LayoutParams(-1, -1); tv.visibility = View.VISIBLE; sc.setPhoto(false, plan)
    }

    private fun askDims() {
        val w = edit("العرض (سم)", plan.w.toInt().toString(), true); val d = edit("العمق (سم)", plan.d.toInt().toString(), true)
        AlertDialog.Builder(this).setTitle("أبعاد الغرفة الحقيقية (سم)").setView(form(w, d)).setPositiveButton("تطبيق") { _, _ ->
            plan.w = (w.text.toString().toFloatOrNull() ?: plan.w).coerceIn(200f, 1000f); plan.d = (d.text.toString().toFloatOrNull() ?: plan.d).coerceIn(200f, 800f)
            plan.items.forEach { resnap(it) }; sc.buildRoom(plan); if (marks.size == 4) runCalib(); editor.invalidate()
        }.setNegativeButton("إلغاء", null).show()
    }

    // =============================================================== camera / gallery / import
    private fun launchCamera(req: Int) {
        val f = File(cacheDir, "cam_${System.currentTimeMillis()}.jpg"); camFile = f
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try { startActivityForResult(i, req) } catch (e: Exception) { toast("لا يوجد تطبيق كاميرا") }
    }

    private fun pick(mime: String, req: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT).setType(mime).addCategory(Intent.CATEGORY_OPENABLE)
        try { startActivityForResult(Intent.createChooser(i, "اختر"), req) } catch (e: Exception) { toast("لا يوجد تطبيق مناسب") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_BG_CAM -> camFile?.let { f -> decode { f.inputStream() }?.let { setBackground(it) } }
            REQ_BG_GAL -> data?.data?.let { u -> decode { contentResolver.openInputStream(u)!! }?.let { setBackground(it) } }
            REQ_OBJ_CAM -> camFile?.let { f -> objFromBitmap(decode { f.inputStream() }) }
            REQ_OBJ_GAL -> data?.data?.let { u -> objFromBitmap(decode { contentResolver.openInputStream(u)!! }) }
            REQ_IMPORT -> data?.data?.let { importModel(it) }
        }
    }

    private fun decode(open: () -> InputStream): Bitmap? {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            open().use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (max(o.outWidth, o.outHeight) / s > 2000) s *= 2
            val bmp = open().use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return null
            val deg = try {
                open().use { when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 } }
            } catch (e: Exception) { 0 }
            if (deg == 0) return bmp
            val m = android.graphics.Matrix(); m.postRotate(deg.toFloat())
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (e: Exception) { return null }
    }

    private fun queryName(u: Uri): String =
        contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "model.glb"

    private fun importModel(u: Uri) {
        val name = queryName(u)
        Thread {
            try {
                val bytes = contentResolver.openInputStream(u)!!.use { it.readBytes() }
                runOnUiThread { registerBytes(bytes, name) }
            } catch (e: Exception) { runOnUiThread { toast("تعذر الاستيراد: ${e.message}") } }
        }.start()
    }

    private fun askUrl() {
        val e = edit("https://.../model.glb")
        AlertDialog.Builder(this).setTitle("استيراد من رابط (glb أو obj)").setView(form(e)).setPositiveButton("تنزيل") { _, _ ->
            val link = e.text.toString().trim(); toast("جارٍ التنزيل...")
            Thread {
                try {
                    val bytes = URL(link).openStream().use { it.readBytes() }
                    runOnUiThread { registerBytes(bytes, link.substringAfterLast('/').substringBefore('?')) }
                } catch (ex: Exception) { runOnUiThread { toast("تعذر التنزيل: ${ex.message}") } }
            }.start()
        }.setNegativeButton("إلغاء", null).show()
    }

    /** bytes = glb, or OBJ text (converted). */
    private fun registerBytes(bytes: ByteArray, fileName: String) {
        val glb = try {
            val head = bytes.copyOf(min(bytes.size, 400)).toString(Charsets.UTF_8)
            if (bytes.size > 4 && head.startsWith("glTF")) bytes
            else if (fileName.endsWith(".obj", true) || head.contains("\nv ") || head.startsWith("v ")) ObjToGlb.convert(bytes.toString(Charsets.UTF_8))
            else { toast("الصيغة غير مدعومة. استخدم glb أو obj"); return }
        } catch (ex: Exception) { toast("ملف غير صالح: ${ex.message}"); return }
        val id = "imp_${System.currentTimeMillis()}"
        val f = File(File(filesDir, "imports").also { it.mkdirs() }, "$id.glb"); f.writeBytes(glb)
        val m = sc.measure(f.absolutePath)
        if (m == null) { toast("تعذر قراءة النموذج"); f.delete(); return }
        val name = edit("الاسم", fileName.substringBeforeLast('.'))
        val hgt = edit("الارتفاع بالسم", (m[4] * 100).coerceIn(5f, 300f).toInt().toString(), true)
        val kinds = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("أثاث أرضي", "عنصر جداري", "ديكور")) }
        AlertDialog.Builder(this).setTitle("إضافة عنصر مستورد").setView(form(name, hgt, kinds)).setPositiveButton("إضافة") { _, _ ->
            val hCm = (hgt.text.toString().toFloatOrNull() ?: 60f).coerceIn(2f, 400f)
            val k = (hCm / 100f) / m[4].coerceAtLeast(1e-4f)
            val cat = when (kinds.selectedItemPosition) { 1 -> Category.WALL_UNIT; 2 -> Category.DECOR; else -> Category.FURNITURE }
            val elev = if (kinds.selectedItemPosition == 1) 120f else 0f
            val item = CatalogItem(id, name.text.toString().ifBlank { "عنصر" }, "مستورد", cat, "", m[3] * k * 100f, m[5] * k * 100f, hCm, elev,
                file = f.absolutePath, k = k, offX = -m[0], offY = -m[1], offZ = -m[2])
            Catalog.addImported(this, item); curGroup = "مستورد"; addItem(item); openTab(0)
        }.setNegativeButton("إلغاء") { _, _ -> f.delete() }.show()
    }

    /** Photo of a real object -> background removed -> upright cut-out element at real size. */
    private fun objFromBitmap(src: Bitmap?) {
        if (src == null) { toast("تعذر قراءة الصورة"); return }
        var cut = BackgroundRemover.cut(src, 40)
        val iv = ImageView(this).apply { setBackgroundColor(0xFF888888.toInt()); layoutParams = LinearLayout.LayoutParams(-1, dp(220)); setImageBitmap(cut) }
        val sb = SeekBar(this).apply {
            max = 110; progress = 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { cut = BackgroundRemover.cut(src, 10 + (s?.progress ?: 30)); iv.setImageBitmap(cut) }
            })
        }
        val name = edit("اسم العنصر", "عنصر من صورة"); val hgt = edit("الارتفاع الحقيقي بالسم", "80", true)
        AlertDialog.Builder(this).setTitle("عنصر من صورة (حسّاسية إزالة الخلفية)").setView(ScrollView(this).apply { addView(form(iv, sb, name, hgt)) })
            .setPositiveButton("إضافة") { _, _ ->
                val hCm = (hgt.text.toString().toFloatOrNull() ?: 80f).coerceIn(2f, 400f); val wCm = hCm * cut.width / cut.height
                val id = "img_${System.currentTimeMillis()}"
                val f = File(File(filesDir, "imports").also { it.mkdirs() }, "$id.glb"); f.writeBytes(GlbWriter.photoQuad(cut, wCm / 100f, hCm / 100f))
                val item = CatalogItem(id, name.text.toString().ifBlank { "عنصر" }, "مستورد", Category.FURNITURE, "", wCm, 3f, hCm, 0f, file = f.absolutePath)
                Catalog.addImported(this, item); curGroup = "مستورد"; addItem(item); openTab(0)
            }.setNegativeButton("إلغاء", null).show()
    }

    // =============================================================== export / sketch
    private fun out(ext: String) = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: filesDir, "design_${System.currentTimeMillis()}.$ext")

    private fun composite(): Bitmap? {
        val w = stage.width; val h = stage.height
        if (w == 0 || h == 0) { toast("لا يوجد مشهد للتصدير"); return null }
        val outBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(outBmp); c.drawColor(0xFFEEEEEE.toInt())
        photoBmp?.let { c.drawBitmap(it, null, Rect(0, 0, w, h), null) }
        tv.bitmap?.let { c.drawBitmap(it, 0f, 0f, null) }
        pen.draw(c); return outBmp
    }

    private fun savePng(b: Bitmap) { val f = out("png"); f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; toast(f.absolutePath) }

    private fun sketch(kind: Int) {
        val src = composite() ?: return
        val res = when (kind) { 0 -> Sketchify.pencil(src); 1 -> Sketchify.lines(src); else -> Sketchify.colored(src) }
        val iv = ImageView(this).apply { setImageBitmap(res); adjustViewBounds = true }
        AlertDialog.Builder(this).setView(iv).setPositiveButton("حفظ") { _, _ -> savePng(res) }.setNegativeButton("إغلاق", null).show()
    }
}
