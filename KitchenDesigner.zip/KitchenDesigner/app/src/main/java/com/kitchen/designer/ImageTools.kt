package com.kitchen.designer

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Removes a plain background by flood-filling inward from the image border (photograph the object on a plain wall/floor). */
object BackgroundRemover {
    fun cut(src: Bitmap, tol: Int): Bitmap {
        val s = min(1f, 700f / max(src.width, src.height))
        val bmp = if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true) else src.copy(Bitmap.Config.ARGB_8888, true)
        val w = bmp.width; val h = bmp.height; val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        fun acc(p: Int) { r += Color.red(p); g += Color.green(p); b += Color.blue(p); n++ }
        for (x in 0 until w) { acc(px[x]); acc(px[(h - 1) * w + x]) }
        for (y in 0 until h) { acc(px[y * w]); acc(px[y * w + w - 1]) }
        val br = (r / n).toInt(); val bg = (g / n).toInt(); val bb = (b / n).toInt()
        val thr = tol * 3
        fun dBg(p: Int) = abs(Color.red(p) - br) + abs(Color.green(p) - bg) + abs(Color.blue(p) - bb)
        fun dPx(p: Int, q: Int) = abs(Color.red(p) - Color.red(q)) + abs(Color.green(p) - Color.green(q)) + abs(Color.blue(p) - Color.blue(q))
        val vis = BooleanArray(w * h); val q = IntArray(w * h); var qh = 0; var qt = 0
        fun seed(i: Int) { if (!vis[i] && dBg(px[i]) < thr) { vis[i] = true; q[qt++] = i } }
        for (x in 0 until w) { seed(x); seed((h - 1) * w + x) }
        for (y in 0 until h) { seed(y * w); seed(y * w + w - 1) }
        while (qh < qt) {
            val i = q[qh++]; val x = i % w; val y = i / w
            for (k in 0..3) {
                val nx = x + (if (k == 0) 1 else if (k == 1) -1 else 0); val ny = y + (if (k == 2) 1 else if (k == 3) -1 else 0)
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (vis[j]) continue
                val d = dBg(px[j])
                if (d < thr || (dPx(px[j], px[i]) < thr / 4 && d < thr * 2)) { vis[j] = true; q[qt++] = j }
            }
        }
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (vis[i]) px[i] = 0 else { px[i] = px[i] or (0xFF shl 24); x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y) }
        }
        if (x1 < 0) return bmp
        x0 = max(0, x0 - 2); y0 = max(0, y0 - 2); x1 = min(w - 1, x1 + 2); y1 = min(h - 1, y1 + 2)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.setPixels(px, 0, w, 0, 0, w, h)
        return Bitmap.createBitmap(out, x0, y0, x1 - x0 + 1, y1 - y0 + 1)
    }
}

/** Photo/3D composite -> pencil sketch, line drawing, or watercolour-style coloured sketch. */
object Sketchify {
    private fun scaled(src: Bitmap, maxSide: Int): Bitmap {
        val s = min(1f, maxSide.toFloat() / max(src.width, src.height))
        return if (s < 1f) Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src.copy(Bitmap.Config.ARGB_8888, false)
    }

    private fun gray(px: IntArray) = IntArray(px.size) { val c = px[it]; (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000 }

    private fun blur(a: IntArray, w: Int, h: Int, r: Int): IntArray {
        val t = IntArray(a.size); val o = IntArray(a.size); val k = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w; var s = 0
            for (x in -r..r) s += a[row + x.coerceIn(0, w - 1)]
            for (x in 0 until w) { t[row + x] = s / k; s += a[row + (x + r + 1).coerceAtMost(w - 1)] - a[row + (x - r).coerceAtLeast(0)] }
        }
        for (x in 0 until w) {
            var s = 0
            for (y in -r..r) s += t[y.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) { o[y * w + x] = s / k; s += t[(y + r + 1).coerceAtMost(h - 1) * w + x] - t[(y - r).coerceAtLeast(0) * w + x] }
        }
        return o
    }

    private fun pencilArr(g: IntArray, w: Int, h: Int): IntArray {
        val inv = IntArray(g.size) { 255 - g[it] }; val bl = blur(inv, w, h, max(2, w / 160))
        return IntArray(g.size) { min(255, g[it] * 255 / (255 - bl[it] + 1)) }
    }

    fun pencil(src: Bitmap): Bitmap {
        val b = scaled(src, 1400); val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val p = pencilArr(gray(px), w, h)
        return Bitmap.createBitmap(IntArray(w * h) { val v = p[it]; (0xFF shl 24) or (v shl 16) or (v shl 8) or v }, w, h, Bitmap.Config.ARGB_8888)
    }

    fun lines(src: Bitmap): Bitmap {
        val b = scaled(src, 1400); val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val g = blur(gray(px), w, h, 1); val out = IntArray(w * h) { -1 }
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            val v = (255 - (abs(gx) + abs(gy) - 30) * 255 / 70).coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    fun colored(src: Bitmap): Bitmap {
        val b = scaled(src, 1400); val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val p = pencilArr(gray(px), w, h)
        return Bitmap.createBitmap(IntArray(w * h) {
            val c = px[it]; val k = p[it] / 255f
            val r = ((0.55f * Color.red(c) + 0.45f * 255f) * k).toInt().coerceIn(0, 255)
            val gg = ((0.55f * Color.green(c) + 0.45f * 255f) * k).toInt().coerceIn(0, 255)
            val bb = ((0.55f * Color.blue(c) + 0.45f * 255f) * k).toInt().coerceIn(0, 255)
            (0xFF shl 24) or (r shl 16) or (gg shl 8) or bb
        }, w, h, Bitmap.Config.ARGB_8888)
    }
}
