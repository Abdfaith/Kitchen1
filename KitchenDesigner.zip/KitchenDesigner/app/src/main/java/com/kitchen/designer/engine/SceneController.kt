package com.kitchen.designer.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.Matrix
import com.google.android.filament.*
import com.google.android.filament.android.TextureHelper
import com.google.android.filament.gltfio.*
import com.kitchen.designer.model.*
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Owns every 3D object: room, items (with smooth animation), materials, LEDs, photo-mode shadows, picking. */
class SceneController(private val ctx: Context, private val r: Renderer3D) {
    private val engine = r.engine
    private val scene = r.scene
    private val loader = AssetLoader(engine, UbershaderProvider(engine), EntityManager.get())
    private val resources = ResourceLoader(engine)
    private val cache = HashMap<String, ByteArray>()
    private val nodes = HashMap<Int, Node>()
    private val roomAssets = mutableListOf<FilamentAsset>()
    private val roomLights = mutableListOf<Int>()
    private val texCache = HashMap<String, Texture>()
    private val sampler = TextureSampler(TextureSampler.MinFilter.LINEAR_MIPMAP_LINEAR, TextureSampler.MagFilter.LINEAR, TextureSampler.WrapMode.REPEAT)
    private var white: Texture? = null
    var photo = false
        private set
    private var shadowAlpha = 0.55f

    private class Node(val p: PlacedItem, val a: FilamentAsset) {
        val d = floatArrayOf(p.x, p.z, p.rotY, 0.85f)   // displayed x, z, rot, scale (animated toward the target)
        var settled = false
        var shadow: FilamentAsset? = null
        var led = 0
    }

    init { Quality.apply(engine, r.view); Environment.apply(engine, scene) }

    // ---------- loading ----------
    private fun load(path: String, file: Boolean = false): FilamentAsset {
        val b = if (file) File(path).readBytes() else cache.getOrPut(path) { ctx.assets.open("models/$path").use { it.readBytes() } }
        val buf = ByteBuffer.allocateDirect(b.size); buf.put(b); buf.rewind()
        val a = loader.createAsset(buf) ?: throw IllegalStateException("bad glb: $path")
        resources.loadResources(a); a.releaseSourceData(); scene.addEntities(a.entities)
        return a
    }

    private fun destroy(a: FilamentAsset) { scene.removeEntities(a.entities); loader.destroyAsset(a) }

    /** Returns [cx, minY, cz, sizeX, sizeY, sizeZ] of a glb in its own units, or null if it cannot be loaded. */
    fun measure(path: String): FloatArray? = try {
        val a = load(path, true); val b = a.boundingBox; val c = b.center; val h = b.halfExtent
        destroy(a); floatArrayOf(c[0], c[1] - h[1], c[2], h[0] * 2, h[1] * 2, h[2] * 2)
    } catch (e: Exception) { null }

    // ---------- materials ----------
    private fun makeTex(bmp: Bitmap): Texture {
        val t = Texture.Builder().width(bmp.width).height(bmp.height).levels(0xff).sampler(Texture.Sampler.SAMPLER_2D)
            .format(Texture.InternalFormat.SRGB8_A8).build(engine)
        TextureHelper.setBitmap(engine, t, 0, bmp); t.generateMipmaps(engine); return t
    }

    private fun whiteTex(): Texture {
        white?.let { return it }
        val bmp = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888); bmp.eraseColor(-1)
        val t = makeTex(bmp); white = t; return t
    }

    private fun texOf(name: String): Texture? {
        texCache[name]?.let { return it }
        val bmp = (try { ctx.assets.open("tex/$name.png").use { BitmapFactory.decodeStream(it) } } catch (e: Exception) { null }) ?: return null
        val t = makeTex(bmp); texCache[name] = t; return t
    }

    private fun lin(x: Float) = x.pow(2.2f)

    private fun applyPreset(a: FilamentAsset, order: List<String>, slot: String, pid: String?) {
        val m = Materials.byId(pid) ?: return
        val t = (if (m.tex.isEmpty()) null else texOf(m.tex)) ?: whiteTex()
        val mis = a.materialInstances
        for (i in mis.indices) {
            val mi = mis[i]; val nm = mi.name
            val key = if (!nm.isNullOrBlank()) nm else order.getOrNull(i)
            if (key != slot) continue
            mi.setParameter("baseColorMap", t, sampler)
            mi.setParameter("baseColorFactor", lin(m.r), lin(m.g), lin(m.b), 1f)
            mi.setParameter("metallicFactor", m.metal)
            mi.setParameter("roughnessFactor", m.rough)
        }
    }

    fun refreshMaterials(p: PlacedItem) {
        val n = nodes[p.uid] ?: return
        if (p.item.file != null) return
        val eff = p.item.mats + p.mats
        for (s in p.item.slots) applyPreset(n.a, p.item.order, s, eff[s])
    }

    // ---------- transforms ----------
    private fun setT(a: FilamentAsset, m: FloatArray) { val tm = engine.transformManager; tm.setTransform(tm.getInstance(a.root), m) }

    private fun trs(px: Float, py: Float, pz: Float, rot: Float, sx: Float, sy: Float, sz: Float): FloatArray {
        val m = FloatArray(16)
        Matrix.setIdentityM(m, 0); Matrix.translateM(m, 0, px, py, pz); Matrix.rotateM(m, 0, rot, 0f, 1f, 0f); Matrix.scaleM(m, 0, sx, sy, sz)
        return m
    }

    private fun itemM(p: PlacedItem, x: Float, z: Float, rot: Float, s: Float): FloatArray {
        val i = p.item; val c = 0.01f; val m = FloatArray(16)
        Matrix.setIdentityM(m, 0); Matrix.translateM(m, 0, x * c, i.elevation * c, z * c); Matrix.rotateM(m, 0, rot, 0f, 1f, 0f)
        Matrix.scaleM(m, 0, i.k * s, i.k * s, i.k * s); Matrix.translateM(m, 0, i.offX, i.offY, i.offZ)
        return m
    }

    // ---------- room ----------
    private fun clearRoom() {
        roomAssets.forEach { destroy(it) }; roomAssets.clear()
        roomLights.forEach { scene.removeEntity(it); engine.lightManager.destroy(it); EntityManager.get().destroy(it) }; roomLights.clear()
    }

    fun buildRoom(plan: Plan) {
        clearRoom()
        if (photo) return   // in photo mode the real photo is the room
        val c = 0.01f
        fun add(name: String, m: FloatArray, preset: String) { val a = load(name); applyPreset(a, listOf("main"), "main", preset); setT(a, m); roomAssets += a }
        val nx = ceil(plan.w / 100f).toInt(); val nz = ceil(plan.d / 100f).toInt()
        for (i in 0 until nx) for (j in 0 until nz)
            add("floor_tile.glb", trs(i.toFloat(), 0f, j.toFloat(), 0f, min(1f, plan.w / 100f - i), 1f, min(1f, plan.d / 100f - j)), plan.floorMat)
        for (w in plan.pieces()) add("wall.glb", trs(w.cx * c, w.y0 * c, w.cz * c, w.rotY, w.len * c, w.h * c, w.thick * c), plan.wallMat)
        roomLights += addSpot(plan.w * c * 0.3f, plan.h * c - 0.05f, plan.d * c / 2, 80_000f, false)
        roomLights += addSpot(plan.w * c * 0.7f, plan.h * c - 0.05f, plan.d * c / 2, 80_000f, false)
    }

    // ---------- items ----------
    fun place(p: PlacedItem) {
        if (nodes.containsKey(p.uid)) return
        val ci = p.item
        val a = if (ci.file != null) load(ci.file, true) else load(ci.asset)
        val n = Node(p, a); nodes[p.uid] = n
        refreshMaterials(p)
        if (photo) addShadow(n)
        if (ci.category == Category.WALL_UNIT && ci.elevation >= 140f && ci.file == null) toggleLed(p)
        setT(a, itemM(p, n.d[0], n.d[1], n.d[2], n.d[3]))
    }

    fun update(p: PlacedItem) { nodes[p.uid]?.settled = false }

    fun remove(p: PlacedItem) {
        val n = nodes.remove(p.uid) ?: return
        removeLed(n); n.shadow?.let { destroy(it) }; destroy(n.a)
    }

    fun clearAll() {
        nodes.values.toList().forEach { n -> removeLed(n); n.shadow?.let { destroy(it) }; destroy(n.a) }
        nodes.clear()
    }

    /** Smooth glide toward the target position/rotation + a small pop-in; called every frame. */
    fun tick(dt: Float) {
        val a = 1f - exp(-dt * 14f); val b = 1f - exp(-dt * 9f)
        for (n in nodes.values) {
            if (n.settled) continue
            val p = n.p; val d = n.d
            d[0] += (p.x - d[0]) * a; d[1] += (p.z - d[1]) * a
            val dr = ((((p.rotY - d[2]) % 360f) + 540f) % 360f) - 180f
            d[2] += dr * a; d[3] += (1f - d[3]) * b
            if (abs(p.x - d[0]) < 0.02f && abs(p.z - d[1]) < 0.02f && abs(dr) < 0.1f && abs(1f - d[3]) < 0.002f) {
                d[0] = p.x; d[1] = p.z; d[2] = p.rotY; d[3] = 1f; n.settled = true
            }
            setT(n.a, itemM(p, d[0], d[1], d[2], d[3]))
            n.shadow?.let { s -> val ci = p.item; val c = 0.01f; setT(s, trs(d[0] * c, 0.003f, d[1] * c, d[2], ci.w * c * 1.3f, 1f, ci.d * c * 1.3f)) }
            if (n.led != 0) updateLed(n)
        }
    }

    // ---------- lights ----------
    private fun addSpot(x: Float, y: Float, z: Float, lumens: Float, warm: Boolean): Int {
        val e = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.FOCUSED_SPOT).position(x, y, z).direction(0f, -1f, 0f)
            .color(1f, if (warm) 0.82f else 0.95f, if (warm) 0.6f else 0.9f).intensity(lumens).falloff(if (warm) 1.2f else 6f)
            .spotLightCone(0.5f, 1.2f).castShadows(!warm).build(engine, e)
        scene.addEntity(e); return e
    }

    fun toggleLed(p: PlacedItem) {
        val n = nodes[p.uid] ?: return
        if (n.led != 0) removeLed(n) else { n.led = addSpot(0f, 0f, 0f, 9_000f, true); n.settled = false }
    }

    private fun removeLed(n: Node) {
        if (n.led != 0) { scene.removeEntity(n.led); engine.lightManager.destroy(n.led); EntityManager.get().destroy(n.led); n.led = 0 }
    }

    private fun updateLed(n: Node) {
        val i = n.p.item; val d = n.d; val c = 0.01f; val lm = engine.lightManager; val li = lm.getInstance(n.led)
        val rr = Math.toRadians(d[2].toDouble()); val sx = sin(rr).toFloat(); val cz = cos(rr).toFloat()
        lm.setPosition(li, d[0] * c + sx * i.d * c * 0.2f, (i.elevation - 2f) * c, d[1] * c + cz * i.d * c * 0.2f)
        val q = sqrt(1.25f); lm.setDirection(li, -sx * 0.5f / q, -1f / q, -cz * 0.5f / q)
    }

    // ---------- photo mode (translucent 3D over a photo; blob shadows replace the room) ----------
    private fun addShadow(n: Node) {
        val ci = n.p.item
        if (ci.elevation > 5f || ci.category == Category.OPENING || ci.category == Category.WALL_UNIT) return
        val a = load("shadow.glb"); applyShadowAlpha(a); n.shadow = a; n.settled = false
    }

    private fun applyShadowAlpha(a: FilamentAsset) { for (mi in a.materialInstances) mi.setParameter("baseColorFactor", 0f, 0f, 0f, shadowAlpha) }

    fun setShadowOpacity(v: Float) { shadowAlpha = v; nodes.values.forEach { n -> n.shadow?.let { applyShadowAlpha(it) } } }

    fun setPhoto(on: Boolean, plan: Plan) {
        if (photo == on) return
        photo = on; r.setPhoto(on)
        nodes.values.forEach { n -> if (on) addShadow(n) else { n.shadow?.let { destroy(it) }; n.shadow = null } }
        buildRoom(plan)
    }

    // ---------- picking ----------
    private fun ray(px: Float, py: Float, w: Int, h: Int): Pair<FloatArray, FloatArray> {
        val p = DoubleArray(16); val v = DoubleArray(16)
        r.camera.getProjectionMatrix(p); r.camera.getViewMatrix(v)
        val vp = FloatArray(16); val inv = FloatArray(16)
        Matrix.multiplyMM(vp, 0, FloatArray(16) { p[it].toFloat() }, 0, FloatArray(16) { v[it].toFloat() }, 0)
        Matrix.invertM(inv, 0, vp, 0)
        fun un(z: Float): FloatArray {
            val o = FloatArray(4)
            Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(2 * px / w - 1, 1 - 2 * py / h, z, 1f), 0)
            return floatArrayOf(o[0] / o[3], o[1] / o[3], o[2] / o[3])
        }
        val a = un(0f); val b = un(0.5f)
        val d = floatArrayOf(b[0] - a[0], b[1] - a[1], b[2] - a[2]); val n = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2])
        return a to floatArrayOf(d[0] / n, d[1] / n, d[2] / n)
    }

    fun floorPoint(px: Float, py: Float, w: Int, h: Int): Pair<Float, Float>? {
        val (o, d) = ray(px, py, w, h)
        if (abs(d[1]) < 1e-6f) return null
        val t = -o[1] / d[1]
        return if (t < 0) null else (o[0] + d[0] * t) * 100f to (o[2] + d[2] * t) * 100f
    }

    fun pick(px: Float, py: Float, w: Int, h: Int, items: List<PlacedItem>): PlacedItem? {
        val (o, d) = ray(px, py, w, h)
        var best: PlacedItem? = null; var bt = Float.MAX_VALUE
        for (p in items) {
            val (hx, hz) = SnapEngine.half(p.item, p.rotY)
            val mn = floatArrayOf((p.x - hx) * .01f, p.item.elevation * .01f, (p.z - hz) * .01f)
            val mx = floatArrayOf((p.x + hx) * .01f, (p.item.elevation + p.item.h) * .01f, (p.z + hz) * .01f)
            val t = slab(o, d, mn, mx)
            if (t != null && t < bt) { bt = t; best = p }
        }
        return best
    }

    private fun slab(o: FloatArray, d: FloatArray, mn: FloatArray, mx: FloatArray): Float? {
        var t0 = 0f; var t1 = Float.MAX_VALUE
        for (i in 0..2) {
            if (abs(d[i]) < 1e-6f) { if (o[i] < mn[i] || o[i] > mx[i]) return null }
            else {
                var a = (mn[i] - o[i]) / d[i]; var b = (mx[i] - o[i]) / d[i]
                if (a > b) { val t = a; a = b; b = t }
                t0 = max(t0, a); t1 = min(t1, b)
                if (t0 > t1) return null
            }
        }
        return t0
    }
}
