package com.kitchen.designer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.Image
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.Matrix
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.LightEstimate
import com.google.ar.core.Plane
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.UnavailableApkTooOldException
import com.google.ar.core.exceptions.UnavailableDeviceNotCompatibleException
import com.google.ar.core.exceptions.UnavailableSdkTooOldException
import com.google.ar.core.exceptions.UnavailableUserDeclinedInstallationException
import com.kitchen.designer.engine.Renderer3D
import com.kitchen.designer.model.Plan
import kotlin.math.hypot

/**
 * Live-camera mode on ARCore. ARCore needs a GL context only to write its camera texture, so we give it a tiny off-screen EGL context
 * and read the camera image on the CPU (YUV -> rotated bitmap) to show behind the translucent Filament view.
 * Room space (plan cm) is anchored to the detected floor: roomFromWorld maps ARCore world -> room, so the Filament camera =
 * roomFromWorld * cameraToWorld, with ARCore's own projection matrix. Everything drawn/dragged then stays glued to the real floor.
 */
class ArHelper(private val act: Activity) {
    companion object { var askInstall = true }

    private var session: Session? = null
    private var dpy: EGLDisplay? = null
    private var ectx: EGLContext? = null
    private var esurf: EGLSurface? = null
    private var texId = 0
    private var frame: Frame? = null
    private var bmp: Bitmap? = null
    private var pix: IntArray? = null
    private var sensor = 90
    private var roomFromWorld: FloatArray? = null
    private var dw = 0
    private var dh = 0
    private var n = 0
    var active = false
        private set
    val originSet: Boolean get() = roomFromWorld != null
    val bitmap: Bitmap? get() = bmp

    /** Returns null on success, or a user-facing error message. */
    fun start(): String? {
        try {
            if (ArCoreApk.getInstance().checkAvailability(act) == ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE) return "جهازك غير مدعوم من ARCore. استخدم الصورة مع معايرة الأرضية بدلاً من ذلك"
            if (ArCoreApk.getInstance().requestInstall(act, askInstall) == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                askInstall = false; return "ثبّت خدمات Google Play لـ AR ثم أعد المحاولة"
            }
            val s = Session(act)
            val cfg = Config(s)
            cfg.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL
            cfg.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
            cfg.lightEstimationMode = Config.LightEstimationMode.AMBIENT_INTENSITY
            cfg.focusMode = Config.FocusMode.AUTO
            s.configure(cfg)
            initEgl(); s.setCameraTextureName(texId)
            sensor = try {
                val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.getCameraCharacteristics(s.cameraConfig.cameraId).get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            } catch (e: Exception) { 90 }
            s.resume(); session = s; active = true
            return null
        } catch (e: UnavailableUserDeclinedInstallationException) {
            stop(); askInstall = true; openStore()
            return "خدمة Google Play Services for AR غير مثبتة. ثبّتها من صفحة المتجر التي فُتحت ثم ارجع وأعد المحاولة"
        } catch (e: UnavailableApkTooOldException) {
            stop(); askInstall = true; openStore(); return "حدّث Google Play Services for AR من المتجر ثم أعد المحاولة"
        } catch (e: UnavailableDeviceNotCompatibleException) {
            stop(); return "جهازك غير مدعوم من ARCore. استخدم الصورة مع معايرة الأرضية بدلاً من ذلك"
        } catch (e: UnavailableSdkTooOldException) {
            stop(); return "مكتبة ARCore داخل التطبيق قديمة، أخبر المطوّر لتحديثها"
        } catch (e: Exception) {
            stop(); return "تعذر تشغيل ARCore (${e.javaClass.simpleName})"
        }
    }

    private fun openStore() {
        try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.ar.core"))) }
        catch (e: Exception) { try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.ar.core"))) } catch (e2: Exception) { } }
    }

    private fun initEgl() {
        val d = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY); val v = IntArray(2); EGL14.eglInitialize(d, v, 0, v, 1)
        val attr = intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1); val num = IntArray(1)
        EGL14.eglChooseConfig(d, attr, 0, cfgs, 0, 1, num, 0)
        val c = EGL14.eglCreateContext(d, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val sf = EGL14.eglCreatePbufferSurface(d, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(d, sf, sf, c)
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); texId = t[0]
        GLES20.glBindTexture(0x8D65, texId)   // GL_TEXTURE_EXTERNAL_OES
        dpy = d; ectx = c; esurf = sf
    }

    fun pause() { try { session?.pause() } catch (e: Exception) { } }
    fun resume() { try { session?.resume() } catch (e: Exception) { } }
    fun resetOrigin() { roomFromWorld = null }

    fun stop() {
        active = false
        try { session?.close() } catch (e: Exception) { }
        session = null
        val d = dpy
        if (d != null) {
            EGL14.eglMakeCurrent(d, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            esurf?.let { EGL14.eglDestroySurface(d, it) }; ectx?.let { EGL14.eglDestroyContext(d, it) }
        }
        dpy = null; ectx = null; esurf = null; roomFromWorld = null; frame = null
    }

    /** Tap on the floor: puts the room's centre there, with the room's back wall in the viewing direction. */
    fun tapFloor(x: Float, y: Float, plan: Plan): Boolean {
        val f = frame ?: return false
        for (h in f.hitTest(x, y)) {
            val t = h.trackable
            if (t is Plane && t.isPoseInPolygon(h.hitPose) && t.type == Plane.Type.HORIZONTAL_UPWARD_FACING) {
                val za = f.camera.pose.zAxis
                var fx = -za[0]; var fz = -za[2]
                val l = hypot(fx.toDouble(), fz.toDouble()).toFloat()
                if (l < 1e-3f) return false
                fx /= l; fz /= l
                val zx = -fx; val zz = -fz          // room +Z points toward the user
                val xx = zz; val xz = -zx           // room +X = Y x Z
                val ox = h.hitPose.tx() - xx * plan.w / 200f - zx * plan.d / 200f
                val oy = h.hitPose.ty()
                val oz = h.hitPose.tz() - xz * plan.w / 200f - zz * plan.d / 200f
                val m = floatArrayOf(xx, 0f, xz, 0f, 0f, 1f, 0f, 0f, zx, 0f, zz, 0f, ox, oy, oz, 1f)
                val inv = FloatArray(16)
                if (!Matrix.invertM(inv, 0, m, 0)) return false
                roomFromWorld = inv; return true
            }
        }
        return false
    }

    /** Call every frame. Updates the Filament camera from ARCore and returns the latest camera picture (same Bitmap instance). */
    fun update(vw: Int, vh: Int, r: Renderer3D): Bitmap? {
        val s = session ?: return null
        if (vw <= 0 || vh <= 0) return null
        if (vw != dw || vh != dh) { s.setDisplayGeometry(0, vw, vh); dw = vw; dh = vh }
        val f = try { s.update() } catch (e: Exception) { return bmp }
        frame = f
        val cam = f.camera
        if (cam.trackingState != TrackingState.TRACKING) return bmp
        try {
            val img = f.acquireCameraImage()
            try { toBitmap(img) } finally { img.close() }
        } catch (e: Exception) { }
        val rw = roomFromWorld
        if (rw != null) {
            val camW = FloatArray(16); cam.displayOrientedPose.toMatrix(camW, 0)
            val m = FloatArray(16); Matrix.multiplyMM(m, 0, rw, 0, camW, 0)
            val p = FloatArray(16); cam.getProjectionMatrix(p, 0, 0.05f, 50f)
            r.arModel = DoubleArray(16) { m[it].toDouble() }; r.arProj = DoubleArray(16) { p[it].toDouble() }
        }
        if (++n % 15 == 0) {
            val le = f.lightEstimate
            if (le.state == LightEstimate.State.VALID) r.setLight((0.4f + le.pixelIntensity * 1.1f).coerceIn(0.3f, 1.6f))
        }
        return bmp
    }

    /** YUV_420_888 -> ARGB, rotated by the sensor orientation so it is upright in portrait. */
    private fun toBitmap(img: Image) {
        val w = img.width; val h = img.height
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yB = yP.buffer; val uB = uP.buffer; val vB = vP.buffer
        val yRow = yP.rowStride; val uRow = uP.rowStride; val uPix = uP.pixelStride; val vRow = vP.rowStride; val vPix = vP.pixelStride
        val swap = sensor == 90 || sensor == 270
        val ow = if (swap) h else w; val oh = if (swap) w else h
        var b = bmp; var out = pix
        if (b == null || out == null || b.width != ow || b.height != oh) {
            b = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888); out = IntArray(ow * oh); bmp = b; pix = out
        }
        val bm = b!!; val ob = out!!
        for (y in 0 until h) {
            val yo = y * yRow; val uo = (y shr 1) * uRow; val vo = (y shr 1) * vRow
            for (x in 0 until w) {
                val yy = yB.get(yo + x).toInt() and 0xFF
                val u = (uB.get(uo + (x shr 1) * uPix).toInt() and 0xFF) - 128
                val v = (vB.get(vo + (x shr 1) * vPix).toInt() and 0xFF) - 128
                val r = (yy + ((1436 * v) shr 10)).coerceIn(0, 255)
                val g = (yy - ((352 * u + 731 * v) shr 10)).coerceIn(0, 255)
                val bl = (yy + ((1814 * u) shr 10)).coerceIn(0, 255)
                val di = when (sensor) { 90 -> x * h + (h - 1 - y); 270 -> (w - 1 - x) * h + y; 180 -> (h - 1 - y) * w + (w - 1 - x); else -> y * w + x }
                ob[di] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
        }
        bm.setPixels(ob, 0, ow, 0, 0, ow, oh)
    }
}
