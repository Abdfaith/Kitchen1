package com.kitchen.designer

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Automatic vanishing-point detection: Sobel edges -> gradient-oriented Hough lines -> RANSAC over pairwise line intersections.
 * A vanishing point is where parallel 3D lines meet in the photo; lines are consistent with a point when the line direction
 * points (within 2.5 degrees) at it. Returns up to 3 points in the pixel space of (outW x outH).
 */
object PerspectiveDetector {
    private class Ln(val c: Double, val s: Double, val rho: Double, val votes: Int) {
        val dx = -s; val dy = c                         // direction of the line
        val ax = rho * c; val ay = rho * s              // a point on the line
    }

    fun detect(src: Bitmap, outW: Int, outH: Int): List<DoubleArray> {
        val sc = min(1f, 480f / max(src.width, src.height))
        val w = max(16, (src.width * sc).toInt()); val h = max(16, (src.height * sc).toInt())
        val px = IntArray(w * h); Bitmap.createScaledBitmap(src, w, h, true).getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) { val c = px[it]; (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000 }
        val mag = IntArray(w * h); val th = FloatArray(w * h); val hist = IntArray(2100)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            val m = abs(gx) + abs(gy); mag[i] = m; th[i] = atan2(gy.toDouble(), gx.toDouble()).toFloat(); hist[min(m, 2099)]++
        }
        // keep the strongest ~7% of edge pixels
        var acc = 0; var thr = 2099; val target = (w * h * 0.07).toInt()
        while (thr > 40 && acc < target) { acc += hist[thr]; thr-- }
        val diag = hypot(w.toDouble(), h.toDouble()).toInt() + 1
        val bins = IntArray(180 * (2 * diag + 1))
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            if (mag[i] < thr) continue
            val t0 = Math.round(Math.toDegrees(th[i].toDouble())).toInt().let { ((it % 180) + 180) % 180 }
            for (dt in -1..1) {
                val t = (t0 + dt + 180) % 180; val r = Math.toRadians(t.toDouble())
                val rho = Math.round(x * cos(r) + y * sin(r)).toInt() + diag
                bins[t * (2 * diag + 1) + rho]++
            }
        }
        var maxV = 0; for (v in bins) if (v > maxV) maxV = v
        val minVotes = max(25, (maxV * 0.15).toInt())
        val cand = ArrayList<Ln>()
        for (t in 0 until 180) for (ri in 1 until 2 * diag) {
            val v = bins[t * (2 * diag + 1) + ri]
            if (v < minVotes) continue
            var peak = true
            for (dt in -1..1) for (dr in -1..1) {
                if (dt == 0 && dr == 0) continue
                val tt = (t + dt + 180) % 180
                if (bins[tt * (2 * diag + 1) + ri + dr] > v) peak = false
            }
            if (peak) { val r = Math.toRadians(t.toDouble()); cand.add(Ln(cos(r), sin(r), (ri - diag).toDouble(), v)) }
        }
        cand.sortByDescending { it.votes }
        val lines = ArrayList<Ln>()
        for (l in cand) {
            if (abs(l.dy) < 0.03 || abs(l.dx) < 0.17) continue    // ignore horizontal-ish (no convergence) and vertical-ish lines
            if (lines.none { o -> abs(o.dx * l.dy - o.dy * l.dx) < 0.05 && hypot(o.ax - l.ax, o.ay - l.ay) < 14.0 }) lines.add(l)
            if (lines.size >= 40) break
        }
        val result = ArrayList<DoubleArray>(); val pool = ArrayList(lines)
        repeat(3) {
            var bestP: DoubleArray? = null; var bestIn: List<Ln> = emptyList()
            for (i in pool.indices) for (j in i + 1 until pool.size) {
                val a = pool[i]; val b = pool[j]
                val det = a.c * b.s - a.s * b.c
                if (abs(det) < 0.05) continue
                val x = (a.rho * b.s - b.rho * a.s) / det; val y = (a.c * b.rho - b.c * a.rho) / det
                if (abs(x) > 20.0 * max(w, h) || abs(y) > 20.0 * max(w, h)) continue
                val inl = pool.filter { l -> val vx = x - l.ax; val vy = y - l.ay; val len = hypot(vx, vy); len > 1.0 && abs(l.dx * vy - l.dy * vx) / len < 0.0436 }
                if (inl.size > bestIn.size) { bestIn = inl; bestP = doubleArrayOf(x, y) }
            }
            val p = bestP
            if (p != null && bestIn.size >= 3) { result.add(doubleArrayOf(p[0] * outW / w, p[1] * outH / h)); pool.removeAll(bestIn.toSet()) }
        }
        return result
    }
}
