package com.kitchen.designer.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class Category { BASE, WALL_UNIT, APPLIANCE, COUNTER, DECOR, OPENING, FURNITURE }

/** Dimensions in cm. Built-in models are authored in real metres; imported ones carry k (scale) and off* (model-space offset). */
data class CatalogItem(
    val id: String, val name: String, val group: String, val category: Category, val asset: String,
    val w: Float, val d: Float, val h: Float, val elevation: Float = 0f,
    val mats: Map<String, String> = emptyMap(), val order: List<String> = emptyList(),
    val file: String? = null, val k: Float = 1f, val offX: Float = 0f, val offY: Float = 0f, val offZ: Float = 0f
) {
    val slots: List<String> get() = order.filter { it == "main" || it == "top" || it == "accent" }
}

class PlacedItem(
    val uid: Int, val item: CatalogItem, var x: Float, var z: Float, var rotY: Float = 0f,
    val mats: MutableMap<String, String> = mutableMapOf()
)

data class Piece(val cx: Float, val cz: Float, val len: Float, val rotY: Float, val thick: Float, val y0: Float, val h: Float)

class Plan(var w: Float, var d: Float, val h: Float) {
    val items = mutableListOf<PlacedItem>()
    var floorMat = "porcelain_beige"
    var wallMat = "offwhite"

    private class W(val a0: Float, val a1: Float, val perp: Float, val alongX: Boolean, val rot: Float, val openingRot: Float)

    /** Walls cut into boxes around doors/windows. */
    fun pieces(): List<Piece> {
        val t = 10f; val out = mutableListOf<Piece>()
        val walls = listOf(W(-t, w + t, -t / 2, true, 0f, 0f), W(-t, w + t, d + t / 2, true, 0f, 180f),
            W(0f, d, -t / 2, false, 90f, 90f), W(0f, d, w + t / 2, false, 90f, 270f))
        for (wl in walls) {
            fun box(a: Float, b: Float, y0: Float, hh: Float) {
                if (b - a > 0.5f && hh > 0.5f) {
                    val c = (a + b) / 2
                    out += Piece(if (wl.alongX) c else wl.perp, if (wl.alongX) wl.perp else c, b - a, wl.rot, t, y0, hh)
                }
            }
            val ops = items.filter { it.item.category == Category.OPENING && it.rotY == wl.openingRot }
                .sortedBy { if (wl.alongX) it.x else it.z }
            var cur = wl.a0
            for (o in ops) {
                val c = if (wl.alongX) o.x else o.z
                val a = c - o.item.w / 2; val b = c + o.item.w / 2; val e = o.item.elevation; val oh = o.item.h
                box(cur, a, 0f, h); box(a, b, 0f, e); box(a, b, e + oh, h - e - oh); cur = maxOf(cur, b)
            }
            box(cur, wl.a1, 0f, h)
        }
        return out
    }

    fun bom(): List<Pair<CatalogItem, Int>> = items.groupingBy { it.item }.eachCount().toList()

    fun toJson(): String {
        val o = JSONObject(); o.put("w", w.toDouble()); o.put("d", d.toDouble()); o.put("floor", floorMat); o.put("wall", wallMat)
        val arr = JSONArray()
        for (p in items) {
            val j = JSONObject(); j.put("uid", p.uid); j.put("id", p.item.id); j.put("x", p.x.toDouble()); j.put("z", p.z.toDouble()); j.put("rot", p.rotY.toDouble())
            val mo = JSONObject(); for ((k, v) in p.mats) mo.put(k, v); j.put("mats", mo); arr.put(j)
        }
        o.put("items", arr); return o.toString()
    }

    fun restore(json: String) {
        val o = JSONObject(json); w = o.getDouble("w").toFloat(); d = o.getDouble("d").toFloat()
        floorMat = o.optString("floor", floorMat); wallMat = o.optString("wall", wallMat); items.clear()
        val a = o.getJSONArray("items")
        for (i in 0 until a.length()) {
            val j = a.getJSONObject(i); val ci = Catalog.byId(j.getString("id")) ?: continue
            val p = PlacedItem(j.getInt("uid"), ci, j.getDouble("x").toFloat(), j.getDouble("z").toFloat(), j.getDouble("rot").toFloat())
            val mo = j.optJSONObject("mats")
            if (mo != null) { val ks = mo.keys(); while (ks.hasNext()) { val k = ks.next(); p.mats[k] = mo.getString(k) } }
            items += p
        }
    }
}

object Catalog {
    val items = mutableListOf<CatalogItem>()

    fun load(ctx: Context) {
        items.clear()
        parse(JSONArray(ctx.assets.open("catalog.json").bufferedReader().use { it.readText() }))
        val f = File(ctx.filesDir, "imports.json")
        if (f.exists()) try { parse(JSONArray(f.readText())) } catch (e: Exception) { }
    }

    private fun parse(a: JSONArray) {
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val mats = mutableMapOf<String, String>(); val mo = o.optJSONObject("mats")
            if (mo != null) { val ks = mo.keys(); while (ks.hasNext()) { val k = ks.next(); mats[k] = mo.getString(k) } }
            val order = ArrayList<String>(); val oa = o.optJSONArray("order")
            if (oa != null) for (j in 0 until oa.length()) order.add(oa.getString(j))
            items += CatalogItem(
                o.getString("id"), o.getString("name"), o.getString("grp"), Category.valueOf(o.getString("cat")), o.optString("asset", ""),
                o.getDouble("w").toFloat(), o.getDouble("d").toFloat(), o.getDouble("h").toFloat(), o.optDouble("elev", 0.0).toFloat(), mats, order,
                if (o.has("file")) o.getString("file") else null, o.optDouble("k", 1.0).toFloat(),
                o.optDouble("ox", 0.0).toFloat(), o.optDouble("oy", 0.0).toFloat(), o.optDouble("oz", 0.0).toFloat()
            )
        }
    }

    fun groups(): List<String> = items.map { it.group }.distinct()
    fun byId(id: String): CatalogItem? = items.firstOrNull { it.id == id }

    fun addImported(ctx: Context, ci: CatalogItem) {
        items += ci
        val arr = JSONArray()
        for (c in items) if (c.file != null) {
            arr.put(JSONObject().put("id", c.id).put("name", c.name).put("grp", c.group).put("cat", c.category.name).put("asset", "")
                .put("w", c.w.toDouble()).put("d", c.d.toDouble()).put("h", c.h.toDouble()).put("elev", c.elevation.toDouble())
                .put("file", c.file).put("k", c.k.toDouble()).put("ox", c.offX.toDouble()).put("oy", c.offY.toDouble()).put("oz", c.offZ.toDouble()))
        }
        File(ctx.filesDir, "imports.json").writeText(arr.toString())
    }
}

data class MatPreset(val id: String, val name: String, val grp: String, val tex: String, val r: Float, val g: Float, val b: Float, val metal: Float, val rough: Float)

object Materials {
    val list = mutableListOf<MatPreset>()
    fun load(ctx: Context) {
        list.clear()
        val a = JSONArray(ctx.assets.open("materials.json").bufferedReader().use { it.readText() })
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            list += MatPreset(o.getString("id"), o.getString("name"), o.getString("grp"), o.getString("tex"), o.getDouble("r").toFloat(), o.getDouble("g").toFloat(),
                o.getDouble("b").toFloat(), o.getDouble("metal").toFloat(), o.getDouble("rough").toFloat())
        }
    }
    fun byId(id: String?): MatPreset? = if (id == null) null else list.firstOrNull { it.id == id }
    fun groups(): List<String> = list.map { it.grp }.distinct()
}
