package com.kitchen.designer.model

import kotlin.math.abs
import kotlin.math.roundToInt

data class Snapped(val x: Float, val z: Float, val rot: Float)

/** Pure logic (no Android) so it can be unit-tested. cm / degrees. */
object SnapEngine {
    const val GRID = 5f        // grid size
    const val EDGE = 10f       // neighbour-edge snap distance
    const val WALL_PULL = 30f  // distance at which an item jumps to a wall

    fun half(item: CatalogItem, rot: Float): Pair<Float, Float> =
        if ((rot / 90f).roundToInt() and 1 == 1) item.d / 2 to item.w / 2 else item.w / 2 to item.d / 2

    private fun edgeDelta(lo: Float, hi: Float, cands: List<Float>): Float? {
        var best: Float? = null
        for (c in cands) for (e in floatArrayOf(lo, hi)) {
            val d = c - e
            if (abs(d) <= EDGE && (best == null || abs(d) < abs(best))) best = d
        }
        return best
    }

    fun snap(plan: Plan, m: PlacedItem, rx: Float, rz: Float): Snapped {
        var x = rx; var z = rz; var rot = m.rotY
        var lockX = false; var lockZ = false
        val ci = m.item
        if (ci.category == Category.OPENING) { // doors/windows live inside the wall thickness and slide along it
            val near = minOf(minOf(rz, plan.d - rz), minOf(rx, plan.w - rx)); val hw = ci.w / 2
            fun g(v: Float) = (v / GRID).roundToInt() * GRID
            return when (near) {
                rz -> Snapped(g(rx).coerceIn(hw, plan.w - hw), -ci.d / 2, 0f)
                plan.d - rz -> Snapped(g(rx).coerceIn(hw, plan.w - hw), plan.d + ci.d / 2, 180f)
                rx -> Snapped(-ci.d / 2, g(rz).coerceIn(hw, plan.d - hw), 90f)
                else -> Snapped(plan.w + ci.d / 2, g(rz).coerceIn(hw, plan.d - hw), 270f)
            }
        }
        if (ci.category != Category.DECOR) {
            val dN = rz; val dS = plan.d - rz; val dW = rx; val dE = plan.w - rx
            val near = minOf(minOf(dN, dS), minOf(dW, dE))
            if (near < WALL_PULL) when (near) {
                dN -> { rot = 0f; z = ci.d / 2; lockZ = true }
                dS -> { rot = 180f; z = plan.d - ci.d / 2; lockZ = true }
                dW -> { rot = 90f; x = ci.d / 2; lockX = true }
                else -> { rot = 270f; x = plan.w - ci.d / 2; lockX = true }
            }
        }
        val (hx, hz) = half(ci, rot)
        val xs = mutableListOf(0f, plan.w); val zs = mutableListOf(0f, plan.d)
        for (o in plan.items) if (o !== m && o.item.category != Category.OPENING) {
            val (ox, oz) = half(o.item, o.rotY)
            xs += listOf(o.x - ox, o.x + ox); zs += listOf(o.z - oz, o.z + oz)
        }
        if (!lockX) x += edgeDelta(x - hx, x + hx, xs) ?: ((x / GRID).roundToInt() * GRID - x)
        if (!lockZ) z += edgeDelta(z - hz, z + hz, zs) ?: ((z / GRID).roundToInt() * GRID - z)
        return Snapped(x.coerceIn(hx, plan.w - hx), z.coerceIn(hz, plan.d - hz), rot)
    }
}
