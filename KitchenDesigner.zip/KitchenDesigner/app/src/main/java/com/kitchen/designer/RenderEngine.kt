package com.kitchen.designer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.kitchen.designer.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Image-to-Realism engine. 1) local(): builds the render JSON from the project itself (offline, exact layout + PBR materials).
 * 2) claudePrompt(): sends the picture to Claude with the engine instructions below. 3) a1111()/generic(): sends the JSON + picture to an image server.
 */
object RenderEngine {
    const val SYSTEM = """# Role & Objective
You are an elite Photorealistic Architectural & Design Rendering Engine (Image-to-Realism AI). Your core task is to analyze standard input designs (2D sketches, CAD wireframes, flat 3D blocks, or basic layouts) and translate them into hyper-realistic, physically accurate photographic prompts while strictly preserving the exact spatial geometry and proportions.

# Processing Pipeline (Step-by-Step)
When an input image or design specification is provided, execute the following analysis:
1. **Structural Lock (Geometry & Layout):** Identify the exact placement of walls, cabinets, furniture, windows, and perspective lines. Do NOT alter, add, or remove structural elements.
2. **Material Mapping (PBR Texturing):** Replace flat colors or basic sketches with Physically Based Rendering (PBR) materials (e.g., convert flat brown into "natural oak wood with visible fine grain and matte varnish"; convert white surfaces into "honed Calacatta marble with subtle grey veining" or "brushed stainless steel").
3. **Lighting & Optics Calculation:** Apply realistic lighting physics based on window placements and light fixtures. Enforce Ray-Traced Global Illumination, Ambient Occlusion in corners, and soft natural shadow falloff.
4. **Camera & Lens Simulation:** Frame the output as a real-world photograph captured on a full-frame DSLR camera (e.g., 24mm or 35mm architectural tilt-shift lens, f/8 aperture for deep depth of field, crisp focus).

# Output Format
Respond ONLY with the final engineered rendering parameters in the following JSON structure so the image generation backend can execute it directly:

{
  "positive_prompt": "[Detailed description of the scene, exact layout, upgraded PBR materials, lighting physics, and camera settings, ending with: photorealistic, raw photo, 8k resolution, ArchViz, Unreal Engine 5, V-Ray render, high surface imperfections]",
  "negative_prompt": "sketch, wireframe, cartoon, CGI, 3D model look, plastic texture, flat shading, oversaturated, distorted perspective, deformed lines, blurry, watermark, low quality",
  "controlnet_settings": {
    "preprocessor": "canny_or_mlsd",
    "conditioning_scale": 0.95,
    "guidance_scale": 7.5,
    "denoising_strength": 0.65
  }
}"""

    private const val TAIL = "photorealistic, raw photo, 8k resolution, ArchViz, Unreal Engine 5, V-Ray render, high surface imperfections"
    private const val NEG = "sketch, wireframe, cartoon, CGI, 3D model look, plastic texture, flat shading, oversaturated, distorted perspective, deformed lines, blurry, watermark, low quality"
    private val KITCHEN = setOf("خزائن سفلية", "أحواض", "خزائن علوية", "أعمدة وتخزين", "أسطح وجزر", "باكسبلاش", "أجهزة", "شفاطات")
    private val ORDER = listOf("back wall", "left wall", "right wall", "front wall", "centre of the room")

    private fun mat(id: String?): String { val m = Materials.byId(id) ?: return ""; return if (m.en.isNotBlank()) m.en else m.name }
    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)

    private fun sideOf(p: PlacedItem, plan: Plan): String {
        if (p.item.category == Category.OPENING) return when (p.rotY.toInt()) { 0 -> "back wall"; 180 -> "front wall"; 90 -> "left wall"; else -> "right wall" }
        val d = listOf(p.z to "back wall", plan.d - p.z to "front wall", p.x to "left wall", plan.w - p.x to "right wall")
        val m = d.minByOrNull { it.first } ?: return "centre of the room"
        return if (m.first < 60f) m.second else "centre of the room"
    }

    private fun describe(p: PlacedItem): String {
        val ci = p.item; val eff = ci.mats + p.mats
        val nm = if (ci.en.isNotBlank()) ci.en else ci.name
        val parts = ArrayList<String>()
        val main = mat(eff["main"]); val top = mat(eff["top"])
        if (main.isNotBlank()) parts.add(main)
        if (top.isNotBlank()) parts.add("$top surface")
        return if (parts.isEmpty()) nm else "$nm in ${parts.joinToString(" with ")}"
    }

    /** Deterministic engine: exact layout + PBR materials + lighting + lens, in the required JSON structure. */
    fun local(plan: Plan, photo: Boolean, leds: Int, preprocessor: String = "mlsd"): JSONObject {
        val kind = if (plan.items.any { it.item.group in KITCHEN }) "kitchen" else "interior"
        val bySide = plan.items.groupBy { sideOf(it, plan) }
        val layout = ArrayList<String>()
        for (s in ORDER) {
            val list = bySide[s] ?: continue
            val sorted = list.sortedBy { if (s == "left wall" || s == "right wall") it.z else it.x }
            val counts = LinkedHashMap<String, Int>()
            for (p in sorted) { val t = describe(p); counts[t] = (counts[t] ?: 0) + 1 }
            val txt = counts.entries.joinToString(", ") { e -> if (e.value > 1) "${e.value} x ${e.key}" else e.key }
            layout.add(if (s == "centre of the room") "in the centre of the room: $txt" else "along the $s (left to right as seen from the room entrance): $txt")
        }
        val windows = plan.items.filter { it.item.id.startsWith("win") }.map { sideOf(it, plan) }.distinct()
        val sb = StringBuilder()
        sb.append("Photograph of a modern $kind, room ${f1(plan.w / 100f)} x ${f1(plan.d / 100f)} m with ${f1(plan.h / 100f)} m ceiling, ")
        sb.append("exact layout and perspective locked to the input design, no elements added, removed or moved. ")
        if (layout.isNotEmpty()) sb.append(layout.joinToString("; ")).append(". ")
        if (photo) sb.append("The existing walls, floor and perspective of the original photograph stay unchanged; only the added furniture is rendered with matching light. ")
        else sb.append("Floor in ${mat(plan.floorMat)}, walls in ${mat(plan.wallMat)}. ")
        sb.append(if (windows.isNotEmpty()) "Soft natural daylight entering through the window on the ${windows.joinToString(" and ")}, " else "Soft diffused natural daylight, ")
        if (leds > 0) sb.append("warm 2700K LED strip lighting beneath the wall cabinets casting a soft glow on the worktop and backsplash, ")
        sb.append("ray-traced global illumination with colour bleeding, ambient occlusion in all corners and under cabinets, soft natural shadow falloff, physically accurate specular highlights. ")
        sb.append("Camera: full-frame DSLR, 24mm architectural tilt-shift lens, eye level, vertical lines corrected, f/8, ISO 100, deep depth of field, crisp focus edge to edge. ")
        sb.append(TAIL)
        val cn = JSONObject().put("preprocessor", preprocessor).put("conditioning_scale", 0.95).put("guidance_scale", 7.5).put("denoising_strength", 0.65)
        return JSONObject().put("positive_prompt", sb.toString()).put("negative_prompt", "$NEG, extra cabinets, missing cabinets, moved appliances, warped geometry, text, logo").put("controlnet_settings", cn)
    }

    // ---------------------------------------------------------------- network
    private fun httpPost(url: String, headers: Map<String, String>, body: String, timeoutMs: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = timeoutMs; c.doOutput = true
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(300)}")
        return text
    }

    private fun httpGet(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        for ((k, v) in headers) c.setRequestProperty(k, v)
        val code = c.responseCode
        val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: ${text.take(200)}")
        return text
    }

    /** Claude analyses the picture with the engine instructions above and returns the render JSON. */
    fun claudePrompt(apiKey: String, model: String, imgB64: String, sceneNotes: String): JSONObject {
        val src = JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", imgB64)
        val content = JSONArray().put(JSONObject().put("type", "image").put("source", src))
            .put(JSONObject().put("type", "text").put("text", "Input design image attached. Authoritative scene data from the design tool (preserve exactly):\n$sceneNotes\n\nReturn only the JSON."))
        val body = JSONObject().put("model", model).put("max_tokens", 2000).put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content))).toString()
        val resp = httpPost("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01", "content-type" to "application/json"), body, 120_000)
        val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        val s = text.indexOf('{'); val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw RuntimeException("no JSON in reply")
        return JSONObject(text.substring(s, e + 1))
    }

    private fun normPre(p: String) = if (p.lowercase().contains("mlsd")) "mlsd" else "canny"

    private fun resolveModel(root: String, pre: String): String = try {
        val list = JSONObject(httpGet("$root/controlnet/model_list")).getJSONArray("model_list")
        var found = "control_v11p_sd15_$pre"
        for (i in 0 until list.length()) { val n = list.getString(i); if (n.contains(pre, true)) { found = n; break } }
        found
    } catch (e: Exception) { "control_v11p_sd15_$pre" }

    private fun decodeImage(b64: String): Bitmap {
        val bytes = Base64.decode(b64.substringAfter(","), Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw RuntimeException("invalid image")
    }

    /** Stable Diffusion WebUI (AUTOMATIC1111 / Forge) started with --api and the ControlNet extension. */
    fun a1111(base: String, j: JSONObject, imgB64: String, w: Int, h: Int): Bitmap {
        val root = base.trim().trimEnd('/'); val cn = j.optJSONObject("controlnet_settings") ?: JSONObject()
        val pre = normPre(cn.optString("preprocessor", "mlsd"))
        val unit = JSONObject().put("input_image", imgB64).put("module", pre).put("model", resolveModel(root, pre))
            .put("weight", cn.optDouble("conditioning_scale", 0.95)).put("control_mode", 0).put("guidance_start", 0.0).put("guidance_end", 1.0)
        val body = JSONObject().put("init_images", JSONArray().put(imgB64)).put("prompt", j.getString("positive_prompt")).put("negative_prompt", j.optString("negative_prompt", ""))
            .put("denoising_strength", cn.optDouble("denoising_strength", 0.65)).put("cfg_scale", cn.optDouble("guidance_scale", 7.5))
            .put("steps", 30).put("sampler_name", "DPM++ 2M Karras").put("width", w).put("height", h)
            .put("alwayson_scripts", JSONObject().put("controlnet", JSONObject().put("args", JSONArray().put(unit)))).toString()
        val resp = httpPost("$root/sdapi/v1/img2img", mapOf("Content-Type" to "application/json"), body, 600_000)
        return decodeImage(JSONObject(resp).getJSONArray("images").getString(0))
    }

    // ---------------------------------------------------------------- AI Horde (free, anonymous key 0000000000)
    private const val SHORT_TAIL = "photorealistic, raw photo, 8k, ArchViz, V-Ray render"
    private const val AGENT = "KitchenDesigner:1.0:app"

    /** Horde prompts are limited to ~1000 chars: positive ### negative. */
    private fun hordePrompt(j: JSONObject): String {
        var pos = j.getString("positive_prompt")
        if (pos.length > 740) pos = pos.take(690).trimEnd(' ', ',', '.') + ", " + SHORT_TAIL
        val neg = j.optString("negative_prompt", "").take(200)
        return if (neg.isBlank()) pos else "$pos ### $neg"
    }

    private fun hordeBody(j: JSONObject, imgB64: String, w: Int, h: Int, control: Boolean): String {
        val cn = j.optJSONObject("controlnet_settings") ?: JSONObject()
        val params = JSONObject().put("sampler_name", "k_euler_a").put("cfg_scale", cn.optDouble("guidance_scale", 7.5))
            .put("width", w).put("height", h).put("karras", true).put("steps", 25).put("n", 1)
        val body = JSONObject().put("prompt", hordePrompt(j)).put("r2", true).put("slow_workers", true).put("trusted_workers", false).put("source_image", imgB64)
        if (control) params.put("control_type", if (normPre(cn.optString("preprocessor", "mlsd")) == "mlsd") "hough" else "canny")
        else { params.put("denoising_strength", cn.optDouble("denoising_strength", 0.65)); body.put("source_processing", "img2img") }
        return body.put("params", params).toString()
    }

    private fun runHorde(root: String, key: String, body: String, maxWaitMs: Long, onStatus: (String) -> Unit): Bitmap? {
        val hdr = mapOf("apikey" to key, "Content-Type" to "application/json", "Client-Agent" to AGENT)
        val ca = mapOf("Client-Agent" to AGENT)
        val id = JSONObject(httpPost("$root/generate/async", hdr, body, 60_000)).getString("id")
        val start = System.currentTimeMillis()
        while (true) {
            Thread.sleep(4000)
            val chk = JSONObject(httpGet("$root/generate/check/$id", ca))
            onStatus("في الطابور: ${chk.optInt("queue_position")} - المتبقي تقريباً ${chk.optInt("wait_time")} ث")
            if (chk.optBoolean("faulted")) throw RuntimeException("فشلت المهمة على الخادم")
            if (chk.optBoolean("done")) break
            if (System.currentTimeMillis() - start > maxWaitMs) {
                try { val c = URL("$root/generate/status/$id").openConnection() as HttpURLConnection; c.requestMethod = "DELETE"; c.setRequestProperty("Client-Agent", AGENT); c.responseCode } catch (e: Exception) { }
                return null
            }
        }
        val st = JSONObject(httpGet("$root/generate/status/$id", ca))
        val gen = st.getJSONArray("generations").getJSONObject(0)
        if (gen.optBoolean("censored")) throw RuntimeException("حجبت الشبكة الصورة، أعد المحاولة")
        val img = gen.getString("img")
        if (img.startsWith("http")) {
            return URL(img).openStream().use { BitmapFactory.decodeStream(it) } ?: throw RuntimeException("تعذر تنزيل الصورة")
        }
        return decodeImage(img)
    }

    /** Free community cluster. ControlNet (hough = lines / canny) keeps the layout; falls back to img2img if no ControlNet worker answers. */
    fun horde(base: String, key: String, j: JSONObject, imgB64: String, w: Int, h: Int, control: Boolean, onStatus: (String) -> Unit): Bitmap {
        val root = base.trim().trimEnd('/'); val k = key.ifBlank { "0000000000" }
        if (control) {
            try {
                onStatus("إرسال الطلب (ControlNet)...")
                val r = runHorde(root, k, hordeBody(j, imgB64, w, h, true), 5 * 60_000L, onStatus)
                if (r != null) return r
                onStatus("لا يوجد عامل ControlNet متاح، التحويل إلى img2img...")
            } catch (e: RuntimeException) { onStatus("ControlNet غير متاح (${e.message?.take(60)})، التحويل إلى img2img...") }
        }
        return runHorde(root, k, hordeBody(j, imgB64, w, h, false), 10 * 60_000L, onStatus) ?: throw RuntimeException("انتهت مهلة الانتظار، حاول لاحقاً")
    }

    /** Any custom backend: receives {image, positive_prompt, negative_prompt, controlnet_settings}; returns {image} or {images:[...]} (base64). */
    fun generic(url: String, j: JSONObject, imgB64: String): Bitmap {
        val body = JSONObject().put("image", imgB64).put("positive_prompt", j.getString("positive_prompt")).put("negative_prompt", j.optString("negative_prompt", ""))
            .put("controlnet_settings", j.optJSONObject("controlnet_settings") ?: JSONObject()).toString()
        val r = JSONObject(httpPost(url.trim(), mapOf("Content-Type" to "application/json"), body, 600_000))
        val b64 = if (r.has("image")) r.getString("image") else r.getJSONArray("images").getString(0)
        return decodeImage(b64)
    }
}
