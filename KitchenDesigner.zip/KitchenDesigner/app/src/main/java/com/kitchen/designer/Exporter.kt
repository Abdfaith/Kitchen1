package com.kitchen.designer

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.kitchen.designer.model.*
import java.io.File
import kotlin.math.min

/** Two-page A4 PDF: page 1 = 3D render + to-scale floor plan, page 2 = bill of materials. */
object Exporter {
    private fun col(c: Category) = when (c) {
        Category.BASE -> 0xFFB88557; Category.WALL_UNIT -> 0xFF8FA0A0; Category.APPLIANCE -> 0xFFBFC4CC
        Category.COUNTER -> 0xFFE8E8E8; Category.DECOR -> 0xFF5A9040; Category.OPENING -> 0xFF4FA3D1; Category.FURNITURE -> 0xFF9A7BC0
    }.toInt()

    fun pdf(plan: Plan, shot: Bitmap?, out: File) {
        val doc = PdfDocument(); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); var c = page.canvas
        p.color = Color.BLACK; p.textAlign = Paint.Align.RIGHT; p.textSize = 24f; p.isFakeBoldText = true
        c.drawText("مخطط تصميم المطبخ", 555f, 55f, p)
        p.isFakeBoldText = false; p.textSize = 13f; p.color = 0xFF555555.toInt()
        c.drawText("أبعاد الغرفة: ${plan.w.toInt()} × ${plan.d.toInt()} × ${plan.h.toInt()} سم", 555f, 78f, p)
        shot?.let {
            val f = min(515f / it.width, 330f / it.height); val w2 = it.width * f; val h2 = it.height * f
            c.drawBitmap(it, null, RectF(40f + (515f - w2) / 2, 95f, 40f + (515f - w2) / 2 + w2, 95f + h2), p)
        }
        // floor plan to scale
        val sf = min(455f / plan.w, 290f / plan.d); val ox = 40f + (515f - plan.w * sf) / 2; val oy = 465f
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.BLACK
        c.drawRect(ox, oy, ox + plan.w * sf, oy + plan.d * sf, p)
        for (it in plan.items.sortedBy { it.item.elevation }) {
            val (hx, hz) = SnapEngine.half(it.item, it.rotY)
            val r = RectF(ox + (it.x - hx) * sf, oy + (it.z - hz) * sf, ox + (it.x + hx) * sf, oy + (it.z + hz) * sf)
            p.style = Paint.Style.FILL; p.color = col(it.item.category); p.alpha = if (it.item.elevation >= 140f) 120 else 255; c.drawRect(r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.BLACK; c.drawRect(r, p)
            p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = 8f; c.drawText(it.item.name, r.centerX(), r.centerY() + 3f, p)
        }
        p.textAlign = Paint.Align.CENTER; p.textSize = 11f; p.color = 0xFF333333.toInt()
        c.drawText("${plan.w.toInt()} سم", ox + plan.w * sf / 2, oy - 8f, p)
        c.drawText("${plan.d.toInt()} سم", ox + plan.w * sf / 2, oy + plan.d * sf + 16f, p)
        doc.finishPage(page)

        page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 2).create()); c = page.canvas
        p.style = Paint.Style.FILL; p.color = Color.BLACK; p.textAlign = Paint.Align.RIGHT; p.textSize = 22f; p.isFakeBoldText = true
        c.drawText("قائمة الكميات", 555f, 55f, p)
        p.textSize = 13f; var y = 95f
        c.drawText("العنصر", 555f, y, p); p.textAlign = Paint.Align.CENTER; c.drawText("الأبعاد (سم)", 320f, y, p); c.drawText("الكمية", 90f, y, p)
        p.isFakeBoldText = false; var total = 0
        for ((item, n) in plan.bom()) {
            y += 28f; total += n
            p.color = 0xFFCCCCCC.toInt(); c.drawLine(40f, y - 18f, 555f, y - 18f, p); p.color = Color.BLACK
            p.textAlign = Paint.Align.RIGHT; c.drawText(item.name, 555f, y, p)
            p.textAlign = Paint.Align.CENTER; c.drawText("${item.w.toInt()} × ${item.d.toInt()} × ${item.h.toInt()}", 320f, y, p); c.drawText("$n", 90f, y, p)
        }
        y += 34f; p.isFakeBoldText = true; p.textAlign = Paint.Align.RIGHT; c.drawText("إجمالي القطع: $total", 555f, y, p)
        doc.finishPage(page)
        out.outputStream().use { doc.writeTo(it) }; doc.close()
    }
}
