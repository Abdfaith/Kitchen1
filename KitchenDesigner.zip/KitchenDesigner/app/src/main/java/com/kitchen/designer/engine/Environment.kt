package com.kitchen.designer.engine

import com.google.android.filament.Engine
import com.google.android.filament.IndirectLight
import com.google.android.filament.Scene
import com.google.android.filament.Texture
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/**
 * Procedural studio environment (no HDR file needed): sky gradient, warm horizon, floor bounce and two window softboxes.
 * Builds a roughness-prefiltered reflection cubemap (analytic blur per mip) + 3-band SH irradiance.
 * The environment is symmetric in X and Z so cubemap handedness conventions cannot flip it.
 */
object Environment {
    private fun sm(a: Float, b: Float, x: Float): Float { val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t) }

    private fun radiance(x: Float, y: Float, z: Float, blur: Float): FloatArray {
        val sky = sm(0f, 1f, y); val hz = floatArrayOf(.95f, .88f, .78f); val zen = floatArrayOf(.40f, .58f, .90f); val fl = floatArrayOf(.30f, .28f, .26f)
        val up = sm(-.12f - blur * .3f, .12f + blur * .3f, y)
        val win = sm(.5f - .25f * blur, .75f + .2f * blur, abs(z)) * sm(-.7f - blur, -.45f + blur * .2f, x) * (1 - sm(.45f - blur * .2f, .7f + blur, x)) *
            sm(.0f - blur * .2f, .18f + blur * .3f, y) * (1 - sm(.55f, .8f + blur * .3f, y))
        val amp = 7f / (1f + blur * blur * 18f)
        return FloatArray(3) { c -> (fl[c] + (hz[c] + (zen[c] - hz[c]) * sky - fl[c]) * up) + win * amp }
    }

    private fun dir(face: Int, s: Float, t: Float): FloatArray {
        val v = when (face) { 0 -> floatArrayOf(1f, -t, -s); 1 -> floatArrayOf(-1f, -t, s); 2 -> floatArrayOf(s, 1f, t)
            3 -> floatArrayOf(s, -1f, -t); 4 -> floatArrayOf(s, -t, 1f); else -> floatArrayOf(-s, -t, -1f) }
        val n = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return floatArrayOf(v[0] / n, v[1] / n, v[2] / n)
    }

    fun apply(engine: Engine, scene: Scene, intensity: Float = 30_000f) {
        val levels = 5; val base = 64
        val tex = Texture.Builder().width(base).height(base).levels(levels).sampler(Texture.Sampler.SAMPLER_CUBEMAP)
            .format(Texture.InternalFormat.R11F_G11F_B10F).build(engine)
        for (l in 0 until levels) {
            val size = base shr l; val blur = l / (levels - 1f)
            val buf = ByteBuffer.allocateDirect(6 * size * size * 3 * 4).order(ByteOrder.nativeOrder())
            for (f in 0 until 6) for (py in 0 until size) for (px in 0 until size) {
                val d = dir(f, (px + .5f) / size * 2 - 1, (py + .5f) / size * 2 - 1)
                radiance(d[0], d[1], d[2], blur).forEach { buf.putFloat(it) }
            }
            buf.rewind(); val fb = size * size * 3 * 4
            tex.setImage(engine, l, Texture.PixelBufferDescriptor(buf, Texture.Format.RGB, Texture.Type.FLOAT), IntArray(6) { it * fb })
        }
        // SH irradiance, pre-convolved with the cosine lobe and the Lambertian 1/pi (Filament's layout: 1,y,z,x,xy,yz,3z^2-1,xz,x^2-y^2)
        val sh = Array(9) { DoubleArray(3) }; val w = 64; val h = 32
        for (j in 0 until h) for (i in 0 until w) {
            val th = PI * (j + .5) / h; val ph = 2 * PI * (i + .5) / w
            val x = (sin(th) * cos(ph)).toFloat(); val y = cos(th).toFloat(); val z = (sin(th) * sin(ph)).toFloat()
            val dw = (2 * PI / w) * (PI / h) * sin(th); val r = radiance(x, y, z, 0f)
            val b = doubleArrayOf(.282095, .488603 * y, .488603 * z, .488603 * x, 1.092548 * x * y, 1.092548 * y * z,
                .315392 * (3 * z * z - 1), 1.092548 * x * z, .546274 * (x * x - y * y))
            for (k in 0 until 9) for (c in 0 until 3) sh[k][c] += r[c] * b[k] * dw
        }
        val a = doubleArrayOf(1.0, 2.0 / 3, 2.0 / 3, 2.0 / 3, .25, .25, .25, .25, .25)
        val k = doubleArrayOf(.282095, .488603, .488603, .488603, 1.092548, 1.092548, .315392, 1.092548, .546274)
        val out = FloatArray(27) { n -> (sh[n / 3][n % 3] * a[n / 3] * k[n / 3]).toFloat() }
        scene.indirectLight = IndirectLight.Builder().reflections(tex).irradiance(3, out).intensity(intensity).build(engine)
    }
}
