plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.kitchen.designer"
    compileSdk = 34
    defaultConfig { applicationId = "com.kitchen.designer"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("glb", "ktx", "filamat") }
}
dependencies {
    val f = "1.51.0"
    implementation("com.google.android.filament:filament-android:$f")
    implementation("com.google.android.filament:gltfio-android:$f")
    implementation("com.google.android.filament:filament-utils-android:$f")
    implementation("androidx.core:core-ktx:1.13.1")
}
