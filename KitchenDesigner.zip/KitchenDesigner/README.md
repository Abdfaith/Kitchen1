# Kitchen Designer (Kotlin + Filament)
Build: upload KitchenDesigner.zip + .github/workflows/build-apk.yml to GitHub (see chat), or open in Android Studio.
Regenerate catalog/materials/icons: `python3 tools/make_assets.py` (numpy, pillow).
Import your own models: .glb / .obj from the app (Elements tab > + import / + from URL).
