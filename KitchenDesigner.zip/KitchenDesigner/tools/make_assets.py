"""Procedural assets: PBR texture presets, parametric kitchen/home models (.glb), catalog.json, materials.json, icons.
Needs numpy + pillow.  Run: python3 tools/make_assets.py"""
import json, struct, io, os, math, random
import numpy as np
from PIL import Image, ImageDraw
HERE = os.path.dirname(os.path.abspath(__file__)); A = os.path.join(HERE, '..', 'app', 'src', 'main', 'assets')
for d in ('models', 'tex', 'icons'):
    os.makedirs(os.path.join(A, d), exist_ok=True)
    for f in os.listdir(os.path.join(A, d)): os.remove(os.path.join(A, d, f))
N = 384
def rgb(h): h = h.lstrip('#'); return np.array([int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)])
def pink(n, seed, beta=1.6, ax=1.0, ay=1.0):
    r = np.random.default_rng(seed); fx = np.fft.fftfreq(n)[None, :] * ax; fy = np.fft.fftfreq(n)[:, None] * ay
    f = np.sqrt(fx**2 + fy**2); f[0, 0] = 1; s = np.fft.fft2(r.standard_normal((n, n))) / f**beta; s[0, 0] = 0
    a = np.real(np.fft.ifft2(s)); return (a - a.min()) / (a.max() - a.min())
def lerp(a, b, t): return np.array(a) + (np.array(b) - np.array(a)) * np.asarray(t)[..., None]
def png(a, mode='RGB'):
    b = io.BytesIO(); Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8), mode).save(b, 'PNG', optimize=True); return b.getvalue()
def XY(): return np.meshgrid(np.arange(N) / N, np.arange(N) / N)

def g_wood(c1, c2, f=10, wave=.3, seed=1):
    xx, yy = XY(); g = pink(N, seed, 1.1, ax=.015); rings = .5 + .5 * np.sin((yy * f + wave * pink(N, seed + 1, 1.5)) * 2 * math.pi); fine = pink(N, seed + 2, .8, ax=.01)
    return lerp(rgb(c1), rgb(c2), .45 * g + .3 * rings + .25 * fine)
def g_marble(base, vein, k=1, seed=3, wid=.06):
    xx, yy = XY(); n = pink(N, seed, 1.8)
    v1 = 1 - np.clip(np.abs(np.sin((xx * 3 * k + yy * 2 * k + 2.2 * n) * math.pi)) / wid, 0, 1)
    v2 = (1 - np.clip(np.abs(np.sin((xx * -2 * k + yy * 4 * k + 3 * pink(N, seed + 3, 1.8)) * math.pi)) / (wid / 2), 0, 1)) * .5
    b = lerp(rgb(base), rgb(base) * .85, pink(N, seed + 1, 2.2) * .6); return lerp(b, rgb(vein), np.maximum(v1 * .8, v2))
def g_speckle(base, c2, seed=5, d=.3):
    n = pink(N, seed, .4); m = (n > 1 - d * .5).astype(float); b = lerp(rgb(base), rgb(c2), m * .7)
    return b * (.94 + .1 * pink(N, seed + 1, 1.5))[..., None]
def g_terrazzo(base, seed=6):
    r = random.Random(seed); im = Image.new('RGB', (N, N), tuple(int(c * 255) for c in rgb(base))); d = ImageDraw.Draw(im)
    for _ in range(260):
        x, y = r.randrange(N), r.randrange(N); s = r.randrange(3, 10); c = r.choice(['#b0a89e', '#5c5750', '#d9cbb5', '#8a6f5a', '#e8e2d8'])
        for dx in (-N, 0, N):
            for dy in (-N, 0, N): d.ellipse([x + dx - s, y + dy - s * .7, x + dx + s, y + dy + s * .7], fill=c)
    return np.asarray(im) / 255.0
def g_concrete(c, seed=23): return lerp(rgb(c) * .88, np.minimum(rgb(c) * 1.06, 1), pink(N, seed, 2.0))
def g_strata(c1, c2, seed=9):
    xx, yy = XY(); n = pink(N, seed, 1.4, ax=.05); t = .5 + .5 * np.sin((yy * 14 + 2 * n) * 2 * math.pi); pits = (pink(N, seed + 1, .5) > .93) * .25
    return np.clip(lerp(rgb(c1), rgb(c2), t * .6 + .2 * pink(N, seed + 2, 1.2)) * (1 - pits)[..., None], 0, 1)
def g_brushed(c1, c2, seed=5): return lerp(rgb(c1), rgb(c2), pink(N, seed, 1.0, ax=.01))
def g_subway(tile, grout, rows=4, cols=2, seed=7, var=.05):
    a = np.ones((N, N, 3)) * rgb(grout); n = pink(N, seed, 2) * .04; rh = N // rows; cw = N // cols; r = random.Random(seed)
    for i in range(rows):
        off = (i % 2) * cw // 2
        for j in range(-1, cols + 1):
            x0 = j * cw + off; y0 = i * rh; xa = max(x0 + 3, 0); xb = min(x0 + cw, N)
            if xa < xb: a[y0 + 3:y0 + rh, xa:xb] = rgb(tile) * (1 + (r.random() - .5) * var)
    return np.clip(a + n[..., None] - .02, 0, 1)
def g_squares(n, tile, grout, var=.05, seed=8):
    a = np.ones((N, N, 3)) * rgb(grout); s = N // n; r = random.Random(seed)
    for i in range(n):
        for j in range(n): a[i * s + 2:(i + 1) * s, j * s + 2:(j + 1) * s] = np.minimum(rgb(tile) * (1 + (r.random() - .5) * var * 2), 1)
    return np.clip(a, 0, 1)
def g_checker(c1, c2, n=4):
    i, j = np.meshgrid(np.arange(N) // (N // n), np.arange(N) // (N // n)); m = ((i + j) % 2)[..., None]; return rgb(c1) * (1 - m) + rgb(c2) * m
def g_diamond(tile, grout, k=4):
    xx, yy = XY(); u = (xx + yy) * k; v = (xx - yy) * k; fu = u - np.floor(u); fv = v - np.floor(v)
    edge = (np.minimum(fu, 1 - fu) < .035) | (np.minimum(fv, 1 - fv) < .035)
    return np.clip(np.where(edge[..., None], rgb(grout), rgb(tile)) + pink(N, 3, 2)[..., None] * .03 - .015, 0, 1)
def g_planks(c1, c2, cols=6, seed=11):
    base = np.rot90(g_wood(c1, c2, 9, .3, seed)); a = np.zeros((N, N, 3)); r = random.Random(seed); w = N // cols
    for j in range(cols):
        a[:, j * w:(j + 1) * w] = np.roll(base, r.randrange(N), axis=0)[:, j * w:(j + 1) * w] * (1 + (r.random() - .5) * .14)
        a[r.randrange(N - 2):][:2, j * w:(j + 1) * w] *= .55; a[:, j * w:j * w + 2] *= .55
    return np.clip(a, 0, 1)
def g_fabric(c, seed=13, f=96):
    xx, yy = XY(); w = .9 + .1 * np.sin(2 * math.pi * xx * f) * np.sin(2 * math.pi * yy * f)
    return np.clip(rgb(c) * (w + pink(N, seed, 1.0) * .08 - .04)[..., None], 0, 1)
def g_leather(c, seed=14): return np.clip(rgb(c) * (.9 + pink(N, seed, 1.7) * .12 + pink(N, seed + 1, .6) * .05)[..., None], 0, 1)

PRE = []
def P(id, name, grp, gen=None, color=None, metal=0, rough=.6): PRE.append((id, name, grp, gen, color, metal, rough))
W_, S_, M_, T_, F_, PA_, L_, FA_ = 'خشب', 'رخام وحجر', 'معادن', 'بلاط', 'أرضيات', 'دهانات', 'طلاء لامع', 'أقمشة وجلد'
for id, n, c1, c2, f, wv, s in [('oak_light', 'بلوط فاتح', '#c8a273', '#e8d2a8', 10, .3, 1), ('oak_nat', 'بلوط طبيعي', '#a8763f', '#cf9d62', 10, .3, 2),
        ('oak_dark', 'بلوط داكن', '#5a3a22', '#7d5233', 9, .3, 3), ('walnut', 'جوز', '#3d2415', '#6b4426', 9, .35, 4), ('cherry', 'كرز', '#7a3b22', '#a9562f', 10, .25, 5),
        ('wenge', 'ونجي', '#241812', '#3b2a20', 12, .25, 6), ('ash_white', 'رماد أبيض', '#d9cdb8', '#efe6d4', 11, .2, 7), ('pine', 'صنوبر', '#c99a52', '#e5c07e', 8, .5, 8),
        ('teak', 'ساج', '#8b5a2b', '#b07a3f', 10, .3, 9), ('bamboo', 'خيزران', '#cfae6a', '#e7cf8f', 16, .1, 10), ('whitewash', 'خشب مبيّض', '#cfc8bc', '#ece7de', 10, .25, 11),
        ('driftwood', 'خشب رمادي', '#8a8378', '#b3ac9f', 10, .3, 12)]:
    P(id, n, W_, (lambda c1=c1, c2=c2, f=f, wv=wv, s=s: g_wood(c1, c2, f, wv, s)), rough=.55)
for id, n, b, v, s, w in [('carrara', 'كرارا أبيض', '#f0f0ee', '#8d9096', 3, .06), ('calacatta', 'كالاكاتا ذهبي', '#f4efe6', '#b08a4a', 13, .05),
        ('marquina', 'مارکينا أسود', '#1c1c1e', '#e6e6e6', 14, .04), ('emperador', 'إمبرادور بني', '#6b4a3a', '#d9c3a5', 15, .06), ('verde', 'رخام أخضر', '#2f4a3b', '#c9d8cc', 16, .06),
        ('marble_floor', 'رخام أرضية', '#ecebe8', '#9a9ea4', 35, .05)]:
    P(id, n, S_, (lambda b=b, v=v, s=s, w=w: g_marble(b, v, 1, s, w)), rough=.08)
for id, n, b, c, s, d in [('granite_grey', 'جرانيت رمادي', '#7c7f84', '#2e3033', 17, .35), ('granite_black', 'جرانيت أسود', '#1b1c1e', '#6a6c70', 18, .3),
        ('quartz_white', 'كوارتز أبيض', '#ecebe7', '#c4c2bb', 19, .15), ('quartz_beige', 'كوارتز بيج', '#d8cdb8', '#a89c85', 20, .15)]:
    P(id, n, S_, (lambda b=b, c=c, s=s, d=d: g_speckle(b, c, s, d)), rough=.15)
P('terrazzo', 'تيرازو', S_, lambda: g_terrazzo('#e6e0d6'), rough=.2); P('travertine', 'ترافرتين', S_, lambda: g_strata('#d8c8a8', '#b8a37c', 21), rough=.5)
P('slate', 'أردواز', S_, lambda: g_strata('#3c4147', '#5b626b', 22), rough=.6); P('concrete_light', 'خرسانة فاتحة', S_, lambda: g_concrete('#b9b9b6', 23), rough=.85)
P('concrete_dark', 'خرسانة داكنة', S_, lambda: g_concrete('#6e6f71', 24), rough=.85)
for id, n, c1, c2 in [('steel_brushed', 'ستانلس مصقول', '#9a9da3', '#c4c7cc'), ('steel_dark', 'جرافيت معدني', '#4a4d52', '#6b6f75'), ('aluminum', 'ألمنيوم', '#b8bbc0', '#d8dade'),
        ('brass', 'نحاس أصفر', '#b08d57', '#d7b878'), ('copper', 'نحاس أحمر', '#a8603e', '#d28a5f'), ('bronze', 'برونز', '#6f5a3a', '#8e7549')]:
    P(id, n, M_, (lambda c1=c1, c2=c2: g_brushed(c1, c2)), metal=1, rough=.35)
P('gold', 'ذهبي', M_, color=rgb('#ffc864'), metal=1, rough=.25); P('chrome', 'كروم', M_, color=np.array([.92, .92, .94]), metal=1, rough=.05)
P('black_metal', 'أسود معدني', M_, color=np.array([.05, .05, .055]), metal=1, rough=.35)
for id, n, t, g in [('subway_white', 'سبواي أبيض', '#f3f3f1', '#c9c9c6'), ('subway_black', 'سبواي أسود', '#222426', '#555555'), ('subway_green', 'سبواي أخضر', '#3f6b57', '#bfc9c3'), ('subway_blue', 'سبواي أزرق', '#2f5d8a', '#c3ccd6')]:
    P(id, n, T_, (lambda t=t, g=g: g_subway(t, g)), rough=.12)
P('square_white', 'مربعات بيضاء', T_, lambda: g_squares(4, '#f2f2f0', '#bdbdba', .03), rough=.12); P('square_grey', 'مربعات رمادية', T_, lambda: g_squares(4, '#8d9094', '#5e6064', .06), rough=.25)
P('checker_bw', 'شطرنج أبيض/أسود', T_, lambda: g_checker('#f0f0f0', '#1d1d1d', 4), rough=.15); P('checker_beige', 'شطرنج بيج', T_, lambda: g_checker('#e8dcc6', '#b49a76', 4), rough=.2)
P('diamond_white', 'معيّن أبيض', T_, lambda: g_diamond('#f1efe9', '#b5b2a8'), rough=.15); P('mosaic_blue', 'فسيفساء زرقاء', T_, lambda: g_squares(16, '#3a79a8', '#cfd8de', .18), rough=.1)
P('mosaic_grey', 'فسيفساء رمادية', T_, lambda: g_squares(16, '#9ea1a5', '#6a6c70', .14), rough=.15); P('brick_red', 'طوب أحمر', T_, lambda: g_subway('#9c4a37', '#b9b1a6', 8, 4, 7, .25), rough=.8)
P('brick_white', 'طوب أبيض', T_, lambda: g_subway('#e9e6df', '#b9b6ae', 8, 4, 8, .1), rough=.8); P('terracotta', 'تراكوتا', T_, lambda: g_squares(3, '#b9623b', '#8a4528', .08), rough=.7)
for id, n, c1, c2, s in [('planks_oak', 'ألواح بلوط', '#b88a52', '#d9b07a', 31), ('planks_grey', 'ألواح رمادية', '#7d7a75', '#a09c96', 32),
        ('planks_dark', 'ألواح داكنة', '#4b3626', '#6b4e37', 33), ('planks_white', 'ألواح بيضاء', '#d8d2c6', '#eee9de', 34)]:
    P(id, n, F_, (lambda c1=c1, c2=c2, s=s: g_planks(c1, c2, 6, s)), rough=.45)
P('porcelain_grey', 'بورسلان رمادي', F_, lambda: g_squares(2, '#9b9ea2', '#7c7f83', .04), rough=.2); P('porcelain_beige', 'بورسلان بيج', F_, lambda: g_squares(2, '#d9d0bf', '#b8ae9b', .04), rough=.2)
for id, n, c in [('offwhite', 'أبيض مطفي', '#f1eee8'), ('white', 'أبيض ناصع', '#fbfbfa'), ('cream', 'كريمي', '#efe4cc'), ('beige', 'بيج', '#d9c9aa'), ('light_grey', 'رمادي فاتح', '#cfd0d1'),
        ('grey', 'رمادي', '#8d9093'), ('charcoal', 'فحمي', '#3a3d41'), ('black', 'أسود', '#17181a'), ('navy', 'كحلي', '#1f3354'), ('blue', 'أزرق', '#3e6ea3'), ('sky', 'سماوي', '#a9cbe3'),
        ('sage', 'أخضر مريمية', '#9db39a'), ('olive', 'زيتي', '#6f7a45'), ('forest', 'أخضر غابة', '#2f5a3e'), ('teal', 'تركواز', '#2f7f86'), ('terracotta_paint', 'طيني', '#b4603f'),
        ('mustard', 'خردلي', '#d1a52c'), ('blush', 'وردي هادئ', '#e6b8b0'), ('burgundy', 'عنابي', '#6b1f2e'), ('lavender', 'لافندر', '#b9a7d1')]:
    P(id, n, PA_, color=rgb(c), rough=.85)
for id, n, c in [('gloss_white', 'لامع أبيض', '#f4f4f2'), ('gloss_black', 'لامع أسود', '#131315'), ('gloss_red', 'لامع أحمر', '#a3231f'), ('gloss_grey', 'لامع رمادي', '#7a7f85'),
        ('gloss_cream', 'لامع كريمي', '#ebdfc5'), ('gloss_navy', 'لامع كحلي', '#1c2f52')]:
    P(id, n, L_, color=rgb(c), rough=.12)
for id, n, c in [('linen_beige', 'كتان بيج', '#cdbfa4'), ('fabric_grey', 'قماش رمادي', '#8a8d91'), ('fabric_navy', 'قماش كحلي', '#2d3e5e'), ('fabric_green', 'قماش أخضر', '#5a7a5c'),
        ('fabric_mustard', 'قماش خردلي', '#c9a23a'), ('fabric_blush', 'قماش وردي', '#d9a9a0'), ('velvet_green', 'قطيفة خضراء', '#2a5a45')]:
    P(id, n, FA_, (lambda c=c: g_fabric(c)), rough=.95)
for id, n, c in [('leather_brown', 'جلد بني', '#6b4226'), ('leather_black', 'جلد أسود', '#1e1d1c'), ('leather_tan', 'جلد عسلي', '#a9763f'), ('leather_white', 'جلد أبيض', '#e9e5dc')]:
    P(id, n, FA_, (lambda c=c: g_leather(c)), rough=.5)

PCOL, MJ = {}, []
for id, n, grp, gen, col, metal, rough in PRE:
    if gen:
        arr = gen(); open(os.path.join(A, 'tex', id + '.png'), 'wb').write(png(arr)); PCOL[id] = arr.mean((0, 1)); r = g = b = 1.0
    else: PCOL[id] = np.array(col); r, g, b = [float(x) for x in col]
    MJ.append(dict(id=id, name=n, grp=grp, tex=id if gen else '', r=r, g=g, b=b, metal=metal, rough=rough))
json.dump(MJ, open(os.path.join(A, 'materials.json'), 'w'), ensure_ascii=False)
print('materials', len(MJ))

# ---------------- mesh builder ----------------
class M:
    def __init__(s): s.p = {}
    def _pr(s, k): return s.p.setdefault(k, {'pos': [], 'nor': [], 'uv': [], 'idx': []})
    def _emit(s, k, Pp, Nn, U, order, idx):
        pr = s._pr(k); b = len(pr['pos'])
        for i in order: pr['pos'].append(tuple(Pp[i])); pr['nor'].append(tuple(Nn[i])); pr['uv'].append(tuple(U[i]))
        pr['idx'] += [b + i for i in idx]
    def quad(s, k, Pp, Nn, U):
        c = np.cross(np.subtract(Pp[1], Pp[0]), np.subtract(Pp[2], Pp[1]))
        s._emit(k, Pp, Nn, U, [0, 1, 2, 3] if np.dot(c, np.mean(Nn, 0)) >= 0 else [0, 3, 2, 1], [0, 1, 2, 0, 2, 3])
    def tri(s, k, Pp, Nn, U):
        c = np.cross(np.subtract(Pp[1], Pp[0]), np.subtract(Pp[2], Pp[0]))
        s._emit(k, Pp, Nn, U, [0, 1, 2] if np.dot(c, np.mean(Nn, 0)) >= 0 else [0, 2, 1], [0, 1, 2])
    def box(s, k, x0, y0, z0, x1, y1, z1, us=1.0, uo=.5):
        F = [((1, 0, 0), [(x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0)]), ((-1, 0, 0), [(x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0)]),
             ((0, 1, 0), [(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)]), ((0, -1, 0), [(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)]),
             ((0, 0, 1), [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]), ((0, 0, -1), [(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)])]
        for n, Pp in F:
            if n[0]: uv = lambda p: ((p[2] + uo) * us, p[1] * us)
            elif n[1]: uv = lambda p: ((p[0] + uo) * us, (p[2] + uo) * us)
            else: uv = lambda p: ((p[0] + uo) * us, p[1] * us)
            s.quad(k, Pp, [n] * 4, [uv(p) for p in Pp])
    def cyl(s, k, cx, cz, y0, y1, r0, r1=None, seg=24):
        r1 = r0 if r1 is None else r1
        for i in range(seg):
            a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg; c0, s0, c1, s1 = math.cos(a0), math.sin(a0), math.cos(a1), math.sin(a1)
            Pp = [(cx + r0 * c0, y0, cz + r0 * s0), (cx + r0 * c1, y0, cz + r0 * s1), (cx + r1 * c1, y1, cz + r1 * s1), (cx + r1 * c0, y1, cz + r1 * s0)]
            s.quad(k, Pp, [(c0, 0, s0), (c1, 0, s1), (c1, 0, s1), (c0, 0, s0)], [(i / seg, y0), ((i + 1) / seg, y0), ((i + 1) / seg, y1), (i / seg, y1)])
            if r1 > 0: s.tri(k, [(cx, y1, cz), Pp[3], Pp[2]], [(0, 1, 0)] * 3, [(.5, .5), (.5 + c0 / 2, .5 + s0 / 2), (.5 + c1 / 2, .5 + s1 / 2)])
    def cylz(s, k, cx, cy, z0, z1, r, seg=24):
        for i in range(seg):
            a0, a1 = 2 * math.pi * i / seg, 2 * math.pi * (i + 1) / seg; c0, s0, c1, s1 = math.cos(a0), math.sin(a0), math.cos(a1), math.sin(a1)
            Pp = [(cx + r * c0, cy + r * s0, z0), (cx + r * c1, cy + r * s1, z0), (cx + r * c1, cy + r * s1, z1), (cx + r * c0, cy + r * s0, z1)]
            s.quad(k, Pp, [(c0, s0, 0), (c1, s1, 0), (c1, s1, 0), (c0, s0, 0)], [(i / seg, z0), ((i + 1) / seg, z0), ((i + 1) / seg, z1), (i / seg, z1)])
            s.tri(k, [(cx, cy, z1), Pp[3], Pp[2]], [(0, 0, 1)] * 3, [(.5, .5), (.5 + c0 / 2, .5 + s0 / 2), (.5 + c1 / 2, .5 + s1 / 2)])
    def sphere(s, k, cx, cy, cz, r, lat=8, lon=14):
        def pt(i, j):
            t, f = math.pi * i / lat, 2 * math.pi * j / lon; n = (math.sin(t) * math.cos(f), math.cos(t), math.sin(t) * math.sin(f))
            return (cx + r * n[0], cy + r * n[1], cz + r * n[2]), n, (j / lon, i / lat)
        for i in range(lat):
            for j in range(lon):
                q = [pt(i, j), pt(i, j + 1), pt(i + 1, j + 1), pt(i + 1, j)]; s.quad(k, [a[0] for a in q], [a[1] for a in q], [a[2] for a in q])

def bar_h(m, x0, x1, y, z, k='accent'):
    m.box(k, x0, y, z + .012, x1, y + .012, z + .024); m.box(k, x0, y, z, x0 + .012, y + .012, z + .012); m.box(k, x1 - .012, y, z, x1, y + .012, z + .012)
def bar_v(m, x, y0, y1, z, k='accent'):
    m.box(k, x, y0, z + .012, x + .012, y1, z + .024); m.box(k, x, y0 + .01, z, x + .012, y0 + .022, z + .012); m.box(k, x, y1 - .022, z, x + .012, y1 - .01, z + .012)
def hw_(W): return min(.07, W / 2 - .04)

# ---------------- kitchen models (metres; origin = centre x/z, floor y; front = +z) ----------------
def cab(W, style='dr1', D=.6, H=.85):
    m = M(); g = .003; zf = D / 2 - .02; zb = D / 2; us = 1 / .6; hw = hw_(W)
    m.box('main', -W / 2, .1, -D / 2, W / 2, H, zf, us); m.box('dark', -W / 2 + .01, 0, -D / 2, W / 2 - .01, .1, D / 2 - .07)
    top = H - .005
    if style == 'dr3':
        ys = [.105, .36, .61, top]
        for a, b in zip(ys[:-1], ys[1:]): m.box('main', -W / 2 + g, a + g, zf, W / 2 - g, b - g, zb, us); bar_h(m, -hw, hw, b - .07, zb)
        return m
    dt = top
    if style == 'dr1': m.box('main', -W / 2 + g, .62, zf, W / 2 - g, top, zb, us); bar_h(m, -hw, hw, .775, zb); dt = .615
    if W > .7:
        m.box('main', -W / 2 + g, .105, zf, -g / 2, dt, zb, us); m.box('main', g / 2, .105, zf, W / 2 - g, dt, zb, us)
        bar_v(m, -.04, dt - .22, dt - .05, zb); bar_v(m, .028, dt - .22, dt - .05, zb)
    else:
        m.box('main', -W / 2 + g, .105, zf, W / 2 - g, dt, zb, us); bar_v(m, W / 2 - .06, dt - .22, dt - .05, zb)
    return m
def sinkcab(W, double=False):
    m = cab(W, 'door'); m.box('top', -W / 2, .85, -.3, W / 2, .89, .31, 1.0); n = 2 if double else 1; bw = (W - .1) / n
    for i in range(n):
        cx = -W / 2 + .05 + bw * (i + .5); m.box('dsteel', cx - bw / 2 + .03, .89, -.19, cx + bw / 2 - .03, .893, .19)
    m.cyl('accent', 0, -.24, .89, 1.04, .016); m.box('accent', -.008, 1.03, -.24, .008, 1.046, -.08); m.box('accent', .016, .98, -.245, .06, .992, -.235); return m
def wcab(W, H=.7, D=.35, glass=False):
    m = M(); g = .003; zf = D / 2 - .02; zb = D / 2; hw = hw_(W)
    m.box('main', -W / 2, 0, -D / 2, W / 2, H, zf)
    if glass:
        f = .05; m.box('main', -W / 2 + g, g, zf, -W / 2 + f, H - g, zb); m.box('main', W / 2 - f, g, zf, W / 2 - g, H - g, zb)
        m.box('main', -W / 2 + f, g, zf, W / 2 - f, f, zb); m.box('main', -W / 2 + f, H - f, zf, W / 2 - f, H - g, zb); m.box('glassc', -W / 2 + f, f, zb - .008, W / 2 - f, H - f, zb - .004)
    elif W > .7: m.box('main', -W / 2 + g, g, zf, -g / 2, H - g, zb); m.box('main', g / 2, g, zf, W / 2 - g, H - g, zb)
    else: m.box('main', -W / 2 + g, g, zf, W / 2 - g, H - g, zb)
    bar_h(m, -hw, hw, .035, zb); return m
def shelf(W, D=.25):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, .03, D / 2)
    for x in (-W / 2 + .08, W / 2 - .12): m.box('accent', x, -.12, -D / 2, x + .04, 0, -D / 2 + .02); m.box('accent', x, -.03, -D / 2, x + .04, 0, D / 2 - .03)
    return m
def tall(W, kind):
    m = M(); g = .003; D = .6; H = 2.1; zf = D / 2 - .02; zb = D / 2; us = 1 / .6
    m.box('main', -W / 2, .1, -D / 2, W / 2, H, zf, us); m.box('dark', -W / 2 + .01, 0, -D / 2, W / 2 - .01, .1, D / 2 - .07)
    if kind == 'pantry':
        for a, b in ((.105, 1.05), (1.053, H - .005)):
            if W > .7: m.box('main', -W / 2 + g, a, zf, -g / 2, b, zb, us); m.box('main', g / 2, a, zf, W / 2 - g, b, zb, us); bar_v(m, -.04, b - .25, b - .06, zb); bar_v(m, .028, b - .25, b - .06, zb)
            else: m.box('main', -W / 2 + g, a, zf, W / 2 - g, b, zb, us); bar_v(m, W / 2 - .06, b - .25, b - .06, zb)
    else:
        m.box('main', -W / 2 + g, .105, zf, W / 2 - g, .55, zb, us); m.box('main', -W / 2 + g, 1.5, zf, W / 2 - g, H - .005, zb, us); bar_h(m, -.1, .1, .5, zb)
        for y0, y1 in ((.58, 1.1), (1.13, 1.47)): m.box('dsteel', -W / 2 + .02, y0, zf, W / 2 - .02, y1, zb); m.box('glass', -W / 2 + .06, y0 + .06, zb, W / 2 - .06, y1 - .06, zb + .003); bar_h(m, -.2, .2, y1 - .04, zb)
    return m
def counter(L, D=.62, T=.04):
    m = M(); m.box('top', -L / 2, 0, -D / 2, L / 2, T, D / 2, 1.0); return m
def island(L):
    m = cab(L, 'dr1', .8, .85); m.box('top', -L / 2 - .02, .85, -.45, L / 2 + .02, .89, .45, 1.0); return m
def splash(L): m = M(); m.box('main', -L / 2, 0, -.01, L / 2, .6, .01, 1 / .3); return m
def hood(W=.6, D=.5, H=.9):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, .07, D / 2, 1 / .6); m.box('main', -W / 2 + .1, .07, -D / 2, W / 2 - .1, .14, D / 2 - .08, 1 / .6)
    m.box('main', -.15, .14, -D / 2, .15, H, -D / 2 + .22, 1 / .6); m.box('glass', -W / 2 + .1, -.002, -.1, W / 2 - .1, 0, .1); return m
def rng_(W=.6, D=.6, H=.9):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, .86, D / 2, 1 / .6); m.box('glass', -W / 2, .86, -D / 2, W / 2, .875, D / 2)
    xs = (-.14, .14) if W < .7 else (-.27, 0, .27)
    for x in xs:
        for z in (-.13, .13): m.cyl('dsteel', x, z, .875, .887, .075, .068); m.cyl('dark', x, z, .887, .895, .035)
    m.box('main', -W / 2 + .02, .08, D / 2, W / 2 - .02, .66, D / 2 + .02, 1 / .6); m.box('glass', -W / 2 + .08, .14, D / 2 + .02, W / 2 - .08, .60, D / 2 + .023); bar_h(m, -W / 2 + .06, W / 2 - .06, .68, D / 2 + .01)
    for i in range(4): x = -W / 2 + .12 + i * (W - .24) / 3; m.box('dark', x - .018, .76, D / 2, x + .018, .795, D / 2 + .025)
    return m
def fridge(kind='bot', W=.7, D=.7, H=1.8):
    m = M(); g = .004; us = 1 / .6; zf = D / 2 - .02; zb = D / 2
    m.box('main', -W / 2, .02, -D / 2, W / 2, H, zf, us); m.box('dark', -W / 2 + .02, 0, -D / 2, W / 2 - .02, .02, D / 2 - .05)
    if kind == 'bot': m.box('main', -W / 2, .62, zf, W / 2, H - g, zb, us); m.box('main', -W / 2, .025, zf, W / 2, .6, zb, us); bar_v(m, W / 2 - .09, 1.1, 1.55, zb); bar_v(m, W / 2 - .09, .3, .5, zb)
    elif kind == 'side': m.box('main', -W / 2 + g, .025, zf, -g / 2, H - g, zb, us); m.box('main', g / 2, .025, zf, W / 2 - g, H - g, zb, us); bar_v(m, -.05, .9, 1.5, zb); bar_v(m, .038, .9, 1.5, zb)
    else: m.box('main', -W / 2, .025, zf, W / 2, H - g, zb, us); bar_v(m, W / 2 - .08, H - .35, H - .08, zb)
    return m
def dish(W=.6, D=.6, H=.85):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, H, D / 2, 1 / .6); m.box('dark', -W / 2 + .03, H - .09, D / 2, W / 2 - .03, H - .02, D / 2 + .005); bar_h(m, -.22, .22, H - .13, D / 2); return m
def micro(W=.45, D=.35, H=.28):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, H, D / 2, 1 / .6); m.box('glass', -W / 2 + .02, .03, D / 2, W / 2 - .12, H - .03, D / 2 + .004); m.box('dark', W / 2 - .1, .03, D / 2, W / 2 - .02, H - .03, D / 2 + .004); bar_v(m, W / 2 - .115, .06, H - .06, D / 2); return m
def washer(W=.6, D=.6, H=.85):
    m = M(); m.box('main', -W / 2, 0, -D / 2, W / 2, H, D / 2, 1 / .6); m.box('dark', -W / 2 + .03, H - .1, D / 2, W / 2 - .03, H - .03, D / 2 + .004)
    m.cylz('accent', 0, .42, D / 2 - .005, D / 2 + .012, .24); m.cylz('glass', 0, .42, D / 2, D / 2 + .022, .19); return m
def winecool(W=.6, D=.6, H=.85):
    m = M(); m.box('dark', -W / 2, 0, -D / 2, W / 2, H, D / 2); m.box('glassc', -W / 2 + .03, .05, D / 2, W / 2 - .03, H - .05, D / 2 + .004)
    for y in (.25, .45, .65): m.box('main', -W / 2 + .04, y, -D / 2 + .05, W / 2 - .04, y + .015, D / 2 - .03)
    bar_v(m, W / 2 - .07, .2, .65, D / 2); return m
def kettle():
    m = M(); m.cyl('dark', 0, 0, 0, .02, .09); m.cyl('main', 0, 0, .02, .22, .085, .065); m.cyl('dark', 0, 0, .22, .235, .045); m.box('dark', .07, .05, -.015, .12, .2, .015); return m
def toaster():
    m = M(); m.box('main', -.14, 0, -.08, .14, .18, .08, 1 / .6)
    for dx in (-.07, .07): m.box('dark', dx - .05, .179, -.015, dx + .05, .182, .015)
    m.box('accent', .15, .06, -.02, .165, .14, .02); return m
def coffee():
    m = M(); m.box('dark', -.14, 0, -.2, .14, .04, .2); m.box('main', -.14, .04, -.2, .14, .36, -.1, 1 / .6); m.box('main', -.14, .3, -.2, .14, .36, .05, 1 / .6)
    m.cyl('dark', 0, -.02, .1, .3, .02); m.cyl('accent', 0, .08, .04, .12, .045); return m
def plant(tall_=False):
    m = M()
    if tall_:
        m.cyl('pot', 0, 0, 0, .3, .2, .16); m.cyl('soil', 0, 0, .3, .302, .19); m.cyl('pot', 0, 0, .302, 1.0, .02)
        for x, y, z, r in [(0, 1.15, 0, .26), (.14, 1.0, .1, .2), (-.14, 1.05, -.08, .2), (0, 1.35, .02, .18), (.1, 1.28, -.14, .16)]: m.sphere('leaf', x, y, z, r)
    else:
        m.cyl('pot', 0, 0, 0, .15, .08, .1); m.cyl('soil', 0, 0, .15, .152, .075)
        for x, y, z, r in [(0, .28, 0, .11), (.06, .22, .04, .08), (-.06, .24, -.04, .08), (0, .35, .02, .06)]: m.sphere('leaf', x, y, z, r)
    return m
def fruitbowl():
    m = M(); m.cyl('main', 0, 0, 0, .06, .08, .15)
    for k, x, z in [('fruit_r', -.04, 0), ('fruit_o', .05, .03), ('fruit_y', .02, -.05), ('fruit_r', .06, -.04)]: m.sphere(k, x, .09, z, .04)
    return m
def canisters():
    m = M()
    for i, (r, h) in enumerate([(.06, .18), (.06, .14), (.05, .12)]): x = (i - 1) * .14; m.cyl('main', x, 0, 0, h, r); m.cyl('accent', x, 0, h, h + .02, r + .003)
    return m
def board(): m = M(); m.box('main', -.2, 0, -.125, .2, .02, .125, 1 / .6); return m

# ---------------- home furniture ----------------
def table(L, Wd, H=.75):
    m = M(); m.box('main', -L / 2, H - .04, -Wd / 2, L / 2, H, Wd / 2, 1 / .8)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * (L / 2 - .09) - .03, 0, sz * (Wd / 2 - .09) - .03, sx * (L / 2 - .09) + .03, H - .04, sz * (Wd / 2 - .09) + .03)
    return m
def table_r(D, H=.75):
    m = M(); m.cyl('main', 0, 0, H - .04, H, D / 2); m.cyl('accent', 0, 0, 0, H - .04, .05); m.cyl('accent', 0, 0, 0, .03, D * .3); return m
def chair(up=False):
    m = M(); sk = 'main'; m.box(sk, -.225, .44, -.225, .225, .48 if not up else .52, .225, 1 / .6)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * .19 - .018, 0, sz * .19 - .018, sx * .19 + .018, .44, sz * .19 + .018)
    m.box(sk, -.225, .5, -.225, .225, .88, -.19, 1 / .6); return m
def stool(H=.65):
    m = M(); m.cyl('main', 0, 0, H - .04, H, .17)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * .11 - .015, 0, sz * .11 - .015, sx * .11 + .015, H - .04, sz * .11 + .015)
    m.box('accent', -.12, H * .35, -.12, .12, H * .35 + .015, .12); return m
def armchair():
    m = M(); m.box('main', -.4, .15, -.4, .4, .42, .4, 1 / .6); m.box('main', -.4, .42, -.4, .4, .85, -.2, 1 / .6)
    for sx in (-1, 1): m.box('main', sx * .4 - .07 if sx < 0 else .33, .42, -.4, sx * .4 + .07 if sx > 0 else -.33, .62, .4, 1 / .6)
    m.box('main', -.3, .42, -.2, .3, .5, .4, 1 / .6)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * .34 - .02, 0, sz * .34 - .02, sx * .34 + .02, .15, sz * .34 + .02)
    return m
def sofa(L, D=.9):
    m = M(); m.box('main', -L / 2, .12, -D / 2, L / 2, .42, D / 2, 1 / .8); m.box('main', -L / 2, .42, -D / 2, L / 2, .88, -D / 2 + .22, 1 / .8)
    for sx in (-1, 1): m.box('main', sx * (L / 2 - .075) - .075, .42, -D / 2 + .22, sx * (L / 2 - .075) + .075, .65, D / 2, 1 / .8)
    n = max(2, round(L / .7)); sw = (L - .3) / n
    for i in range(n): x0 = -L / 2 + .15 + i * sw; m.box('main', x0 + .01, .42, -D / 2 + .22, x0 + sw - .01, .52, D / 2 - .02, 1 / .8)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * (L / 2 - .08) - .025, 0, sz * (D / 2 - .08) - .025, sx * (L / 2 - .08) + .025, .12, sz * (D / 2 - .08) + .025)
    return m
def ottoman(): m = M(); m.box('main', -.3, .08, -.3, .3, .4, .3, 1 / .6); [m.box('accent', sx * .24 - .02, 0, sz * .24 - .02, sx * .24 + .02, .08, sz * .24 + .02) for sx in (-1, 1) for sz in (-1, 1)]; return m
def coffee_t(L, Wd, H=.4):
    m = M(); m.box('main', -L / 2, H - .035, -Wd / 2, L / 2, H, Wd / 2, 1 / .8); m.box('main', -L / 2 + .06, .12, -Wd / 2 + .06, L / 2 - .06, .15, Wd / 2 - .06, 1 / .8)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * (L / 2 - .06) - .02, 0, sz * (Wd / 2 - .06) - .02, sx * (L / 2 - .06) + .02, H - .035, sz * (Wd / 2 - .06) + .02)
    return m
def side_t(D=.45, H=.5): m = M(); m.cyl('main', 0, 0, H - .03, H, D / 2); m.cyl('accent', 0, 0, 0, H - .03, .03); m.cyl('accent', 0, 0, 0, .025, D * .35); return m
def tvunit(L, H=.45, D=.4):
    m = M(); g = .003; m.box('main', -L / 2, .1, -D / 2, L / 2, H, D / 2 - .02, 1 / .8); n = 3 if L > 1.7 else 2; w = L / n
    for i in range(n): x0 = -L / 2 + i * w; m.box('main', x0 + g, .105, D / 2 - .02, x0 + w - g, H - .005, D / 2, 1 / .8); bar_v(m, x0 + w / 2 - .006, H - .2, H - .06, D / 2)
    for sx in (-1, 1): m.box('accent', sx * (L / 2 - .06) - .02, 0, -.15, sx * (L / 2 - .06) + .02, .1, .15)
    return m
def tv(W=1.2):
    H = W * .5625; m = M(); m.box('dark', -W / 2, .12, -.02, W / 2, .12 + H, .02); m.box('glass', -W / 2 + .01, .13, .02, W / 2 - .01, .11 + H, .022); m.box('accent', -.2, 0, -.1, .2, .02, .1); m.box('accent', -.03, .02, -.02, .03, .12, .02); return m
def bookshelf(W, H, D=.3):
    m = M(); r = random.Random(int(W * 100 + H * 10)); t = .025
    m.box('main', -W / 2, 0, -D / 2, -W / 2 + t, H, D / 2); m.box('main', W / 2 - t, 0, -D / 2, W / 2, H, D / 2); m.box('main', -W / 2, 0, -D / 2, W / 2, .08, D / 2 - .02); m.box('main', -W / 2, 0, -D / 2, W / 2, H, -D / 2 + .01)
    ys = [i * .36 + .08 for i in range(int((H - .1) / .36) + 1)]
    for y in ys + [H - t]: m.box('main', -W / 2, min(y, H - t), -D / 2, W / 2, min(y, H - t) + t, D / 2)
    for y in ys[:-1]:
        x = -W / 2 + t + .02
        while x < W / 2 - t - .08:
            bw = r.choice([.03, .04, .05]); bh = r.choice([.22, .26, .3]); m.box(r.choice(['book1', 'book2', 'book3', 'book4']), x, y + t, -D / 2 + .03, x + bw, y + t + bh, D / 2 - .05); x += bw + .003
            if r.random() < .15: x += .12
    return m
def wardrobe(W, H=2.2, D=.6):
    m = M(); g = .003; n = 2 if W < 1.3 else 3 if W < 1.8 else 4; w = W / n
    m.box('main', -W / 2, .08, -D / 2, W / 2, H, D / 2 - .02, 1 / .6); m.box('dark', -W / 2 + .01, 0, -D / 2, W / 2 - .01, .08, D / 2 - .05)
    for i in range(n): x0 = -W / 2 + i * w; m.box('main', x0 + g, .085, D / 2 - .02, x0 + w - g, H - .005, D / 2, 1 / .6); xh = x0 + w - .05 if i % 2 == 0 else x0 + .04; bar_v(m, xh, 1.0, 1.35, D / 2)
    return m
def bed(W, L=2.0):
    m = M(); m.box('main', -W / 2 - .04, .15, -L / 2, W / 2 + .04, .3, L / 2 + .04, 1 / .8); m.box('white', -W / 2 + .02, .3, -L / 2 + .12, W / 2 - .02, .52, L / 2 - .02, 1 / .8)
    m.box('main', -W / 2 - .04, .15, -L / 2 - .08, W / 2 + .04, 1.1, -L / 2, 1 / .8); m.box('top', -W / 2 + .01, .52, -.1, W / 2 - .01, .56, L / 2 - .01, 1 / .8)
    n = 1 if W < 1.2 else 2
    for i in range(n): cx = (i - (n - 1) / 2) * (W / n) * .9; m.box('white', cx - .27, .52, -L / 2 + .15, cx + .27, .62, -L / 2 + .5)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * (W / 2 - .02) - .025, 0, sz * (L / 2 - .02) - .025, sx * (W / 2 - .02) + .025, .15, sz * (L / 2 - .02) + .025)
    return m
def nightstand():
    m = M(); m.box('main', -.225, .08, -.2, .225, .5, .18, 1 / .6); m.box('main', -.22, .3, .18, .22, .49, .2, 1 / .6); m.box('main', -.22, .1, .18, .22, .29, .2, 1 / .6); bar_h(m, -.05, .05, .4, .2); bar_h(m, -.05, .05, .2, .2)
    for sx in (-1, 1):
        for sz in (-1, 1): m.box('accent', sx * .19 - .015, 0, sz * .16 - .015, sx * .19 + .015, .08, sz * .16 + .015)
    return m
def desk(L, D=.65, H=.75):
    m = M(); m.box('main', -L / 2, H - .03, -D / 2, L / 2, H, D / 2, 1 / .8); m.box('main', L / 2 - .45, .05, -D / 2 + .03, L / 2 - .02, H - .03, D / 2 - .03, 1 / .8)
    for k, (a, b) in enumerate([(.06, .28), (.3, .52), (.54, .72)]): m.box('main', L / 2 - .44, a, D / 2 - .03, L / 2 - .03, b, D / 2 - .01, 1 / .8); bar_h(m, L / 2 - .27, L / 2 - .2, b - .06, D / 2 - .02)
    for sz in (-1, 1): m.box('accent', -L / 2 + .04, 0, sz * (D / 2 - .06) - .02, -L / 2 + .08, H - .03, sz * (D / 2 - .06) + .02)
    return m
def ochair():
    m = M(); m.box('dark', -.3, .03, -.03, .3, .06, .03); m.box('dark', -.03, .03, -.3, .03, .06, .3); m.cyl('dark', 0, 0, .06, .42, .025); m.box('main', -.24, .42, -.24, .24, .5, .24, 1 / .6); m.box('main', -.22, .5, -.24, .22, .95, -.2, 1 / .6); return m
def dresser(W=1.0, H=.85, D=.45):
    m = M(); m.box('main', -W / 2, .1, -D / 2, W / 2, H, D / 2 - .02, 1 / .6); m.box('dark', -W / 2 + .01, 0, -D / 2, W / 2 - .01, .1, D / 2 - .05)
    for a, b in [(.105, .33), (.335, .56), (.565, H - .005)]: m.box('main', -W / 2 + .003, a, D / 2 - .02, W / 2 - .003, b, D / 2, 1 / .6); bar_h(m, -.06, .06, b - .07, D / 2)
    return m
def mirror(W, H):
    m = M(); f = .03; m.box('accent', -W / 2, 0, -.02, W / 2, H, .02); m.box('mirror', -W / 2 + f, f, .02, W / 2 - f, H - f, .024); return m
def floorlamp():
    m = M(); m.cyl('accent', 0, 0, 0, .02, .15); m.cyl('accent', 0, 0, .02, 1.45, .012); m.cyl('white', 0, 0, 1.4, 1.72, .22, .15); return m
def tablelamp():
    m = M(); m.cyl('accent', 0, 0, 0, .03, .08); m.cyl('accent', 0, 0, .03, .22, .02); m.cyl('white', 0, 0, .2, .42, .17, .11); return m
def pendant():
    m = M(); m.cyl('dark', 0, 0, .6, .85, .006); m.cyl('white', 0, 0, .3, .6, .26, .04); m.cyl('accent', 0, 0, .28, .3, .24, .26); return m
def rug(W, L, T=.015): m = M(); m.box('main', -W / 2, 0, -L / 2, W / 2, T, L / 2, 1 / .6); return m
def rug_r(D, T=.015): m = M(); m.cyl('main', 0, 0, 0, T, D / 2, seg=40); return m
def picture(W, H): m = M(); f = .025; m.box('accent', -W / 2, 0, -.015, W / 2, H, .015); m.box('main', -W / 2 + f, f, .015, W / 2 - f, H - f, .017, 1 / .5); return m
def curtain(W=1.6, H=2.4):
    m = M(); n = 14; w = W / n
    for i in range(n): z = .03 if i % 2 else 0; m.box('main', -W / 2 + i * w, 0, -.04 + z, -W / 2 + (i + 1) * w, H - .05, -.01 + z, 1 / .6)
    m.box('accent', -W / 2 - .05, H - .05, -.05, W / 2 + .05, H - .02, -.02); return m
def tub(L=1.7, W=.75, H=.55):
    m = M(); m.box('white', -L / 2, 0, -W / 2, L / 2, H, W / 2); m.box('water', -L / 2 + .07, H - .003, -W / 2 + .07, L / 2 - .07, H + .002, W / 2 - .07); m.cyl('accent', -L / 2 + .06, 0, H, H + .22, .015); m.box('accent', -L / 2 + .045, H + .2, -.01, -L / 2 + .12, H + .22, .01); return m
def toilet():
    m = M(); m.box('white', -.19, 0, -.37, .19, .75, -.17); m.box('white', -.19, 0, -.17, .19, .4, .25); m.cyl('white', 0, .25, .38, .42, .18, .17, 28); m.box('white', -.17, .4, -.17, .17, .43, .27); return m
def vanity(W, D=.5, H=.8):
    m = cab(W, 'dr3', D, H); m.box('top', -W / 2, H, -D / 2, W / 2, H + .03, D / 2 + .01, 1.0); m.box('white', -W / 2 + .1, H + .03, -D / 2 + .06, W / 2 - .1, H + .045, D / 2 - .08)
    m.cyl('accent', 0, -D / 2 + .05, H + .03, H + .22, .012); m.box('accent', -.006, H + .2, -D / 2 + .05, .006, H + .215, -D / 2 + .14); return m
def shower(W=.9, H=2.0):
    m = M(); m.box('white', -W / 2, 0, -W / 2, W / 2, .05, W / 2); m.box('glassc', -W / 2, .05, W / 2 - .01, W / 2, H, W / 2); m.box('glassc', W / 2 - .01, .05, -W / 2, W / 2, H, W / 2)
    m.box('accent', -W / 2, .05, W / 2 - .02, W / 2, .07, W / 2); m.box('accent', -W / 2, H - .02, W / 2 - .02, W / 2, H, W / 2); m.box('accent', W / 2 - .02, .05, -W / 2, W / 2, H, -W / 2 + .03); m.cyl('accent', -W / 2 + .1, -W / 2 + .1, 1.6, 2.0, .01); return m

# ---------------- openings (z centred on wall thickness .10) ----------------
def door(W=.9, H=2.05, leaves=1, glass=False):
    m = M(); f = .06
    m.box('accent', -W / 2, 0, -.055, -W / 2 + f, H, .055, 1 / .6); m.box('accent', W / 2 - f, 0, -.055, W / 2, H, .055, 1 / .6); m.box('accent', -W / 2, H - f, -.055, W / 2, H, .055, 1 / .6)
    iw = W - 2 * f; lw = iw / leaves
    for i in range(leaves):
        x0 = -W / 2 + f + i * lw
        if glass:
            fr = .08; m.box('main', x0 + .002, 0, -.02, x0 + fr, H - f, .02, 1 / .6); m.box('main', x0 + lw - fr, 0, -.02, x0 + lw - .002, H - f, .02, 1 / .6); m.box('main', x0 + fr, 0, -.02, x0 + lw - fr, fr, .02, 1 / .6)
            m.box('main', x0 + fr, H - f - fr, -.02, x0 + lw - fr, H - f, .02, 1 / .6); m.box('glassc', x0 + fr, fr, -.004, x0 + lw - fr, H - f - fr, .004)
        else: m.box('main', x0 + .002, 0, -.02, x0 + lw - .002, H - f, .02, 1 / .6)
        hx = x0 + lw - .1 if (i == leaves - 1 and leaves == 1) or i == 0 and leaves > 1 else x0 + .06
        m.box('dsteel', hx - .05, .95, .02, hx + .06, .975, .048); m.box('dsteel', hx - .02, .93, .02, hx, 1.0, .03)
    return m
def slider(W=1.8, H=2.1):
    m = M(); f = .05; m.box('accent', -W / 2, 0, -.055, W / 2, f, .055); m.box('accent', -W / 2, H - f, -.055, W / 2, H, .055); m.box('accent', -W / 2, 0, -.055, -W / 2 + f, H, .055); m.box('accent', W / 2 - f, 0, -.055, W / 2, H, .055)
    for i, z in enumerate((-.02, .02)):
        x0 = -W / 2 + f + i * (W - 2 * f) / 2 - (.03 if i else 0); x1 = x0 + (W - 2 * f) / 2 + .03; fr = .05
        m.box('main', x0, f, z - .008, x0 + fr, H - f, z + .008); m.box('main', x1 - fr, f, z - .008, x1, H - f, z + .008); m.box('main', x0 + fr, f, z - .008, x1 - fr, f + fr, z + .008); m.box('main', x0 + fr, H - f - fr, z - .008, x1 - fr, H - f, z + .008)
        m.box('glassc', x0 + fr, f + fr, z - .003, x1 - fr, H - f - fr, z + .003)
    return m
def window(W, H, sill=True, mull=1):
    m = M(); f = .05
    m.box('main', -W / 2, 0, -.04, -W / 2 + f, H, .04); m.box('main', W / 2 - f, 0, -.04, W / 2, H, .04); m.box('main', -W / 2 + f, 0, -.04, W / 2 - f, f, .04); m.box('main', -W / 2 + f, H - f, -.04, W / 2 - f, H, .04)
    iw = W - 2 * f
    for i in range(1, mull + 1): x = -W / 2 + f + iw * i / (mull + 1); m.box('main', x - .015, f, -.04, x + .015, H - f, .04)
    m.box('glassc', -W / 2 + f, f, -.004, W / 2 - f, H - f, .004)
    if sill: m.box('top', -W / 2 - .04, -.03, -.05, W / 2 + .04, 0, .1, 1.0)
    return m
def unit(k, uo=.5): m = M(); m.box(k, -.5, 0, -.5, .5, 1, .5, 1.0, uo); return m
def floor_tile(): m = M(); m.box('main', 0, -.03, 0, 1, 0, 1, 1.0, 0); return m
def shadow_q(): m = M(); m.quad('shadow', [(-.5, .0, -.5), (.5, .0, -.5), (.5, .0, .5), (-.5, .0, .5)], [(0, 1, 0)] * 4, [(0, 0), (1, 0), (1, 1), (0, 1)]); return m

# ---------------- glb writer ----------------
FIX = {'dark': ((.035, .035, .04), 0, .5), 'glass': ((.02, .025, .03), 0, .04), 'glassc': ((.7, .85, .92), 0, .03, .16), 'white': ((.95, .95, .95), 0, .4), 'dsteel': ((.16, .16, .17), 1, .4),
       'pot': ((.78, .74, .68), 0, .7), 'soil': ((.09, .06, .045), 0, 1), 'leaf': ((.17, .42, .16), 0, .55), 'mirror': ((.85, .9, .95), 1, .02), 'fruit_r': ((.7, .1, .08), 0, .4),
       'fruit_o': ((.9, .45, .05), 0, .5), 'fruit_y': ((.9, .8, .15), 0, .5), 'book1': ((.6, .15, .12), 0, .7), 'book2': ((.15, .3, .5), 0, .7), 'book3': ((.8, .7, .4), 0, .7),
       'book4': ((.2, .4, .3), 0, .7), 'water': ((.55, .75, .85), 0, .05)}
SLOT = ('main', 'top', 'accent')
WHITE = png(np.ones((4, 4, 3)))
def radial():
    y, x = np.mgrid[0:128, 0:128] / 127.0; r = np.sqrt((x - .5)**2 + (y - .5)**2) * 2; a = np.clip(1 - r, 0, 1)**1.6
    out = np.zeros((128, 128, 4)); out[..., 3] = a; return png(out, 'RGBA')
RADIAL = radial()
def write(path, m):
    bin_ = bytearray(); bvs, accs, prims, mats, imgs, texs = [], [], [], [], [], []
    def view(data, target=None):
        while len(bin_) % 4: bin_.append(0)
        v = {"buffer": 0, "byteOffset": len(bin_), "byteLength": len(data)}; bin_.extend(data)
        if target: v["target"] = target
        bvs.append(v); return len(bvs) - 1
    def acc(vw, ct, cnt, ty, **kw): accs.append(dict(bufferView=vw, componentType=ct, count=cnt, type=ty, **kw)); return len(accs) - 1
    def tex(data):
        imgs.append({"bufferView": view(data), "mimeType": "image/png"}); texs.append({"source": len(imgs) - 1, "sampler": 0}); return len(texs) - 1
    tw = tr = None; order = []
    for k, pr in m.p.items():
        order.append(k); extra = {}
        if k in SLOT:
            if tw is None: tw = tex(WHITE)
            pbr = {"baseColorFactor": [1, 1, 1, 1], "baseColorTexture": {"index": tw}, "metallicFactor": 0, "roughnessFactor": .6}
        elif k == 'shadow':
            if tr is None: tr = tex(RADIAL)
            pbr = {"baseColorFactor": [0, 0, 0, 1], "baseColorTexture": {"index": tr}, "metallicFactor": 0, "roughnessFactor": 1}; extra = {"alphaMode": "BLEND", "doubleSided": True}
        else:
            c, me, ro, *al = FIX[k]; al = al[0] if al else 1
            pbr = {"baseColorFactor": list(c) + [al], "metallicFactor": me, "roughnessFactor": ro}
            if al < 1: extra = {"alphaMode": "BLEND", "doubleSided": True}
        mats.append({"pbrMetallicRoughness": pbr, "name": k, **extra})
        pos = np.array(pr['pos'], '<f4'); nor = np.array(pr['nor'], '<f4'); uv = np.array(pr['uv'], '<f4'); idx = np.array(pr['idx'], '<u2')
        ai = acc(view(idx.tobytes(), 34963), 5123, len(idx), "SCALAR"); ap = acc(view(pos.tobytes(), 34962), 5126, len(pos), "VEC3", min=pos.min(0).tolist(), max=pos.max(0).tolist())
        an = acc(view(nor.tobytes(), 34962), 5126, len(nor), "VEC3"); au = acc(view(uv.tobytes(), 34962), 5126, len(uv), "VEC2")
        prims.append({"attributes": {"POSITION": ap, "NORMAL": an, "TEXCOORD_0": au}, "indices": ai, "material": len(mats) - 1})
    j = {"asset": {"version": "2.0"}, "scene": 0, "scenes": [{"nodes": [0]}], "nodes": [{"mesh": 0}], "meshes": [{"primitives": prims}], "materials": mats, "accessors": accs, "bufferViews": bvs, "buffers": [{"byteLength": len(bin_)}]}
    if imgs: j.update(images=imgs, textures=texs, samplers=[{"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497}])
    js = json.dumps(j).encode(); js += b' ' * (-len(js) % 4); bin_ += b'\0' * (-len(bin_) % 4)
    open(path, 'wb').write(struct.pack('<4sII', b'glTF', 2, 28 + len(js) + len(bin_)) + struct.pack('<I4s', len(js), b'JSON') + js + struct.pack('<I4s', len(bin_), b'BIN\0') + bin_)
    return order

# ---------------- icons ----------------
DEF = {'main': 'oak_nat', 'top': 'carrara', 'accent': 'steel_brushed'}
def color_of(k, mats):
    if k in SLOT: return PCOL[mats.get(k, DEF[k])]
    return np.array(FIX[k][0]) if k in FIX else np.array([.5, .5, .5])
def icon(m, mats, path, size=96):
    yaw, pit = math.radians(-35), math.radians(26)
    Ry = np.array([[math.cos(yaw), 0, math.sin(yaw)], [0, 1, 0], [-math.sin(yaw), 0, math.cos(yaw)]]); Rx = np.array([[1, 0, 0], [0, math.cos(pit), -math.sin(pit)], [0, math.sin(pit), math.cos(pit)]]); R = Rx @ Ry
    tris = []
    for k, pr in m.p.items():
        col = color_of(k, mats); Q = (R @ np.array(pr['pos']).T).T
        for i in range(0, len(pr['idx']), 3):
            a, b, c = Q[pr['idx'][i]], Q[pr['idx'][i + 1]], Q[pr['idx'][i + 2]]; n = np.cross(b - a, c - a); ln = np.linalg.norm(n)
            if ln < 1e-12: continue
            n = n / ln
            if n[2] <= 0: continue
            sh = .5 + .5 * max(0, float(np.dot(n, [.35, .8, .5]))); tris.append(((a[2] + b[2] + c[2]) / 3, [a[:2], b[:2], c[:2]], np.clip(col * sh, 0, 1)))
    if not tris: return
    xs = [p[0] for t in tris for p in t[1]]; ys = [p[1] for t in tris for p in t[1]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys); S = size * 2 * .86 / max(x1 - x0, y1 - y0, 1e-6); cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    img = Image.new('RGBA', (size * 2, size * 2), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    for z, poly, col in sorted(tris, key=lambda t: t[0]):
        d.polygon([(size + (p[0] - cx) * S, size - (p[1] - cy) * S) for p in poly], fill=tuple(int(c * 255) for c in col) + (255,))
    img.resize((size, size), Image.LANCZOS).save(path)

# ---------------- registry ----------------
CAT = []
def reg(id, name, grp, cat, m, w, d, h, elev=0, mats=None):
    mats = mats or {}; order = write(os.path.join(A, 'models', id + '.glb'), m); icon(m, mats, os.path.join(A, 'icons', id + '.png'))
    CAT.append(dict(id=id, name=name, grp=grp, cat=cat, asset=id + '.glb', w=w, d=d, h=h, elev=elev, mats=mats, order=order))
G_BASE, G_SINK, G_WALL, G_TALL, G_TOP, G_SPL, G_APP, G_HOOD, G_KD = 'خزائن سفلية', 'أحواض', 'خزائن علوية', 'أعمدة وتخزين', 'أسطح وجزر', 'باكسبلاش', 'أجهزة', 'شفاطات', 'ديكور مطبخ'
G_TAB, G_CH, G_SOFA, G_BED, G_STO, G_LI, G_BATH, G_DOOR, G_WIN = 'طاولات', 'كراسي ومقاعد', 'كنب وجلوس', 'غرف نوم', 'خزائن وأثاث', 'إضاءة وديكور', 'حمام', 'أبواب', 'نوافذ'
DW = {'main': 'oak_nat', 'accent': 'steel_brushed'}; DWL = {'main': 'gloss_grey', 'accent': 'steel_brushed'}; DST = {'main': 'steel_brushed', 'accent': 'steel_brushed'}
DF = {'main': 'oak_nat', 'accent': 'black_metal'}; DFB = {'main': 'fabric_grey', 'accent': 'black_metal'}; DDR = {'main': 'gloss_white', 'accent': 'gloss_white'}

for W in (30, 40, 45, 50, 60, 80, 90, 100, 120): reg(f'base{W}', f'سفلية {W}', G_BASE, 'BASE', cab(W / 100, 'dr1' if W >= 40 else 'door'), W, 60, 85, mats=DW)
for W in (40, 60, 80, 100): reg(f'drw{W}', f'أدراج {W}', G_BASE, 'BASE', cab(W / 100, 'dr3'), W, 60, 85, mats=DW)
for W in (60, 80, 100, 120): reg(f'sink{W}', f'حوض {W}' + (' مزدوج' if W >= 120 else ''), G_SINK, 'BASE', sinkcab(W / 100, W >= 120), W, 60, 115, mats={'main': 'oak_nat', 'top': 'carrara', 'accent': 'chrome'})
for W in (30, 40, 45, 50, 60, 80, 90, 100): reg(f'wall{W}', f'علوية {W}', G_WALL, 'WALL_UNIT', wcab(W / 100), W, 35, 70, 140, mats=DWL)
for W in (60, 80): reg(f'wallg{W}', f'علوية زجاج {W}', G_WALL, 'WALL_UNIT', wcab(W / 100, glass=True), W, 35, 70, 140, mats=DWL)
reg('wallh60', 'علوية عالية 60', G_WALL, 'WALL_UNIT', wcab(.6, .9), 60, 35, 90, 120, mats=DWL)
for W in (80, 120): reg(f'shelf{W}', f'رف {W}', G_WALL, 'WALL_UNIT', shelf(W / 100), W, 25, 15, 140, mats={'main': 'oak_nat', 'accent': 'black_metal'})
for W in (60, 80): reg(f'pantry{W}', f'عمود تخزين {W}', G_TALL, 'BASE', tall(W / 100, 'pantry'), W, 60, 210, mats=DW)
reg('oventower60', 'عمود فرن 60', G_TALL, 'BASE', tall(.6, 'oven'), 60, 60, 210, mats=DW)
for L in (60, 90, 120, 150, 180, 240, 300): reg(f'top{L}', f'رخام {L}', G_TOP, 'COUNTER', counter(L / 100), L, 62, 4, 85, mats={'top': 'carrara'})
for L in (180, 240): reg(f'island{L}', f'جزيرة {L}', G_TOP, 'BASE', island(L / 100), L, 90, 89, mats={'main': 'oak_nat', 'top': 'carrara', 'accent': 'steel_brushed'})
for L in (60, 90, 120, 150, 180, 240): reg(f'splash{L}', f'باكسبلاش {L}', G_SPL, 'WALL_UNIT', splash(L / 100), L, 2, 60, 89, mats={'main': 'subway_white'})
for W in (60, 90): reg(f'hood{W}', f'شفاط {W}', G_HOOD, 'WALL_UNIT', hood(W / 100), W, 50, 90, 150, mats={'main': 'steel_brushed'})
for W in (60, 90): reg(f'range{W}', f'موقد وفرن {W}', G_APP, 'APPLIANCE', rng_(W / 100), W, 60, 90, mats={'main': 'steel_brushed', 'accent': 'steel_brushed'})
reg('fridge70', 'ثلاجة 70', G_APP, 'APPLIANCE', fridge('bot'), 70, 70, 180, mats=DST); reg('fridge90', 'ثلاجة جانبية 90', G_APP, 'APPLIANCE', fridge('side', .9), 90, 70, 180, mats=DST)
reg('fridge60u', 'ثلاجة صغيرة 60', G_APP, 'APPLIANCE', fridge('under', .6, .6, .85), 60, 60, 85, mats=DST)
reg('dish60', 'غسالة صحون', G_APP, 'APPLIANCE', dish(), 60, 60, 85, mats=DST); reg('micro45', 'ميكروويف', G_APP, 'APPLIANCE', micro(), 45, 35, 28, 89, mats=DST)
reg('washer60', 'غسالة ملابس', G_APP, 'APPLIANCE', washer(), 60, 60, 85, mats={'main': 'gloss_white', 'accent': 'steel_brushed'}); reg('wine60', 'مبرد مشروبات', G_APP, 'APPLIANCE', winecool(), 60, 60, 85, mats={'main': 'steel_brushed'})
reg('kettle', 'غلاية', G_KD, 'DECOR', kettle(), 18, 18, 24, 89, mats={'main': 'steel_brushed'}); reg('toaster', 'محمصة', G_KD, 'DECOR', toaster(), 30, 16, 18, 89, mats={'main': 'gloss_cream', 'accent': 'steel_brushed'})
reg('coffee', 'ماكينة قهوة', G_KD, 'DECOR', coffee(), 28, 40, 36, 89, mats={'main': 'gloss_black'}); reg('plant_s', 'نبتة صغيرة', G_KD, 'DECOR', plant(), 25, 25, 40, 89)
reg('plant_t', 'نبتة طويلة', G_KD, 'DECOR', plant(True), 55, 55, 160); reg('fruit', 'وعاء فواكه', G_KD, 'DECOR', fruitbowl(), 30, 30, 12, 89, mats={'main': 'oak_light'})
reg('canisters', 'علب حفظ', G_KD, 'DECOR', canisters(), 40, 12, 22, 89, mats={'main': 'gloss_white', 'accent': 'brass'}); reg('board', 'لوح تقطيع', G_KD, 'DECOR', board(), 40, 25, 2, 89, mats={'main': 'walnut'})
for L, Wd in ((120, 80), (160, 90), (200, 100)): reg(f'table{L}', f'طاولة {L}×{Wd}', G_TAB, 'FURNITURE', table(L / 100, Wd / 100), L, Wd, 75, mats=DF)
for D in (90, 120): reg(f'tabler{D}', f'طاولة دائرية {D}', G_TAB, 'FURNITURE', table_r(D / 100), D, D, 75, mats=DF)
reg('coffeet100', 'طاولة قهوة 100', G_TAB, 'FURNITURE', coffee_t(1.0, .55), 100, 55, 40, mats=DF); reg('sidet', 'طاولة جانبية', G_TAB, 'FURNITURE', side_t(), 45, 45, 50, mats=DF)
reg('chair', 'كرسي طعام', G_CH, 'FURNITURE', chair(), 45, 45, 88, mats=DF); reg('chairup', 'كرسي منجّد', G_CH, 'FURNITURE', chair(True), 45, 45, 88, mats=DFB)
reg('stool65', 'كرسي مرتفع 65', G_CH, 'FURNITURE', stool(.65), 36, 36, 65, mats=DF); reg('stool75', 'كرسي مرتفع 75', G_CH, 'FURNITURE', stool(.75), 36, 36, 75, mats=DF)
reg('armchair', 'كنبة مفردة', G_CH, 'FURNITURE', armchair(), 80, 80, 85, mats=DFB); reg('ochair', 'كرسي مكتب', G_CH, 'FURNITURE', ochair(), 60, 60, 95, mats={'main': 'leather_black'}); reg('ottoman', 'بوف', G_CH, 'FURNITURE', ottoman(), 60, 60, 40, mats=DFB)
for L, n in ((160, 'ثنائية'), (210, 'ثلاثية'), (260, 'رباعية')): reg(f'sofa{L}', f'كنبة {n}', G_SOFA, 'FURNITURE', sofa(L / 100), L, 90, 88, mats=DFB)
for W, n in ((90, 'مفرد'), (160, 'مزدوج'), (180, 'كبير')): reg(f'bed{W}', f'سرير {n} {W}', G_BED, 'FURNITURE', bed(W / 100), W + 8, 208, 110, mats={'main': 'fabric_grey', 'top': 'linen_beige', 'accent': 'black_metal'})
reg('night', 'كومودينو', G_BED, 'FURNITURE', nightstand(), 45, 40, 50, mats=DF)
for W in (100, 150, 200): reg(f'ward{W}', f'دولاب {W}', G_BED, 'FURNITURE', wardrobe(W / 100), W, 60, 220, mats={'main': 'oak_light', 'accent': 'steel_brushed'})
reg('dresser', 'تسريحة أدراج', G_BED, 'FURNITURE', dresser(), 100, 45, 85, mats=DW)
for L in (120, 160): reg(f'desk{L}', f'مكتب {L}', G_STO, 'FURNITURE', desk(L / 100), L, 65, 75, mats={'main': 'oak_light', 'accent': 'black_metal'})
for L in (160, 200): reg(f'tvu{L}', f'وحدة تلفاز {L}', G_STO, 'FURNITURE', tvunit(L / 100), L, 40, 45, mats={'main': 'walnut', 'accent': 'black_metal'})
reg('tv55', 'تلفاز 55', G_STO, 'DECOR', tv(1.2), 122, 20, 80, 45, mats={'accent': 'black_metal'})
for W, H in ((80, 180), (120, 200)): reg(f'books{W}', f'مكتبة {W}×{H}', G_STO, 'FURNITURE', bookshelf(W / 100, H / 100), W, 30, H, mats={'main': 'oak_nat'})
reg('shoe80', 'خزانة أحذية', G_STO, 'FURNITURE', dresser(.8, 1.1, .35), 80, 35, 110, mats=DW)
reg('flamp', 'أباجورة أرضية', G_LI, 'DECOR', floorlamp(), 44, 44, 172, mats={'accent': 'black_metal'}); reg('tlamp', 'أباجورة طاولة', G_LI, 'DECOR', tablelamp(), 34, 34, 42, 75, mats={'accent': 'brass'})
reg('pendant', 'ثريا معلّقة', G_LI, 'DECOR', pendant(), 52, 52, 85, 165, mats={'accent': 'brass'})
reg('rug160', 'سجادة 160×230', G_LI, 'DECOR', rug(1.6, 2.3), 160, 230, 2, mats={'main': 'linen_beige'}); reg('rug120', 'سجادة 120×180', G_LI, 'DECOR', rug(1.2, 1.8), 120, 180, 2, mats={'main': 'fabric_blush'})
reg('rugr160', 'سجادة دائرية', G_LI, 'DECOR', rug_r(1.6), 160, 160, 2, mats={'main': 'fabric_green'})
for W, H in ((40, 60), (60, 90), (90, 60)): reg(f'pic{W}x{H}', f'لوحة {W}×{H}', G_LI, 'WALL_UNIT', picture(W / 100, H / 100), W, 3, H, 130, mats={'main': 'sky', 'accent': 'black_metal'})
reg('mirror160', 'مرآة طويلة', G_LI, 'WALL_UNIT', mirror(.6, 1.6), 60, 4, 160, 20, mats={'accent': 'brass'}); reg('curtain', 'ستارة', G_LI, 'WALL_UNIT', curtain(), 160, 10, 240, 0, mats={'main': 'linen_beige', 'accent': 'black_metal'})
reg('tub170', 'حوض استحمام', G_BATH, 'FURNITURE', tub(), 170, 75, 77, mats={'accent': 'chrome'}); reg('toilet', 'مرحاض', G_BATH, 'FURNITURE', toilet(), 38, 62, 75)
for W in (60, 80, 100): reg(f'vanity{W}', f'مغسلة بخزانة {W}', G_BATH, 'BASE', vanity(W / 100), W, 50, 125, mats={'main': 'oak_light', 'top': 'carrara', 'accent': 'chrome'})
reg('shower90', 'كابينة دش 90', G_BATH, 'FURNITURE', shower(), 90, 90, 200, mats={'accent': 'chrome'})
for W in (70, 80, 90, 100): reg(f'door{W}', f'باب {W}', G_DOOR, 'OPENING', door(W / 100), W, 10, 205, mats=DDR)
reg('doorD140', 'باب مزدوج 140', G_DOOR, 'OPENING', door(1.4, 2.05, 2), 140, 10, 205, mats=DDR); reg('doorG90', 'باب زجاج 90', G_DOOR, 'OPENING', door(.9, 2.05, 1, True), 90, 10, 205, mats=DDR)
reg('doorG140', 'باب زجاج مزدوج', G_DOOR, 'OPENING', door(1.4, 2.1, 2, True), 140, 10, 210, mats=DDR); reg('slide180', 'باب منزلق 180', G_DOOR, 'OPENING', slider(1.8), 180, 10, 210, mats=DDR)
for W, H in ((60, 90), (80, 100), (100, 120), (120, 120), (150, 120), (180, 120)):
    reg(f'win{W}x{H}', f'نافذة {W}×{H}', G_WIN, 'OPENING', window(W / 100, H / 100, True, 0 if W < 90 else 1 if W < 140 else 2), W, 10, H, 90, mats={'main': 'gloss_white', 'top': 'carrara'})
reg('winF200', 'نافذة ثابتة 200×150', G_WIN, 'OPENING', window(2.0, 1.5, True, 1), 200, 10, 150, 80, mats={'main': 'gloss_white', 'top': 'carrara'})
reg('winTall', 'باب شرفة زجاجي', G_WIN, 'OPENING', window(.9, 2.1, False, 0), 90, 10, 210, 0, mats={'main': 'gloss_white'})

for nm, m in (('floor_tile', floor_tile()), ('wall', unit('main')), ('shadow', shadow_q())): write(os.path.join(A, 'models', nm + '.glb'), m)
json.dump(CAT, open(os.path.join(A, 'catalog.json'), 'w'), ensure_ascii=False)
print('catalog', len(CAT), 'items; groups', len(set(c['grp'] for c in CAT)))
